create trigger MIGR_GENERATION_ORDER_TRG
  before insert or update
  on MIGR_GENERATION_ORDER
  for each row
  BEGIN
  if inserting and :new.id is null then
        :new.id := MD_META.get_next_id;
    end if;
END;
/

