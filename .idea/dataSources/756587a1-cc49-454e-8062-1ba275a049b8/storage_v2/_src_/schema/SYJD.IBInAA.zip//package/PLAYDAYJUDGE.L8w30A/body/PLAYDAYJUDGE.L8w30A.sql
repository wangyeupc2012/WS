create package body playdayjudge is
--判断两个日期之间有多少个节假日及周末
  function f_playdayjudate(date1 varchar2,
                                 date2 varchar2) return number is
       amount_result    number:=0;
       week_number       number:=0;
       judge_number      number:=0;
       start_date        date:=to_date(date1,'yyyy-mm-dd');
       end_date          date:=to_date(date2,'yyyy-mm-dd');
       begin
          if start_date>=end_date 
            then 
              amount_result:=0;
            else
              
                loop
                    select to_char(start_date,'D') into week_number from dual;
                  if 
                    week_number =7 or week_number=1
                  then
                     amount_result:=amount_result+1;
                  else
                       select count(1) into judge_number from holiday where start_date=holiday_date;
                         if judge_number>0
                         then
                           amount_result:=amount_result+1;                      
                         end if;                 
                 end if;
                  start_date:=start_date+1;
                    --DBMS_output.put_line(start_date||'dddddddd');
              exit when start_date>end_date;
              end loop;
         end if;
        return amount_result;
      exception
       when others then
       return -1;
      end;
end playdayjudge;
/

