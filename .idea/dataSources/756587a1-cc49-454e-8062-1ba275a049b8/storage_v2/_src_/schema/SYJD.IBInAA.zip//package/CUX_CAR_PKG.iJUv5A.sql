create package CUX_CAR_PKG is

  -- Author  : C254462
  -- Created : 2018/7/26 9:15:05
  -- Purpose : CUX_CAR_PKG
  function getCarWayANDCarTimeName(p_milk_station_id number) return varchar2;

end CUX_CAR_PKG;
/

