create package crm_data_initialize_pkg is
  procedure crm_data_initialize;
  procedure saveErrorMessage(tablename in varchar2,errormessage in varchar2);
end crm_data_initialize_pkg;
/

