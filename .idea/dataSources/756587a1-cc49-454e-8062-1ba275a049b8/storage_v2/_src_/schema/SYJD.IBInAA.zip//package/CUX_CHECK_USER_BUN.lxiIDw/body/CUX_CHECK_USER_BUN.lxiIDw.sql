create package body cux_check_user_bun is

  function cux_check_user_bun(p_user_id     varchar2,
                              p_button_name varchar2,
                              p_type        varchar2) return varchar2 is
  
    v_count number := 0;
    v_type  number;
    --219线上 228线下
    
  begin
    select decode(p_type,
                  'online',
                  219,
                  'offline',
                  228)
      into v_type
      from dual;
    select count(1)
      into v_count
      from (
            
            SELECT BUTTON_NAME
              from fnd_resp_button frb, fnd_fun_button ffb
             where ffb.FUN_ID = frb.FUN_ID
               and ffb.BUTTON_ID = frb.BUTTON_ID
               and frb.RESP_ID in (select DISTINCT RESPONSIBILITY_ID
                                    from fnd_user_resps
                                   where USER_ID = p_user_id)
               and frb.FUN_ID = v_type
            
            ) t
     where t.button_name = p_button_name;
  
    if v_count > 0 then
      return 'Y';
    else
      return 'N';
    end if;
  end;
--history data
  function cux_check_user_bun1(p_user_id     varchar2,
                               p_button_name varchar2,
                               p_type        varchar2) return varchar2 is
  
    v_count number := 0;
    v_type  varchar2(100);
  begin
    select decode(p_type,
                  'online',
                  '线上订单管理',
                  'offline',
                  '线下订单管理')
      into v_type
      from dual;
    select count(1)
      into v_count
      from (SELECT ffb.button_id,
                   ffb.button_name,
                   ffb.description,
                   ff.function_path,
                   ff.function_id
              FROM FND_USER_RESPS  fur,
                   fnd_users       fu,
                   fnd_resp_button frb,
                   fnd_fun_button  ffb,
                   fnd_function    ff
             WHERE fur.user_id = fu.user_id
               AND fur.responsibility_id = frb.resp_id
               AND frb.button_id = ffb.button_id
               and ff.function_name = v_type
               and ffb.fun_id = ff.function_id
               AND fu.user_id = p_user_id
            UNION
            SELECT ffb.button_id,
                   ffb.button_name,
                   ffb.description,
                   frm.function_path,
                   frm.function_id
              FROM fnd_fun_button ffb,
                   (SELECT fm.function_id,
                           fun.function_path,
                           fun.FUNCTION_NAME
                      FROM fnd_menu fm, fnd_function_v fun
                     WHERE fm.function_id = fun.function_id(+)
                       AND fm.systemcode = 'PC'
                       AND trunc(fm.start_date) <= trunc(sysdate)
                       AND (fm.end_date IS NULL OR
                           trunc(fm.end_date) > trunc(sysdate))
                       AND exists
                     (SELECT 1
                              FROM fnd_user_resp_menu_v furm
                             WHERE furm.user_id = p_user_id
                               AND furm.menu_id = fm.menu_id)
                     START WITH fm.parent_menu_id = -1
                    CONNECT BY PRIOR fm.menu_id = fm.parent_menu_id) frm
             WHERE ffb.fun_id = frm.function_id
               AND NOT exists
             (SELECT 'x'
                      FROM fnd_user_resps  fur,
                           fnd_users       fu,
                           fnd_resp_button frb
                     WHERE fur.user_id = fu.user_id
                       AND fur.responsibility_id = frb.resp_id
                       AND frb.fun_id = ffb.fun_id
                       AND fu.user_id = p_user_id)
               and frm.function_name = v_type
             ORDER BY button_id, function_id
            
            ) t
     where t.button_name = p_button_name;
  
    if v_count > 0 then
      return 'Y';
    else
      return 'N';
    end if;
  end;

end cux_check_user_bun;
/

