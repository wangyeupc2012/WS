create package CUX_ORDER_EXCEL_PKG is

  -- Author  : WANGYE
  -- Created : 2018/4/1 20:44:04
  -- Purpose : CUX_ORDER_EXCEL_PKG

  PROCEDURE ORDER_UPLOAD_FROM_EXCEL;

end CUX_ORDER_EXCEL_PKG;
/

