create package crm_order_import_wdt_old is

  -- Author  : WANGYE
  -- Created : 2017/12/11 9:13:02
  -- Purpose : crm_order_import_wdt

  --导入正式表
  procedure import_into_orders(p_batch_id             in number,
                               p_insert_flag          out varchar2,
                               p_insert_error_message out varchar2);

  procedure import_into_pause_promotion(p_orderitemid in number, --中间表订单行ID
                                        p_batchId     in number,
                                        p_line_id     in number); --正式表行ID

end crm_order_import_wdt_old;
/

