create view CUX_SALEFORM as
  select
    DISTINCT
    d.DEALERS_NAME
    ,p.sn
    , p.qrname
    ,sum(osi.QUANTITY) salequantity
    ,nvl(ot.PRICE,0) PRICE
    ,sum(osi.QUANTITY)*nvl(ot.PRICE,0) receIncome
  ,nvl(ot.PAY_PRICE,0) PAY_PRICE
    ,sum(osi.QUANTITY)*nvl(ot.PAY_PRICE,0) realIncome
  ,os.SHIPPING_DATE
  from ORDERSHIPPINGITEM osi
    ,ORDERS o
    ,ORDERITEM ot
    ,ORDERSHIPPING os,
    product p,
    MILK_STATION ms,
    MILK_STATION_LINE msl,
    DEALERS d
  where os.ORDERS=o.ID
        and ot.ORDERS=o.id
        and os.ID=osi.ORDERSHIPPING_ID
        and p.sn=osi.SN
        and o.MILK_STATION_ID=ms.ID
        and msl.HEADER_ID=ms.ID
        and msl.DEALERS_ID=d.ID
  group by p.sn,p.QRNAME,d.DEALERS_NAME,ot.PRICE,ot.PAY_PRICE,os.SHIPPING_DATE
  order by d.DEALERS_NAME
/

