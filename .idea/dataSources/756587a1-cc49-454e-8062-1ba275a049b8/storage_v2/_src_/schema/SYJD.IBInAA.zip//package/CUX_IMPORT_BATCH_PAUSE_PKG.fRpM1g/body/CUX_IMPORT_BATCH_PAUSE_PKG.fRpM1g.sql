create package body CUX_IMPORT_BATCH_PAUSE_PKG is

  PROCEDURE IMPORT_BATCH_PAUSE(P_MSCOURIER_ID  IN VARCHAR2,
                               P_PAUSE_REASON  IN VARCHAR2,
                               P_PAUSE_FROM    IN VARCHAR2,
                               P_RECOVERY_DATE IN VARCHAR2,
                               P_CREATED_BY    IN VARCHAR2,
                               P_FLAG          OUT VARCHAR2,
                               P_MSG           OUT VARCHAR2) IS
    CURSOR CUR_ORDER_PAUSE IS
      SELECT OI.ID,
             OI.SHIPPING_TYPE,
             OI.ORDER_DATE_FROM,
             OI.ORDER_DATE_TO,
             OS.MS_COURIER_ID,
             OI.DAILY_DELIVERY_QUANTITY,
             OI.ORDER_DAYS
        FROM ORDERS OS, ORDERITEM OI
       WHERE OS.ID = OI.ORDERS
         AND OS.MS_COURIER_ID = P_MSCOURIER_ID
         AND ((OI.ORDER_DATE_FROM BETWEEN
             TO_DATE(P_PAUSE_FROM, 'yyyy-MM-dd') AND
             TO_DATE(P_RECOVERY_DATE, 'yyyy-MM-dd')) OR
             (OI.ORDER_DATE_TO BETWEEN TO_DATE(P_PAUSE_FROM, 'yyyy-MM-dd') AND
             TO_DATE(P_RECOVERY_DATE, 'yyyy-MM-dd')) OR
             (OI.ORDER_DATE_FROM <= TO_DATE(P_PAUSE_FROM, 'yyyy-MM-dd') AND
             OI.ORDER_DATE_TO > TO_DATE(P_RECOVERY_DATE, 'yyyy-MM-dd')));
    VAR_ORDER_PAUSE       CUR_ORDER_PAUSE%ROWTYPE;
    VAR_PAUSE_CNT         NUMBER;
    VAR_PAUSE_FROM        DATE := TO_DATE(P_PAUSE_FROM, 'yyyy-MM-dd');
    VAR_RECOVERY_DATE     DATE := TO_DATE(P_RECOVERY_DATE, 'yyyy-MM-dd');
    VAR_NEW_ORDER_DATE_TO DATE;
    VAR_BATCH_PAUSE_ID    NUMBER; --本次操作的批量暂停ID
    VAR_MILKSTATION_ID    NUMBER; --配送员所属奶站ID
    VAR_NUM               NUMBER := 0;
    VAR_ACT_PAUSE_CNT     NUMBER; --计算改日期是否存在于暂停区间内 大于0则标识有暂停（包括普通、批量、奶站APP等等）
    VAR_HOLIDAY_CNT       NUMBER; --是否是节假日
    VAR_WEEK              VARCHAR2(20);
    VAR_ACT_PAUSE_FROM    DATE; --订单展示实际暂停起始日期
  BEGIN
    --判断本次插入的批量暂停是否和该配送员已有批量暂停重叠
    SELECT COUNT(1)
      INTO VAR_PAUSE_CNT
      FROM MSCOURIER_BATCH_PAUSE MBP
     WHERE MBP.MS_COURIER_ID = P_MSCOURIER_ID
       AND ((MBP.PAUSE_DATE_FROM BETWEEN VAR_PAUSE_FROM AND
           VAR_RECOVERY_DATE) OR
           (MBP.RECOVERY_DATE BETWEEN VAR_PAUSE_FROM AND VAR_RECOVERY_DATE));
    IF VAR_PAUSE_CNT = 0 THEN
      --插入批量暂停表
      VAR_BATCH_PAUSE_ID := get_primary_id('MSCOURIER_BATCH_PAUSE');
    
      SELECT MC.MILK_STATION_ID
        INTO VAR_MILKSTATION_ID
        FROM MS_COURIER MC
       WHERE MC.ID = P_MSCOURIER_ID;
    
      INSERT INTO MSCOURIER_BATCH_PAUSE
        (ID,
         MS_COURIER_ID,
         PAUSE_DATE_FROM,
         RECOVERY_DATE,
         PAUSE_REASON,
         PAUSE_STATUS,
         CREATEDDATE,
         LASTMODIFIEDDATE,
         CREATED_BY,
         LAST_UPDATED_BY,
         VERSION,
         DELETE_STATUS,
         MILK_STATION_ID)
      VALUES
        (VAR_BATCH_PAUSE_ID,
         P_MSCOURIER_ID,
         VAR_PAUSE_FROM,
         VAR_RECOVERY_DATE,
         P_PAUSE_REASON,
         'Y',
         SYSDATE,
         SYSDATE,
         P_CREATED_BY,
         P_CREATED_BY,
         1,
         '',
         VAR_MILKSTATION_ID);
      --DBMS_OUTPUT.put_line('=====插入配送员暂停成功=======' || VAR_NUM);
      COMMIT;
      FOR VAR_ORDER_PAUSE IN CUR_ORDER_PAUSE LOOP
        BEGIN
          --插入ORDER_PAUSE_INTERVAL表
          IF VAR_PAUSE_FROM <= VAR_ORDER_PAUSE.ORDER_DATE_FROM THEN
            VAR_ACT_PAUSE_FROM := VAR_ORDER_PAUSE.ORDER_DATE_FROM;
          ELSE
            VAR_ACT_PAUSE_FROM := VAR_PAUSE_FROM;
          END IF;
          INSERT INTO ORDER_PAUSE_INTERVAL
            (ID,
             CREATEDDATE,
             LASTMODIFIEDDATE,
             VERSION,
             CREATED_BY,
             LAST_UPDATED_BY,
             ORDERITEM_ID,
             PAUSE_STATUS,
             QUANTITY,
             PAUSE_INDEX,
             PAUSE_DATE_FROM,
             RECOVERY_DATE,
             IS_EXPIRY_DATE_FLAG,
             PAUSE_REASON,
             PAUSE_FROM,
             BATCH_PAUSE_ID)
          VALUES
            (get_primary_id('ORDER_PAUSE_INTERVAL'),
             SYSDATE,
             SYSDATE,
             1,
             P_CREATED_BY,
             P_CREATED_BY,
             VAR_ORDER_PAUSE.ID,
             'Y',
             VAR_ORDER_PAUSE.DAILY_DELIVERY_QUANTITY,
             1,
             VAR_ACT_PAUSE_FROM,
             VAR_RECOVERY_DATE,
             '',
             P_PAUSE_REASON,
             'CRM_BATCH_PAUSE',
             VAR_BATCH_PAUSE_ID);
          --  DBMS_OUTPUT.put_line('=====插入暂停成功=======' || VAR_NUM);
          --日期顺延计算
          IF VAR_ORDER_PAUSE.ORDER_DAYS IS NOT NULL THEN
            -- DBMS_OUTPUT.put_line('=====开始计算日期顺延=======' || VAR_NUM);
            IF VAR_ORDER_PAUSE.SHIPPING_TYPE = 0 THEN
              --VAR_NUM := 0;
              --  DBMS_OUTPUT.put_line('=====每日配送=======' ||
              --                 VAR_ORDER_PAUSE.ID);
              VAR_NEW_ORDER_DATE_TO := VAR_ORDER_PAUSE.ORDER_DATE_FROM;
              WHILE VAR_NUM <= VAR_ORDER_PAUSE.ORDER_DAYS LOOP
                -- DBMS_OUTPUT.put_line('=====每日配送=======' || VAR_NUM|| VAR_NEW_ORDER_DATE_TO);
                --从起始配送日期开始判断每一天是否是暂停内 不是则实际配送加一天
                SELECT COUNT(1)
                  INTO VAR_ACT_PAUSE_CNT
                  FROM ORDER_PAUSE_INTERVAL OPI
                 WHERE OPI.ORDERITEM_ID = VAR_ORDER_PAUSE.ID
                   AND VAR_NEW_ORDER_DATE_TO >= OPI.PAUSE_DATE_FROM
                   AND VAR_NEW_ORDER_DATE_TO < OPI.RECOVERY_DATE;
                IF VAR_ACT_PAUSE_CNT = 0 THEN
                  VAR_NUM := VAR_NUM + 1;
                END IF;
                IF VAR_NUM < VAR_ORDER_PAUSE.ORDER_DAYS THEN
                  VAR_NEW_ORDER_DATE_TO := VAR_NEW_ORDER_DATE_TO + 1;
                END IF;
              END LOOP;
              VAR_NUM := 0;
              UPDATE ORDERITEM OI
                 SET OI.ORDER_DATE_TO    = VAR_NEW_ORDER_DATE_TO,
                     OI.LAST_UPDATED_BY  = P_CREATED_BY,
                     OI.LASTMODIFIEDDATE = SYSDATE
               WHERE OI.ID = VAR_ORDER_PAUSE.ID;
              P_FLAG := 'Y';
            ELSIF VAR_ORDER_PAUSE.SHIPPING_TYPE = 1 THEN
              --计算每一天是否为工作日 或者 是否存在于暂停区间
              --VAR_NUM := 0;
              --DBMS_OUTPUT.put_line('=====工作日配送=======' || VAR_ORDER_PAUSE.ID);
              VAR_NEW_ORDER_DATE_TO := VAR_ORDER_PAUSE.ORDER_DATE_FROM;
              WHILE VAR_NUM < VAR_ORDER_PAUSE.ORDER_DAYS LOOP
                --DBMS_OUTPUT.put_line('=====工作日配送=======' || VAR_NUM || VAR_NEW_ORDER_DATE_TO);
                SELECT COUNT(1)
                  INTO VAR_ACT_PAUSE_CNT
                  FROM ORDER_PAUSE_INTERVAL OPI
                 WHERE OPI.ORDERITEM_ID = VAR_ORDER_PAUSE.ID
                   AND VAR_NEW_ORDER_DATE_TO >= OPI.PAUSE_DATE_FROM
                   AND VAR_NEW_ORDER_DATE_TO < OPI.RECOVERY_DATE;
                IF VAR_ACT_PAUSE_CNT = 0 THEN
                  --判断是否是周末或者节假日
                  SELECT COUNT(1)
                    INTO VAR_HOLIDAY_CNT
                    FROM HOLIDAY H
                   WHERE H.HOLIDAY_DATE = VAR_NEW_ORDER_DATE_TO;
                
                  SELECT TO_CHAR(VAR_NEW_ORDER_DATE_TO, 'DAY')
                    INTO VAR_WEEK
                    FROM DUAL;
                  --DBMS_OUTPUT.put_line('=====工作日配送=======' || VAR_HOLIDAY_CNT || VAR_WEEK);
                  IF VAR_HOLIDAY_CNT = 0 AND VAR_WEEK <> '星期六' AND
                     VAR_WEEK <> '星期日' THEN
                    VAR_NUM := VAR_NUM + 1;
                  END IF;
                  --  DBMS_OUTPUT.put_line(VAR_NUM || VAR_HOLIDAY_CNT ||
                  -- VAR_WEEK || VAR_NEW_ORDER_DATE_TO);
                END IF;
                IF VAR_NUM < VAR_ORDER_PAUSE.ORDER_DAYS THEN
                  VAR_NEW_ORDER_DATE_TO := VAR_NEW_ORDER_DATE_TO + 1;
                END IF;
              END LOOP;
              VAR_NUM := 0;
              UPDATE ORDERITEM OI
                 SET OI.ORDER_DATE_TO    = VAR_NEW_ORDER_DATE_TO,
                     OI.LAST_UPDATED_BY  = P_CREATED_BY,
                     OI.LASTMODIFIEDDATE = SYSDATE
               WHERE OI.ID = VAR_ORDER_PAUSE.ID;
              P_FLAG := 'Y';
            END IF;
          END IF;
        EXCEPTION
          WHEN OTHERS THEN
            P_FLAG := 'N';
            P_MSG  := '错误信息：' || SQLERRM;
        END;
        COMMIT;
      END LOOP;
      P_FLAG := 'Y';
    ELSE
      P_FLAG := 'E';
      P_MSG  := '该配送员已有重叠的暂停区间！';
    END IF;
  EXCEPTION
    WHEN OTHERS THEN
      P_FLAG := 'N';
      P_MSG  := '错误信息：' || SQLERRM;
  END;

  PROCEDURE DELETE_BATCH_PAUSE(P_BATCH_PAUSE_ID IN VARCHAR2,
                               P_FLAG           OUT VARCHAR2,
                               P_MSG            OUT VARCHAR2) IS
    CURSOR CUR_BATCH_PAUSE IS
      SELECT *
        FROM ORDER_PAUSE_INTERVAL OPI
       WHERE OPI.BATCH_PAUSE_ID = P_BATCH_PAUSE_ID;
    VAR_BATCH_PAUSE       CUR_BATCH_PAUSE%ROWTYPE;
    VAR_ORDER_FROM        DATE;
    VAR_ORDER_DAYS        NUMBER;
    VAR_SHIPPING_TYPE     NUMBER;
    VAR_NEW_ORDER_DATE_TO DATE;
    VAR_NUM               NUMBER := 0;
    VAR_ACT_PAUSE_CNT     NUMBER;
    VAR_HOLIDAY_CNT       NUMBER;
    VAR_WEEK              VARCHAR2(20);
  BEGIN
    --恢复订单终止日期
    FOR VAR_BATCH_PAUSE IN CUR_BATCH_PAUSE LOOP
      BEGIN
        SELECT OI.ORDER_DATE_FROM, OI.ORDER_DAYS, OI.SHIPPING_TYPE
          INTO VAR_ORDER_FROM, VAR_ORDER_DAYS, VAR_SHIPPING_TYPE
          FROM ORDERITEM OI
         WHERE OI.ID = VAR_BATCH_PAUSE.ORDERITEM_ID;
      EXCEPTION
        WHEN OTHERS THEN
          P_FLAG := 'E';
          P_MSG  := '错误信息：' || SQLERRM;
      END;
      IF VAR_SHIPPING_TYPE = 0 THEN
        VAR_NEW_ORDER_DATE_TO := VAR_ORDER_FROM;
        WHILE VAR_NUM <= VAR_ORDER_DAYS LOOP
          --从起始配送日期开始判断每一天是否是暂停内 不是则实际配送加一天
          --DBMS_OUTPUT.put_line(0||'=='||VAR_NEW_ORDER_DATE_TO||'=='|| VAR_NUM);
          SELECT COUNT(1)
            INTO VAR_ACT_PAUSE_CNT
            FROM ORDER_PAUSE_INTERVAL OPI
           WHERE OPI.ORDERITEM_ID = VAR_BATCH_PAUSE.ORDERITEM_ID
             AND VAR_NEW_ORDER_DATE_TO >= OPI.PAUSE_DATE_FROM
             AND VAR_NEW_ORDER_DATE_TO < OPI.RECOVERY_DATE
             AND (OPI.BATCH_PAUSE_ID <> P_BATCH_PAUSE_ID OR
                 OPI.BATCH_PAUSE_ID IS NULL); --将要删除的批量暂停排除
          IF VAR_ACT_PAUSE_CNT = 0 THEN
            VAR_NUM := VAR_NUM + 1;
          END IF;
          --  DBMS_OUTPUT.put_line(0||'=='||VAR_NEW_ORDER_DATE_TO||'=='|| VAR_NUM);
          IF VAR_NUM < VAR_ORDER_DAYS THEN
            VAR_NEW_ORDER_DATE_TO := VAR_NEW_ORDER_DATE_TO + 1;
          END IF;
        END LOOP;
        VAR_NUM := 0;
      ELSIF VAR_SHIPPING_TYPE = 1 THEN
        VAR_NEW_ORDER_DATE_TO := VAR_ORDER_FROM;
        WHILE VAR_NUM <= VAR_ORDER_DAYS LOOP
          SELECT COUNT(1)
            INTO VAR_ACT_PAUSE_CNT
            FROM ORDER_PAUSE_INTERVAL OPI
           WHERE OPI.ORDERITEM_ID = VAR_BATCH_PAUSE.ORDERITEM_ID
             AND VAR_NEW_ORDER_DATE_TO >= OPI.PAUSE_DATE_FROM
             AND VAR_NEW_ORDER_DATE_TO < OPI.RECOVERY_DATE
             AND (OPI.BATCH_PAUSE_ID <> P_BATCH_PAUSE_ID OR
                 OPI.BATCH_PAUSE_ID IS NULL); --将要删除的批量暂停排除
          IF VAR_ACT_PAUSE_CNT = 0 THEN
            --判断是否是周末或者节假日
            SELECT COUNT(1)
              INTO VAR_HOLIDAY_CNT
              FROM HOLIDAY H
             WHERE H.HOLIDAY_DATE = VAR_NEW_ORDER_DATE_TO;
          
            SELECT TO_CHAR(VAR_NEW_ORDER_DATE_TO, 'DAY')
              INTO VAR_WEEK
              FROM DUAL;
            IF VAR_HOLIDAY_CNT = 0 AND VAR_WEEK <> '星期六' AND
               VAR_WEEK <> '星期日' THEN
              VAR_NUM := VAR_NUM + 1;
            END IF;
          END IF;
          --DBMS_OUTPUT.put_line(1||'=='||VAR_NEW_ORDER_DATE_TO||'=='|| VAR_NUM);
          IF VAR_NUM < VAR_ORDER_DAYS THEN
            VAR_NEW_ORDER_DATE_TO := VAR_NEW_ORDER_DATE_TO + 1;
          END IF;
        END LOOP;
        VAR_NUM := 0;
      END IF;
    
      UPDATE ORDERITEM OI
         SET OI.ORDER_DATE_TO    = VAR_NEW_ORDER_DATE_TO,
             OI.LASTMODIFIEDDATE = SYSDATE
       WHERE OI.ID = VAR_BATCH_PAUSE.ORDERITEM_ID;
      COMMIT;
    END LOOP;
    --删除暂停
    DELETE FROM ORDER_PAUSE_INTERVAL OPI
     WHERE OPI.BATCH_PAUSE_ID = P_BATCH_PAUSE_ID;
    DELETE FROM MSCOURIER_BATCH_PAUSE MBP WHERE MBP.ID = P_BATCH_PAUSE_ID;
    COMMIT;
    P_FLAG := 'Y';
  EXCEPTION
    WHEN OTHERS THEN
      P_FLAG := 'N';
      P_MSG  := '错误信息：' || SQLERRM;
  END;

  PROCEDURE UPDATE_BATCH_PAUSE(P_BATCH_PAUSE_ID IN VARCHAR2,
                               P_MSCOURIER_ID   IN VARCHAR2,
                               P_PAUSE_REASON   IN VARCHAR2,
                               P_PAUSE_FROM     IN VARCHAR2,
                               P_RECOVERY_DATE  IN VARCHAR2,
                               P_CREATED_BY     IN VARCHAR2,
                               P_FLAG           OUT VARCHAR2,
                               P_MSG            OUT VARCHAR2) IS
  BEGIN
    DELETE_BATCH_PAUSE(P_BATCH_PAUSE_ID, P_FLAG, P_MSG);
    IF P_FLAG = 'Y' THEN
      IMPORT_BATCH_PAUSE(P_MSCOURIER_ID,
                         P_PAUSE_REASON,
                         P_PAUSE_FROM,
                         P_RECOVERY_DATE,
                         P_CREATED_BY,
                         P_FLAG,
                         P_MSG);
    ELSE
      P_FLAG := 'N';
      P_MSG  := '错误信息：删除出错' || P_MSG;
    END IF;
  EXCEPTION
    WHEN OTHERS THEN
      P_FLAG := 'N';
      P_MSG  := '错误信息：' || SQLERRM;
  END;
end CUX_IMPORT_BATCH_PAUSE_PKG;
/

