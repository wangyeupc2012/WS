create package body cux_crm_util is

  function get_dealers_name(p_order_number varchar2) return varchar2 is
  
    cursor cur_dealers is
      select dmsv.dealers_name
        from (select os.sn              orders_number,
                     os.milk_station_id,
                     flvs.attribute1    order_source
                from orders os, orderitem oi, fnd_lookup_values flvs
               where os.id = oi.orders
                 and os.order_from = flvs.lookup_code
                 and flvs.lookup_type = 'ORDER_FROM') t,
             cux_dealers_milk_station_v dmsv
       where t.MILK_STATION_ID = dmsv.MILK_STATION_ID(+)
         and t.order_source = dmsv.source(+)
         and t.orders_number = p_order_number;
    var_dealers cur_dealers%rowtype;
  begin
    open cur_dealers;
    fetch cur_dealers
      into var_dealers;
    close cur_dealers;
  
    return var_dealers.dealers_name;
  end;
  procedure validate_orders(p_order_number varchar2, ----订单编号
                            p_flag         out varchar2, -----成功标识  Y/N
                            p_message      out varchar2) is
    ----错误信息
    v_count number := 0;
    -- v_flag varchar2(10);
    --  v_messge varchar2(100);                              
  begin
    -----验证订单是否生成配送单
    select count(1)
      into v_count
      from ordershipping opp, orders os
     where opp.orders = os.id
       and os.sn = p_order_number
       and nvl(opp.status, 'VALID') = 'VALID';
  
    if v_count > 0 then
      p_flag    := 'N';
      p_message := '该订单已存在配送单，请检查！';
      return;
    else
      p_flag    := 'Y';
      p_message := '验证通过！';
    end if;
  
  end;

  ----验证订单状态是否变成已完成    返回值 0/1
  function validate_order_lastdate(p_order_number varchar2) return number is
    v_number number := 0;
  begin
    SELECT count(1)
      into v_number
      from orders o, orderitem ot, ordershipping os
     where os.orders = o.id
       and ot.orders = o.id
       and o.sn = p_order_number
       and ot.REFUND_STATUS <> '5' ---没有退款
     group by o.sn
    having max(trunc(ot.order_date_to)) = max(trunc(os.shipping_date));
    return v_number;
  exception
    when others then
      return v_number;
  end;

  function get_tk_number return varchar2 is
    v_tk_number varchar2(30);
    v_count     number := 0;
    v_flag      boolean := true;
  begin
    while (v_flag) loop
      select 'TK' || TO_CHAR(SYSDATE, 'YYYYMMDD') ||
             LPAD(round(dbms_random.value(1, 999)), 3, '0')
        into v_tk_number
        from dual;
      select count(1)
        into v_count
        from orderrefunds t
       where t.refund_sn = v_tk_number;
      if (v_count = 0) then
        v_flag := false;
      end if;
    end loop;
    return v_tk_number;
  end;

  procedure get_how_many_days(p_start_date   in varchar2,
                              p_end_date     in varchar2,
                              p_orderitem_id in varchar2,
                              p_type         in varchar2,
                              p_flag         out varchar2,
                              p_result       out varchar2) is
    var_start_date  date := to_date(p_start_date, 'yyyy-MM-dd');
    var_end_date    date := to_date(p_end_date, 'yyyy-MM-dd');
    var_flag        varchar2(20) default 'Y';
    var_result      varchar2(200);
    var_type        varchar2(20);
    var_pause_count number;
    var_act_cnt     number := 0;
    var_ho_cnt      number;
    var_weekend     varchar2(10);
  begin
    if p_orderitem_id is null and p_type is null then
      var_flag   := 'N';
      var_result := '错误信息：订单行ID和配送类型不可同时为空；';
    end if;
    if var_flag = 'Y' then
      if p_orderitem_id is not null then
        --根据订单行id获取订单行配送类型
        begin
          select oi.shipping_type
            into var_type
            from orderitem oi
           where oi.id = p_orderitem_id;
        exception
          when others then
            var_flag   := 'N';
            var_result := '错误信息：未找到ID为' || p_orderitem_id || '的订单行信息；';
        end;
      
        if var_flag = 'Y' then
          if p_type is not null then
            if var_type <> p_type then
              var_flag   := 'N';
              var_result := '错误信息：根据订单行ID查询出的配送类型与传入配送类型不一致；';
            end if;
          end if;
          if var_flag = 'Y' then
            if var_type = 0 then
              --每日配送
              while var_start_date <= var_end_date loop
                --判断var_start_date是否在暂停区间内
                begin
                  select count(1)
                    into var_pause_count
                    from order_pause_interval opi
                   where 1 = 1
                     and opi.orderitem_id = p_orderitem_id
                     and var_start_date >= opi.pause_date_from
                     and var_start_date < opi.recovery_date;
                exception
                  when others then
                    null;
                end;
                if var_pause_count = 0 then
                  var_act_cnt := var_act_cnt + 1;
                end if;
                var_start_date := var_start_date + 1;
              end loop;
              var_result := var_act_cnt;
            elsif var_type = 1 then
              --工作日配送
              while var_start_date <= var_end_date loop
                --判断var_start_date是否在暂停区间内
                begin
                  select count(1)
                    into var_pause_count
                    from order_pause_interval opi
                   where 1 = 1
                     and opi.orderitem_id = p_orderitem_id
                     and var_start_date >= opi.pause_date_from
                     and var_start_date < opi.recovery_date;
                exception
                  when others then
                    null;
                end;
                if var_pause_count = 0 then
                  --判断是否是存在于表holiday中（判断是否是以维护的节假日）
                  begin
                    select count(1)
                      into var_ho_cnt
                      from holiday ho
                     where 1 = 1
                       and ho.holiday_date = var_start_date;
                  
                    select to_char(var_start_date, 'd')
                      into var_weekend
                      from dual;
                  
                  exception
                    when others then
                      null;
                  end;
                  if var_ho_cnt = 0 and var_weekend not in (1, 7) then
                    var_act_cnt := var_act_cnt + 1;
                  end if;
                end if;
                var_start_date := var_start_date + 1;
              end loop;
              var_result := var_act_cnt;
            end if;
          end if;
        end if;
        p_flag   := var_flag;
        p_result := var_result;
      else
        --配送类型不为空
        var_type := p_type;
        if var_type = 0 then
          --每日配送
          while var_start_date <= var_end_date loop
            --判断var_start_date是否在暂停区间内
            begin
              select count(1)
                into var_pause_count
                from order_pause_interval opi
               where 1 = 1
                 and opi.orderitem_id = p_orderitem_id
                 and var_start_date >= opi.pause_date_from
                 and var_start_date < opi.recovery_date;
            exception
              when others then
                null;
            end;
            if var_pause_count = 0 then
              var_act_cnt := var_act_cnt + 1;
            end if;
            var_start_date := var_start_date + 1;
          end loop;
          var_result := var_act_cnt;
        elsif var_type = 1 then
          --工作日配送
          while var_start_date <= var_end_date loop
            --判断var_start_date是否在暂停区间内
            begin
              select count(1)
                into var_pause_count
                from order_pause_interval opi
               where 1 = 1
                 and opi.orderitem_id = p_orderitem_id
                 and var_start_date >= opi.pause_date_from
                 and var_start_date < opi.recovery_date;
            
            exception
              when others then
                null;
            end;
            if var_pause_count = 0 then
              --判断是否是存在于表holiday中（判断是否是以维护的节假日）
              begin
                select count(1)
                  into var_ho_cnt
                  from holiday ho
                 where 1 = 1
                   and ho.holiday_date = var_start_date;
              
                select to_char(var_start_date, 'd')
                  into var_weekend
                  from dual;
              exception
                when others then
                  null;
              end;
              if var_ho_cnt = 0 and var_weekend not in (1, 7) then
                var_act_cnt := var_act_cnt + 1;
              end if;
            end if;
            var_start_date := var_start_date + 1;
          end loop;
          var_result := var_act_cnt;
        end if;
        p_flag   := var_flag;
        p_result := var_result;
      end if;
    else
      p_flag   := var_flag;
      p_result := var_result;
    end if;
  end;
  --查询奶站状态
  function check_milk_station_status(p_milk_station_id number,
                                     p_status          varchar2)
    return varchar2 is
    cursor cur_milk_station is
      select * from milk_station_line where header_id = p_milk_station_id;
  begin
    for var_msl in cur_milk_station loop
      if var_msl.status = p_status then
        return 'Y';
      end if;
    end loop;
    return 'N';
  end;
end cux_crm_util;
/

