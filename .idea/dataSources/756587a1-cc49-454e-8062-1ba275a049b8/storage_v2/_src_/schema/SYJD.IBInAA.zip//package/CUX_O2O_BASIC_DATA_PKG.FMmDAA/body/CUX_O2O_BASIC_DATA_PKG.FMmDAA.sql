create package body cux_o2o_basic_data_pkg is

  procedure lood_item is
    cursor cur_item is
      select *
        from cux_item_temp cit
       where cit.status is null
          or cit.status = 'N';
    var_item        cur_item%rowtype;
    v_status        varchar2(10) := 'Y';
    v_error_message varchar2(1000);
  
    v_item_id           number;
    v_body_style_cd     varchar2(50);
    v_type              varchar2(50);
    v_quality_cd        varchar2(50);
    v_sub_type_cd       varchar2(50);
    v_yn_sub_type_cd    varchar2(50);
    v_attribute14       varchar2(50);
    v_attribute15       varchar2(50);
    v_attribute13       varchar2(50);
    v_make_cd           varchar2(50);
    v_load_added        varchar2(50);
    v_attribute6        varchar2(50);
    v_attribute8        varchar2(50);
    v_attribute9        varchar2(50);
    v_attribute10       varchar2(50);
    v_creation_date     varchar2(50);
    v_created_by        varchar2(50);
    v_last_update_date  varchar2(50);
    v_last_updated_by   varchar2(50);
    v_last_update_login varchar2(50);
    v_org_id            varchar2(50) := '211';
    v_attribute11       varchar2(50);
    v_attribute12       varchar2(50);
    v_attrib_03         varchar2(50);
    v_attribute20       varchar2(50);
  
  begin
    for var_item in cur_item loop
      begin
        ------获取物料信息item_id
        begin
          select msi.inventory_item_id
            into v_item_id
            from mtl_system_items_b msi
           where msi.segment1 = var_item.bar_code_num
             and msi.organization_id = 84;
        exception
          when others then
            v_status        := 'E';
            v_error_message := '获取物料信息失败';
        end;
        ------获取生产商code对应 attribute13 
        begin
          select flv.LOOKUP_CODE
            into v_attribute13
            from fnd_lookup_values_vl flv
           where flv.MEANING = var_item.manufacturer
             and flv.LOOKUP_TYPE = 'CUX_MANUFACTURER'
             and flv.ENABLED_FLAG(+) = 'Y';
        exception
          when others then
            v_status        := 'E';
            v_error_message := '获取生产商信息失败';
        end;
        -------------name
        --------item_name
        -----------获取alias_name
        -----------获取bar_code_num
        ------------REF_NUMBER_1,
        ------------REF_NUMBER_3,
      
        ------------UOM_CD,
        ------------MTTR_UOM_CD,
        ------------ACCRUAL_RATE,
        ------------ACTIVE_FLAG,
        ------------MAKE_CD,
        begin
          select flv.LOOKUP_CODE
            into v_make_cd
            from fnd_lookup_values_vl flv
           where flv.MEANING = var_item.make_name
             and flv.LOOKUP_TYPE = 'CUX_ITEM_MAKE'
             and flv.ENABLED_FLAG(+) = 'Y';
        exception
          when others then
            v_status        := 'E';
            v_error_message := '获取品牌失败';
        end;
        ------------BODY_STYLE_CD,
        begin
          select flv.LOOKUP_CODE
            into v_body_style_cd
            from fnd_lookup_values_vl flv
           where flv.MEANING = var_item.body_style_name
             and flv.LOOKUP_TYPE = 'CUX_ITEM_BODY_STYLE'
             and flv.ENABLED_FLAG(+) = 'Y';
        exception
          when others then
            v_status        := 'E';
            v_error_message := '获取包装类型失败';
        end;
        ------------QUALITY_CD,
        begin
          select flv.LOOKUP_CODE
            into v_quality_cd
            from fnd_lookup_values_vl flv
           where flv.MEANING = var_item.quality_name
             and flv.LOOKUP_TYPE = 'CUX_ITEM_QUALITY'
             and flv.ENABLED_FLAG(+) = 'Y';
        exception
          when others then
            v_status        := 'E';
            v_error_message := '获取产品档次失败';
        end;
        ------------TYPE,
        begin
          select flv.LOOKUP_CODE
            into v_type
            from fnd_lookup_values_vl flv
           where flv.MEANING = var_item.type_name
             and flv.LOOKUP_TYPE = 'CUX_ITEM_TYPE'
             and flv.ENABLED_FLAG(+) = 'Y';
        exception
          when others then
            v_status        := 'E';
            v_error_message := '获取产品大类失败';
        end;
        ------------SUB_TYPE_CD,
        begin
          select flv.LOOKUP_CODE
            into v_sub_type_cd
            from fnd_lookup_values_vl flv
           where flv.MEANING = var_item.sub_type_name
             and flv.LOOKUP_TYPE = 'CUX_ITEM_SUB_TYPE'
             and flv.ENABLED_FLAG(+) = 'Y';
        exception
          when others then
            v_status        := 'E';
            v_error_message := '获取产品工艺失败';
        end;
        ------------YN_SUB_TYPE_CD,
        begin
          select flv.LOOKUP_CODE
            into v_yn_sub_type_cd
            from fnd_lookup_values_vl flv
           where flv.MEANING = var_item.yn_sub_type_name
             and flv.LOOKUP_TYPE = 'CUX_ITEM_TYPE'
             and flv.ENABLED_FLAG(+) = 'Y';
        exception
          when others then
            v_status        := 'E';
            v_error_message := '获取产品分类2失败';
        end;
        ------------ITEM_SIZE,
        ------------LOAD_ADDED,???存疑
        begin
          select null
            into v_load_added
            from mtl_system_items_b c
           where c.segment1 = var_item.bar_code_num
             and c.organization_id = 84;
        exception
          when others then
            v_status        := 'E';
            v_error_message := '获取失败';
        end;
        ------------ITEM_TAX_ITEM,
        ------------ATTRIBUTE1,
        ------------ATTRIBUTE2,
        ------------ATTRIBUTE3,
        ------------ATTRIBUTE4,
        ------------ATTRIBUTE5,
        ------------ATTRIBUTE6,
        begin
          select c.attribute6
            into v_attribute6
            from mtl_system_items_b c
           where c.segment1 = var_item.bar_code_num
             and c.organization_id = 84;
        exception
          when others then
            v_status        := 'E';
            v_error_message := '获取失败';
        end;
        ------------ATTRIBUTE7,
        ------------ATTRIBUTE8,
        begin
          select c.attribute8
            into v_attribute8
            from mtl_system_items_b c
           where c.segment1 = var_item.bar_code_num
             and c.organization_id = 84;
        exception
          when others then
            v_status        := 'E';
            v_error_message := '获取失败';
        end;
        ------------ATTRIBUTE9,
        begin
          select c.attribute9
            into v_attribute9
            from mtl_system_items_b c
           where c.segment1 = var_item.bar_code_num
             and c.organization_id = 84;
        exception
          when others then
            v_status        := 'E';
            v_error_message := '获取失败';
        end;
        ------------ATTRIBUTE10,
        begin
          select c.attribute10
            into v_attribute10
            from mtl_system_items_b c
           where c.segment1 = var_item.bar_code_num
             and c.organization_id = 84;
        exception
          when others then
            v_status        := 'E';
            v_error_message := '获取失败';
        end;
        /* ------------CREATION_DATE,
          begin
            select c.creation_date
              into v_creation_date
              from mtl_system_items_b c
             where c.segment1 = var_item.bar_code_num
               and c.organization_id = 84;
          exception
            when others then
              v_status        := 'E';
              v_error_message := '获取失败';
          end;
          ------------CREATED_BY,
          begin
            select c.created_by
              into v_created_by
              from mtl_system_items_b c
             where c.segment1 = var_item.bar_code_num
               and c.organization_id = 84;
          exception
            when others then
              v_status        := 'E';
              v_error_message := '获取失败';
          end;
          ------------LAST_UPDATE_DATE,
          begin
            select c.last_update_date
              into v_last_update_date
              from mtl_system_items_b c
             where c.segment1 = var_item.bar_code_num
               and c.organization_id = 84;
          exception
            when others then
              v_status        := 'E';
              v_error_message := '获取失败';
          end;
          ------------LAST_UPDATED_BY,
          begin
            select c.last_updated_by
              into v_last_updated_by
              from mtl_system_items_b c
             where c.segment1 = var_item.bar_code_num
               and c.organization_id = 84;
          exception
            when others then
              v_status        := 'E';
              v_error_message := '获取失败';
          end;
          ------------LAST_UPDATE_LOGIN,
          begin
            select c.last_update_login
              into v_last_update_login
              from mtl_system_items_b c
             where c.segment1 = var_item.bar_code_num
               and c.organization_id = 84;
          exception
            when others then
              v_status        := 'E';
              v_error_message := '获取失败';
          end;
          ------------org_id(*is null*),
        */
        ------------ATTRIBUTE11,
        begin
          select c.attribute11
            into v_attribute11
            from mtl_system_items_b c
           where c.segment1 = var_item.bar_code_num
             and c.organization_id = 84;
        exception
          when others then
            v_status        := 'E';
            v_error_message := '获取失败';
        end;
        ------------ATTRIBUTE12,
        begin
          select c.attribute12
            into v_attribute12
            from mtl_system_items_b c
           where c.segment1 = var_item.bar_code_num
             and c.organization_id = 84;
        exception
          when others then
            v_status        := 'E';
            v_error_message := '获取失败';
        end;
        ------------ATTRIBUTE13,
        begin
          select c.attribute13
            into v_attribute13
            from mtl_system_items_b c
           where c.segment1 = var_item.bar_code_num
             and c.organization_id = 84;
        exception
          when others then
            v_status        := 'E';
            v_error_message := '获取失败';
        end;
        ------------ATTRIBUTE14,
        begin
          select flv.LOOKUP_CODE
            into v_attribute14
            from fnd_lookup_values_vl flv
           where flv.MEANING = var_item.item_type_3
             and flv.LOOKUP_TYPE = 'CUX_ITEM_TYPE_3'
             and flv.ENABLED_FLAG(+) = 'Y';
        exception
          when others then
            v_status        := 'E';
            v_error_message := '获取产品分类3失败';
        end;
        ------------ATTRIBUTE15,
        begin
          select flv.LOOKUP_CODE
            into v_attribute15
            from fnd_lookup_values_vl flv
           where flv.MEANING = var_item.packaging
             and flv.LOOKUP_TYPE = 'CUX_PACKAGING'
             and flv.ENABLED_FLAG(+) = 'Y';
        exception
          when others then
            v_status        := 'E';
            v_error_message := '获取包装物失败';
        end;
        ------------ATTRIBUTE16,
      
        ------------ATTRIBUTE17,
      
        ------------ATTRIBUTE18,
      
        ------------ATTRIBUTE19,
      
        ------------ATTRIBUTE20
      
        begin
          select flv.LOOKUP_CODE
            into v_attribute20
            from fnd_lookup_values_vl flv
           where flv.MEANING = var_item.manufacturer
             and flv.LOOKUP_TYPE = 'CUX_MANUFACTURER'
             and flv.ENABLED_FLAG(+) = 'Y';
        exception
          when others then
            v_status        := 'E';
            v_error_message := '获取生产商信息失败';
        end;
        ----------
      
        ----- mtl_system_items_b_ext_s 
        -----attrib_03
        begin
          select flv.LOOKUP_CODE
            into v_attrib_03
            from fnd_lookup_values_vl flv
           where flv.MEANING = var_item.SERIES_NAME
             and flv.LOOKUP_TYPE = 'CUX_ITEM_SERIES'
             and flv.ENABLED_FLAG(+) = 'Y';
        exception
          when others then
            v_status        := 'E';
            v_error_message := '获取失败';
        end;
        -----
        if v_status = 'Y' then
          insert into mtl_system_items_b_ext
            (ITEM_ID,
             NAME,
             ITEM_NAME,
             ALIAS_NAME,
             BAR_CODE_NUM,
             REF_NUMBER_1,
             REF_NUMBER_3,
             UOM_CD,
             MTTR_UOM_CD,
             ACCRUAL_RATE,
             ACTIVE_FLAG,
             MAKE_CD,
             BODY_STYLE_CD,
             QUALITY_CD,
             TYPE,
             SUB_TYPE_CD,
             YN_SUB_TYPE_CD,
             ITEM_SIZE,
             LOAD_ADDED,
             ITEM_TAX_ITEM,
             ATTRIBUTE1,
             ATTRIBUTE2,
             ATTRIBUTE3,
             ATTRIBUTE4,
             ATTRIBUTE5,
             ATTRIBUTE6,
             ATTRIBUTE7,
             ATTRIBUTE8,
             ATTRIBUTE9,
             ATTRIBUTE10,
             CREATION_DATE,
             CREATED_BY,
             LAST_UPDATE_DATE,
             LAST_UPDATED_BY,
             LAST_UPDATE_LOGIN,
             org_id,
             ATTRIBUTE11,
             ATTRIBUTE12,
             ATTRIBUTE13,
             ATTRIBUTE14,
             ATTRIBUTE15,
             ATTRIBUTE16,
             ATTRIBUTE17,
             ATTRIBUTE18,
             ATTRIBUTE19,
             ATTRIBUTE20)
          values
            (v_item_id,
             var_item.NAME,
             var_item.ITEM_NAME,
             var_item.ALIAS_NAME,
             var_item.BAR_CODE_NUM,
             var_item.REF_NUMBER_1,
             var_item.REF_NUMBER_3,
             var_item.UOM_CD,
             '箱',
             var_item.ACCRUAL_RATE,
             var_item.ACTIVE_FLAG,
             v_make_cd,
             v_body_style_cd,
             v_quality_cd,
             v_type,
             v_sub_type_cd,
             v_yn_sub_type_cd,
             var_item.ITEM_SIZE,
             v_load_added,
             var_item.ITEM_TAX_ITEM,
             var_item.ATTRIBUTE1,
             var_item.ATTRIBUTE2,
             var_item.ATTRIBUTE3,
             var_item.ATTRIBUTE4,
             var_item.ATTRIBUTE5,
             v_attribute6,
             var_item.ATTRIBUTE7,
             v_attribute8,
             v_attribute9,
             v_attribute10,
             sysdate,
             -1,
             sysdate,
             -1,
             -1,
             g_org_id,
             var_item.attribute11,
             var_item.attribute12,
             v_attribute13,
             v_attribute14,
             v_attribute15,
             var_item.attribute16,
             var_item.attribute17,
             var_item.attribute18,
             var_item.attribute19,
             v_attribute20);
          insert into mtl_system_items_b_ext_s
            (item_id,
             ATTRIB_01,
             ATTRIB_03,
             ATTRIB_14,
             ATTRIB_15,
             ATTRIB_16,
             org_id)
          values
            (v_item_id,
             null, ---零只规格
             null,
             null,
             null,
             null,
             g_org_id);
          update cux_item_temp cit
             set cit.status = 'Y', cit.error_message = '正确'
           where cit.bar_code_num = var_item.bar_code_num;
        else
          update cux_item_temp cit
             set cit.status = v_status, cit.error_message = v_error_message
           where cit.bar_code_num = var_item.bar_code_num;
        end if;
      exception
        when others then
          rollback;
      end;
    end loop;
  end;
  procedure crete_ass is
    cursor cur_item is
      select * from cux_item_temp msi where msi.status = 'Y';
    var_item          cur_item%rowtype;
    l_item_rec        sy_inv_item_grp.item_rec_type;
    l_exists          number := 0; --* Added for Bug 5207014
    l_operating_unit  NUMBER; /* Added for fixing bug 6804003*/
    x_item_rec        sy_inv_item_grp.item_rec_type;
    x_return_stauts   VARCHAR2(1);
    p_error_tbl       sy_inv_item_grp.Error_Tbl_Type;
    l_set_of_books_id number;
    l_exp exception;
    l_segment1      varchar2(50);
    v_ccid          number;
    v_item_id       number;
    v_status        varchar2(10) := 'Y';
    v_error_message varchar2(1000);
  begin
    begin
      select hou.set_of_books_id
        into l_set_of_books_id
        from hr_operating_units hou
       where hou.organization_id = g_org_id;
    exception
      when others then
        l_set_of_books_id := null;
    end;
    for var_item in cur_item loop
      ----获取物料ID
      begin
        select msi.inventory_item_id
          into v_item_id
          from mtl_system_items_b msi
         where msi.segment1 = var_item.bar_code_num
           and msi.organization_id = 84;
      exception
        when others then
          v_status        := 'E';
          v_error_message := '获取物料信息失败';
      end;
      l_item_rec.inventory_item_id       := v_item_id;
      l_item_rec.organization_id         := g_organization_id;
      l_item_rec.primary_uom_code        := var_item.uom_cd;
      l_item_rec.dual_uom_deviation_high := 0;
      l_item_rec.dual_uom_deviation_low  := 0;
      IF var_item.item_tax_item = 13 THEN
        l_item_rec.TAX_CODE := '增值税销项税13%';
      ELSIF var_item.item_tax_item = 17 THEN
        l_item_rec.TAX_CODE := '增值税销项税17%';
      ELSIF var_item.item_tax_item = 11 THEN
        l_item_rec.TAX_CODE := '增值税销项税11%';
      END IF;
    
      if substr(var_item.bar_code_num, 1, 1) = 9 then
        l_Item_Rec.LOT_CONTROL_CODE := 2;
      else
        l_Item_Rec.LOT_CONTROL_CODE := 1;
      end if;
      l_Item_Rec.SHELF_LIFE_CODE            := 1;
      l_Item_Rec.SERIAL_NUMBER_CONTROL_CODE := 1;
      l_Item_Rec.LOCATION_CONTROL_CODE      := 1;
      l_Item_Rec.LOT_STATUS_ENABLED         := 'N';
      l_Item_Rec.AUTO_LOT_ALPHA_PREFIX      := null;
      l_Item_Rec.START_AUTO_LOT_NUMBER      := null;
      --l_Item_Rec.LOT_SPLIT_ENABLED            := 'N';
      --l_Item_Rec.LOT_DIVISIBLE_FLAG           := 'N';
      if substr(var_item.bar_code_num, 1, 1) = 9 then
        l_Item_Rec.LOT_SPLIT_ENABLED  := 'Y';
        l_Item_Rec.LOT_DIVISIBLE_FLAG := 'Y';
      else
        l_Item_Rec.LOT_SPLIT_ENABLED  := 'N';
        l_Item_Rec.LOT_DIVISIBLE_FLAG := 'N';
      end if;
      l_Item_Rec.LOT_TRANSLATE_ENABLED := 'N';
      l_Item_Rec.LOT_MERGE_ENABLED     := 'N';
    
      l_Item_Rec.LOT_SUBSTITUTION_ENABLED := null;
      l_Item_Rec.DEFAULT_LOT_STATUS_ID    := null;
      if substr(var_item.bar_code_num, 1, 1) = 9 then
        v_ccid := get_ccid(p_set_of_books_id => l_set_of_books_id,
                           p_gl_date         => trunc(sysdate),
                           p_segment_name1   => 'COM',
                           p_segment1        => l_segment1,
                           p_segment_name2   => 'DEP',
                           p_segment2        => '0000',
                           p_segment_name3   => 'ACC',
                           p_segment3        => '6401010000',
                           p_segment_name4   => 'SUB',
                           p_segment4        => '00000000',
                           p_segment_name5   => 'INTER',
                           p_segment5        => '0000',
                           p_segment_name6   => 'CA',
                           p_segment6        => '000000',
                           p_segment_name7   => 'PROD',
                           p_segment7        => var_item.bar_code_num,
                           p_segment_name8   => 'PROJECT',
                           p_segment8        => '0000',
                           p_segment_name9   => 'FUTURE',
                           p_segment9        => '0');
      else
        if g_org_id in (532, 552, 572) then
          --SHSY%
          v_ccid := get_ccid(p_set_of_books_id => l_set_of_books_id,
                             p_gl_date         => trunc(sysdate),
                             p_segment_name1   => 'COM',
                             p_segment1        => l_segment1,
                             p_segment_name2   => 'DEP',
                             p_segment2        => '0000',
                             p_segment_name3   => 'ACC',
                             p_segment3        => '6402030000',
                             p_segment_name4   => 'SUB',
                             p_segment4        => '00000000',
                             p_segment_name5   => 'INTER',
                             p_segment5        => '0000',
                             p_segment_name6   => 'CA',
                             p_segment6        => '000000',
                             p_segment_name7   => 'PROD',
                             p_segment7        => var_item.bar_code_num,
                             p_segment_name8   => 'PROJECT',
                             p_segment8        => '0000',
                             p_segment_name9   => 'FUTURE',
                             p_segment9        => '0');
        else
          v_ccid := get_ccid(p_set_of_books_id => l_set_of_books_id,
                             p_gl_date         => trunc(sysdate),
                             p_segment_name1   => 'COM',
                             p_segment1        => l_segment1,
                             p_segment_name2   => 'DEP',
                             p_segment2        => '0000',
                             p_segment_name3   => 'ACC',
                             p_segment3        => '6402800000',
                             p_segment_name4   => 'SUB',
                             p_segment4        => '00000000',
                             p_segment_name5   => 'INTER',
                             p_segment5        => '0000',
                             p_segment_name6   => 'CA',
                             p_segment6        => '000000',
                             p_segment_name7   => 'PROD',
                             p_segment7        => var_item.bar_code_num,
                             p_segment_name8   => 'PROJECT',
                             p_segment8        => '0000',
                             p_segment_name9   => 'FUTURE',
                             p_segment9        => '0');
        end if;
      end if;
      if v_ccid = -1 then
        update cux_item_temp cit
           set cit.status = 'EO', cit.error_message = '创建会计科目失败'
         where cit.bar_code_num = var_item.bar_code_num;
        continue;
      else
        l_Item_Rec.COST_OF_SALES_ACCOUNT := v_ccid;
      end if;
      if substr(var_item.bar_code_num, 1, 1) = 9 then
        v_ccid := get_ccid(p_set_of_books_id => l_set_of_books_id,
                           p_gl_date         => trunc(sysdate),
                           p_segment_name1   => 'COM',
                           p_segment1        => l_segment1,
                           p_segment_name2   => 'DEP',
                           p_segment2        => '0000',
                           p_segment_name3   => 'ACC',
                           p_segment3        => '6001010000',
                           p_segment_name4   => 'SUB',
                           p_segment4        => '00000000',
                           p_segment_name5   => 'INTER',
                           p_segment5        => '0000',
                           p_segment_name6   => 'CA',
                           p_segment6        => '000000',
                           p_segment_name7   => 'PROD',
                           p_segment7        => var_item.bar_code_num,
                           p_segment_name8   => 'PROJECT',
                           p_segment8        => '0000',
                           p_segment_name9   => 'FUTURE',
                           p_segment9        => '0');
      else
        if g_org_id in (532, 552, 572) then
          v_ccid := get_ccid(p_set_of_books_id => l_set_of_books_id,
                             p_gl_date         => trunc(sysdate),
                             p_segment_name1   => 'COM',
                             p_segment1        => l_segment1,
                             p_segment_name2   => 'DEP',
                             p_segment2        => '0000',
                             p_segment_name3   => 'ACC',
                             p_segment3        => '6051030000',
                             p_segment_name4   => 'SUB',
                             p_segment4        => '00000000',
                             p_segment_name5   => 'INTER',
                             p_segment5        => '0000',
                             p_segment_name6   => 'CA',
                             p_segment6        => '000000',
                             p_segment_name7   => 'PROD',
                             p_segment7        => var_item.bar_code_num,
                             p_segment_name8   => 'PROJECT',
                             p_segment8        => '0000',
                             p_segment_name9   => 'FUTURE',
                             p_segment9        => '0');
        else
          v_ccid := get_ccid(p_set_of_books_id => l_set_of_books_id,
                             p_gl_date         => trunc(sysdate),
                             p_segment_name1   => 'COM',
                             p_segment1        => l_segment1,
                             p_segment_name2   => 'DEP',
                             p_segment2        => '0000',
                             p_segment_name3   => 'ACC',
                             p_segment3        => '6051800000',
                             p_segment_name4   => 'SUB',
                             p_segment4        => '00000000',
                             p_segment_name5   => 'INTER',
                             p_segment5        => '0000',
                             p_segment_name6   => 'CA',
                             p_segment6        => '000000',
                             p_segment_name7   => 'PROD',
                             p_segment7        => var_item.bar_code_num,
                             p_segment_name8   => 'PROJECT',
                             p_segment8        => '0000',
                             p_segment_name9   => 'FUTURE',
                             p_segment9        => '0');
        end if;
      
      end if;
      if v_ccid = -1 then
        update cux_item_temp cit
           set cit.status = 'EO', cit.error_message = '创建会计科目失败'
         where cit.bar_code_num = var_item.bar_code_num;
        continue;
      else
        l_Item_Rec.SALES_ACCOUNT := v_ccid;
      end if;
      --Begin Bug 7235525 vggarg. Set dual_uom_control.
      SELECT 1 INTO l_Item_Rec.DUAL_UOM_CONTROL FROM DUAL;
    
      l_item_rec.creation_date    := sysdate;
      l_item_rec.last_update_date := sysdate;
    
      l_item_rec.created_by      := -1;
      l_item_rec.last_updated_by := -1;
    
      sy_inv_item_grp.create_item(p_item_rec      => l_item_rec,
                                  x_item_rec      => x_item_rec,
                                  x_return_status => x_return_stauts,
                                  x_error_tbl     => p_error_tbl,
                                  p_template_name => null);
    
      if x_return_stauts = 'S' then
        insert into cux_org_assign_t
          (assign_id,
           inventory_item_id,
           organization_id,
           CREATION_DATE,
           LAST_UPDATED_BY,
           LAST_UPDATE_DATE,
           LAST_UPDATE_LOGIN,
           CREATED_BY)
        values
          (cux_org_assign_s.nextval,
           v_item_id,
           g_organization_id,
           sysdate,
           -1,
           sysdate,
           -1,
           -1);
      
        update mtl_system_items_b msib
           set msib.attribute3 = v_item_id
         where msib.inventory_item_id = v_item_id
           and msib.organization_id = g_organization_id;
      
        update cux_item_temp cit
           set cit.status = 'YO', cit.error_message = '分配成功！'
         where cit.bar_code_num = var_item.bar_code_num;
      else
        update cux_item_temp cit
           set cit.status        = 'EO',
               cit.error_message = '写入分配表信息失败！'
         where cit.bar_code_num = var_item.bar_code_num;
        return;
      end if;
      commit;
    end loop;
  end;
  procedure load_cars is
    v_status        varchar2(10) := 'Y';
    v_error_message varchar2(1000);
    cursor cur_cars is
      select distinct car_dao_code, car_dao_name from cux_car_temp;
    cursor cur_cars_line(cardaocode varchar2) is
      select * from cux_car_temp where car_dao_code = cardaocode;
    header_temp number;
  begin
    for CARS_HEADER in cur_cars loop
      if v_status = 'Y' then
        SELECT CUX_CARS_INFORMATION_HEADER_S.NEXTVAL
          INTO header_temp
          FROM DUAL;
        INSERT INTO CUX_CARS_INFORMATION_HEADER
          (header_id,
           ORG_ID,
           organization_id,
           Car_dao_code,
           Car_dao_name,
           CAR_DAO_STATUS,
           CREATED_BY,
           CREATION_DATE,
           LAST_UPDATED_BY,
           LAST_UPDATE_DATE,
           last_update_login)
        VALUES
          (header_temp,
           g_org_id,
           g_organization_id,
           CARS_HEADER.Car_DAO_CODE,
           CARS_HEADER.Car_DAO_NAME,
           'Y',
           -1,
           sysdate,
           -1,
           sysdate,
           111);
        update cux_car_temp cit
           set cit.status = 'Y', cit.error_message = '正确'
         where cit.car_ci_code = CARS_HEADER.Car_dao_code;
      else
        update cux_car_temp cit
           set cit.status = 'N', cit.error_message = '错误'
         where cit.car_ci_code = CARS_HEADER.Car_dao_code;
      end if;
      for CARS_LINE in cur_cars_line(CARS_HEADER.Car_DAO_CODE) loop
        if v_status = 'Y' then
          INSERT INTO CUX_CARS_INFORMATION_LINE
            (line_id,
             header_id,
             Car_ci_code,
             Car_ci_name,
             Car_number,
             car_ci_status,
             CREATED_BY,
             CREATION_DATE,
             LAST_UPDATED_BY,
             LAST_UPDATE_DATE,
             last_update_login)
          VALUES
            (CUX_CARS_INFORMATION_LINE_S.NEXTVAL,
             header_temp,
             CARS_LINE.Car_ci_code,
             CARS_LINE.Car_ci_name,
             CARS_LINE.CAR_NUMBER,
             'Y',
             -1,
             sysdate,
             -1,
             sysdate,
             111);
          update cux_car_temp cit
             set cit.status = 'Y', cit.error_message = '正确'
           where cit.car_ci_code = CARS_LINE.Car_ci_code;
        else
          update cux_car_temp cit
             set cit.status = 'N', cit.error_message = '错误'
           where cit.car_ci_code = CARS_LINE.Car_ci_code;
        end if;
      end loop;
    end loop;
  end;
end cux_o2o_basic_data_pkg;
/

