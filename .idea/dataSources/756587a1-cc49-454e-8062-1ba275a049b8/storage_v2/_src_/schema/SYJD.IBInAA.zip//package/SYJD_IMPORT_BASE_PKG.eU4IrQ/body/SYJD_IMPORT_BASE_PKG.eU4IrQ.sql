create package body syjd_import_base_pkg is
  procedure import_base_data(p_base_type varchar2) is
  begin
    if p_base_type = 'item' then
      import_item;
    elsif p_base_type = 'price' then
      import_price;
    end if;
  end;
  procedure import_item is
    cursor cur_item is
      select * from mtl_system_items_temp msi where msi.operate_flag = 'N';
    var_item     cur_item%rowtype;
    v_product_id number;
		v_cnt        number;
    v_message    varchar2(200);
  begin
    for var_item in cur_item loop
      begin
				select count(1)
				into v_cnt
				from product prd
				where prd.sn = var_item.segment1;
				if v_cnt = 0 then
					 select get_primary_id('PRODUCT') into v_product_id from dual;
        insert into product
          (id,
           erp_item_id,
           name,
           erp_number,
           unit,
           tax,
           lastmodifieddate,
           last_updated_by,
           createddate,
           version,
           hits,
           isactive,
           ISDELIVERY,
           ISLIST,
           ISMARKETABLE,
           ISTOP,
           MARKETPRICE,
           MONTHHITS,
           MONTHHITSDATE,
           MONTHSALES,
           MONTHSALESDATE,
           PRICE,
           SALES,
           SCORE,
           SCORECOUNT,
           SN,
           TOTALSCORE,
           TYPE,
           WEEKHITS,
           WEEKHITSDATE,
           WEEKSALES,
           WEEKSALESDATE,
           PRODUCTCATEGORY_ID,
           STORE_ID,
           ERP_ITEM_NAME,
           ABBREVIATION,
           QRNAME)
        values
          (v_product_id,
           var_item.inventory_item_id,
           var_item.description,
           var_item.segment1,
           var_item.primary_uom_code,
           var_item.tax_code,
           var_item.last_update_date,
           var_item.last_updated_by,
           var_item.creation_date,
           '0',
           '0',
           '1',
           '0',
           '0',
           '0',
           '0',
           '0',
           '0',
           sysdate,
           '0',
           sysdate,
           '0',
           '0',
           '1.0',
           '0',
           var_item.segment1,
           '0',
           '0',
           '0',
           sysdate,
           '0',
           sysdate,
           '251',
           '51',
           var_item.description,
           var_item.abbreviation,
           var_item.qrname);

           INSERT INTO SKU
           (ID,
           CREATEDDATE,
           LASTMODIFIEDDATE,
           VERSION,
           ALLOCATEDSTOCK,
           COST,
           EXCHANGEPOINT,
           ISDEFAULT,
           MARKETPRICE,
           PRICE,
           REWARDPOINT,
           SN,
           SPECIFICATIONVALUES,
           STOCK,
           PRODUCT_ID,
           LAST_UPDATED_BY)VALUES
           (get_primary_id('SKU'),
           SYSDATE,
           SYSDATE,
           1,
           1,
           0,
           0,
           1,
           0,
           0,
           0,
           var_item.segment1,
           0,
           0,
           v_product_id,
           203);
					 
				else
				   update product prd
					 set prd.name = var_item.description,
					 prd.tax = var_item.tax_code,
					 prd.unit = var_item.primary_uom_code,
					 prd.last_update_date = sysdate,
					 prd.erp_item_name = var_item.description,
					 prd.abbreviation = var_item.abbreviation,
					 prd.qrname = var_item.qrname
					 where prd.sn = var_item.segment1;
				end if;
       
        update mtl_system_items_temp msi
           set msi.operate_flag = 'Y'
         where msi.inventory_item_id = var_item.inventory_item_id
           and msi.organization_id = var_item.organization_id;
      exception
        when others then
          v_message := '错误信息：' || sqlerrm;
          update mtl_system_items_temp msi
             set msi.operate_flag = 'E', msi.error_message = v_message
           where msi.inventory_item_id = var_item.inventory_item_id
             and msi.organization_id = var_item.organization_id;
      end;
      commit;
    end loop;
  end;
  procedure import_price is
    cursor cur_header is
      select * from p_secu_list_headers_temp h where h.operate_flag = 'N';
    cursor cur_line is
      select * from qp_list_lines_temp l where l.operate_flag = 'N';
    var_header cur_header%rowtype;
    var_line   cur_line%rowtype;
    h_message  varchar2(200);
    l_message  varchar2(200);
    h_count    number(10);
    l_count    number(10);
  begin
    for var_header in cur_header loop
      begin
        select count(1)
          into h_count
          from price_list_headers
         where id = var_header.id;
        if (h_count > 0) then
          update price_list_headers
             set id               = var_header.id,
                 price_name       = var_header.price_name,
                 note             = var_header.note,
                 currence_code    = var_header.currence_code,
                 start_date       = var_header.start_date,
                 end_date         = var_header.end_date,
                 status           = var_header.status,
                 last_update_date = var_header.last_update_date,
                 last_updated_by  = var_header.last_updated_by,
                 creation_date    = var_header.creation_date,
                 created_by       = var_header.created_by,
                 price_desc       = var_header.price_desc
           where id = var_header.id;
          update p_secu_list_headers_temp h
             set h.operate_flag = 'Y'
           where h.id = var_header.id;
        else
          insert into price_list_headers
            (id,
             price_name,
             note,
             currence_code,
             start_date,
             end_date,
             status,
             last_update_date,
             last_updated_by,
             creation_date,
             created_by,
             price_desc,
             source)
          values
            (var_header.id,
             var_header.price_name,
             var_header.note,
             var_header.currence_code,
             var_header.start_date,
             var_header.end_date,
             'VALID',
             var_header.last_update_date,
             var_header.last_updated_by,
             var_header.creation_date,
             var_header.created_by,
             var_header.price_desc,
             'ERP');
          update p_secu_list_headers_temp h
             set h.operate_flag = 'Y'
           where h.id = var_header.id;
        end if;
      exception
        when others then
          h_message := '错误信息：' || sqlerrm;
          update p_secu_list_headers_temp h
             set h.operate_flag = 'E', h.error_message = h_message
           where h.id = var_header.id;
      end;
    end loop;
    for var_line in cur_line loop
      begin
        select count(1)
          into l_count
          from price_list_lines
         where id = var_line.id;
        if (l_count > 0) then
          update price_list_lines
             set id               = var_line.id,
                 header_id        = var_line.header_id,
                 product_id       = (select id from product where erp_item_id = var_line.product_id),
                 price_zd         = var_line.price_zd,
                 price_cc         = var_line.price_cc,
                 price_pf         = var_line.price_pf,
                 price_nz         = var_line.price_nz,
                 start_date       = var_line.start_date,
                 end_date         = var_line.end_date,
                 status           = var_line.status,
                 last_update_date = var_line.last_update_date,
                 last_updated_by  = var_line.last_updated_by,
                 creation_date    = var_line.creation_date,
                 created_by       = var_line.created_by,
                 unit             = var_line.unit,
                 product_name     = var_line.product_name
           where id = var_line.id;
          update qp_list_lines_temp l
             set l.operate_flag = 'Y'
           where l.id = var_line.id;
        else
          insert into price_list_lines
            (id,
             header_id,
             product_id,
             price_zd,
             price_cc,
             price_pf,
             price_nz,
             start_date,
             end_date,
             status,
             last_update_date,
             last_updated_by,
             creation_date,
             created_by,
             unit,
             product_name)
          values
            (var_line.id,
             var_line.header_id,
             (select id from product where erp_item_id= var_line.product_id),
             var_line.price_zd,
             var_line.price_cc,
             var_line.price_pf,
             var_line.price_nz,
             var_line.start_date,
             var_line.end_date,
             var_line.status,
             var_line.last_update_date,
             var_line.last_updated_by,
             var_line.creation_date,
             var_line.created_by,
             var_line.unit,
             var_line.product_name);
          update qp_list_lines_temp l
             set l.operate_flag = 'Y'
           where l.id = var_line.id;
        end if;
      exception
        when others then
          l_message := '错误信息：' || sqlerrm;
          update qp_list_lines_temp l
             set l.operate_flag = 'E', l.error_message = l_message
           where l.id = var_line.id;
      end;
    end loop;
    commit;
  end;
   procedure import_price_header(p_header_id number)is
   cursor cur_header is
      select * from p_secu_list_headers_temp h 
      where h.operate_flag = 'N'
      and h.id=p_header_id;
   
    var_header cur_header%rowtype;
    h_message  varchar2(200);
    l_message  varchar2(200);
    h_count    number(10);
    l_count    number(10);
  begin
    for var_header in cur_header loop
      begin
        select count(1)
          into h_count
          from price_list_headers
         where id = var_header.id;
        if (h_count > 0) then
          update price_list_headers
             set id               = var_header.id,
                 price_name       = var_header.price_name,
                 note             = var_header.note,
                 currence_code    = var_header.currence_code,
                 start_date       = var_header.start_date,
                 end_date         = var_header.end_date,
                 status           = var_header.status,
                 last_update_date = var_header.last_update_date,
                 last_updated_by  = var_header.last_updated_by,
                 creation_date    = var_header.creation_date,
                 created_by       = var_header.created_by,
                 price_desc       = var_header.price_desc
           where id = var_header.id;
          update p_secu_list_headers_temp h
             set h.operate_flag = 'Y'
           where h.id = var_header.id;
        else
          insert into price_list_headers
            (id,
             price_name,
             note,
             currence_code,
             start_date,
             end_date,
             status,
             last_update_date,
             last_updated_by,
             creation_date,
             created_by,
             price_desc,
             source)
          values
            (var_header.id,
             var_header.price_name,
             var_header.note,
             var_header.currence_code,
             var_header.start_date,
             var_header.end_date,
             'VALID',
             var_header.last_update_date,
             var_header.last_updated_by,
             var_header.creation_date,
             var_header.created_by,
             var_header.price_desc,
             'ERP');
          update p_secu_list_headers_temp h
             set h.operate_flag = 'Y'
           where h.id = var_header.id;
        end if;
      exception
        when others then
          h_message := '错误信息：' || sqlerrm;
          update p_secu_list_headers_temp h
             set h.operate_flag = 'E', h.error_message = h_message
           where h.id = var_header.id;
      end;
      commit;
    end loop;
    end;
    procedure import_price_line(p_line_id number)is
      
    cursor cur_line is
      select * from qp_list_lines_temp l 
      where l.operate_flag = 'N'
      and l.id=p_line_id;
    var_line   cur_line%rowtype;
    h_message  varchar2(200);
    l_message  varchar2(200);
    h_count    number(10);
    l_count    number(10);
  begin
     for var_line in cur_line loop
      begin
        select count(1)
          into l_count
          from price_list_lines
         where id = var_line.id;
        if (l_count > 0) then
          update price_list_lines
             set id               = var_line.id,
                 header_id        = var_line.header_id,
                 product_id       = (select id from product where erp_item_id = var_line.product_id),
                 price_zd         = var_line.price_zd,
                 price_cc         = var_line.price_cc,
                 price_pf         = var_line.price_pf,
                 price_nz         = var_line.price_nz,
                 start_date       = var_line.start_date,
                 end_date         = var_line.end_date,
                 status           = var_line.status,
                 last_update_date = var_line.last_update_date,
                 last_updated_by  = var_line.last_updated_by,
                 creation_date    = var_line.creation_date,
                 created_by       = var_line.created_by,
                 unit             = var_line.unit,
                 product_name     = var_line.product_name
           where id = var_line.id;
          update qp_list_lines_temp l
             set l.operate_flag = 'Y'
           where l.id = var_line.id;
        else
          insert into price_list_lines
            (id,
             header_id,
             product_id,
             price_zd,
             price_cc,
             price_pf,
             price_nz,
             start_date,
             end_date,
             status,
             last_update_date,
             last_updated_by,
             creation_date,
             created_by,
             unit,
             product_name)
          values
            (var_line.id,
             var_line.header_id,
             (select id from product where erp_item_id= var_line.product_id),
             var_line.price_zd,
             var_line.price_cc,
             var_line.price_pf,
             var_line.price_nz,
             var_line.start_date,
             var_line.end_date,
             var_line.status,
             var_line.last_update_date,
             var_line.last_updated_by,
             var_line.creation_date,
             var_line.created_by,
             var_line.unit,
             var_line.product_name);
          update qp_list_lines_temp l
             set l.operate_flag = 'Y'
           where l.id = var_line.id;
        end if;
      exception
        when others then
          l_message := '错误信息：' || sqlerrm;
          update qp_list_lines_temp l
             set l.operate_flag = 'E', l.error_message = l_message
           where l.id = var_line.id;
      end;
      commit;
    end loop;  
    end;
end syjd_import_base_pkg;
/

