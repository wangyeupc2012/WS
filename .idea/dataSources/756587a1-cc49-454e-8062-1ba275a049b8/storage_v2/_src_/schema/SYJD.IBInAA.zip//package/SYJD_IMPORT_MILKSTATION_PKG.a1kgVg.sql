create PACKAGE syjd_import_milkstation_pkg IS

  --导入奶站
  PROCEDURE syjd_import_milkstation;

  --插入用户 分配权限
  procedure insert_fnd_users(p_mobilephone    in varchar2,
                             p_name           in varchar2,
                             p_milkstation_id in number);
  --导入经销商
  /*PROCEDURE syjd_import_DEALER;*/

  --奶站关联线上经销商
  PROCEDURE dealers_for_milkstation;
  
  --从中间表导入POI
  procedure import_poi;

END syjd_import_milkstation_pkg;
/

