create package CRM_ORDER_EXCEL_IMPORT_PKG is

  -- Author  : WANGYE
  -- Created : 2017/10/13 10:21:09
  -- Purpose : CRM_ORDER_EXCEL_IMPORT_PKG

  --校验数据是否规范
  procedure check_data_validate(p_batch_id            in number,
                                p_check_flag          out varchar2,
                                p_check_error_message out varchar2);

  --数据合并
  procedure merge_data(p_batch_id            in number,
                       p_merge_flag          out varchar2,
                       p_merge_error_message out varchar2);

  --导入正式表
  procedure import_into_orders(p_batch_id             in number,
                               p_insert_flag          out varchar2,
                               p_insert_error_message out varchar2);
                               
   --导入正式表
  procedure import_orders(p_batch_id             in number,
                          p_insert_flag          out varchar2,
                          p_insert_error_message out varchar2);                              

  function  check_order_validate(p_batch_id            in number,
                                 p_order               in varchar2)return varchar2;
-- procedure main;

end CRM_ORDER_EXCEL_IMPORT_PKG;
/

