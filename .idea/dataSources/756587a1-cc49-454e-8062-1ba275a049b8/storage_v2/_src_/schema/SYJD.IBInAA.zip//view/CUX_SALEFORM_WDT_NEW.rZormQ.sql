create view CUX_SALEFORM_WDT_NEW as
  SELECT
cov.order_number,
cov.dealers_id,
cov.dealers_name,
----经销商名字
cov.item_name,
----物料名称
sum(
decode(kcot.rec_type,'OLD_REC',kcot.quantity,null,

(SELECT oot.quantity
FROM orderitem oot
WHERE oot.id = cov.order_line_id
AND
(
(oot.pay_price <> 0 and oot.price<>0)or

(oot.pay_price <> 0 and oot.price=0)or

(oot.pay_price =0 and oot.price<>0)
)
))
) recequantity,
--应收销售数量
sum(
decode(kcot.rec_type,'OLD_REC',kcot.price *kcot.order_days*kcot.DAILY_order_QUANTITY,null,cov.price *cov.order_days*cov.DAILY_DELIVERY_QUANTITY)
) recemoney,
--应收金额
sum(
decode(kcot.rec_type,'OLD_REC',kcot.totalprice,null,cov.totalprice)
) realmoney,
--实收金额
sum(
(SELECT sum(orfit.quantity)
FROM ORDERREFUNDS orf, ORDERREFUNDSITEM orfit
WHERE orf.sn = cov.order_number
AND orfit.orderrefunds = orf.id
AND orfit.sn = cov.item_number
AND cov.order_line_id =orfit.orderitem_id
AND cov.refund_status = 5
AND orf.status = 'REFUNDED'
)
) recesalequantity,
--应退销售数量
sum((SELECT sum(orfit.price*orfit.quantity)
FROM ORDERREFUNDS orf, ORDERREFUNDSITEM orfit
WHERE orf.sn = cov.order_number
AND orfit.orderrefunds = orf.id
AND orfit.sn = cov.item_number
AND cov.order_line_id =orfit.orderitem_id
AND cov.refund_status = 5
AND orf.status = 'REFUNDED')) recerefundmoney,
--应退
sum(
(SELECT sum(nvl(orfit.ACT_PRICE,orfit.amount))
FROM ORDERREFUNDS orf, ORDERREFUNDSITEM orfit
WHERE orf.sn = cov.order_number
AND orfit.orderrefunds = orf.id
AND orfit.sn = cov.item_number
AND cov.order_line_id =orfit.orderitem_id
AND cov.refund_status = 5
AND orf.status = 'REFUNDED'
)
) realrefundmoney,
--实退
sum((SELECT oot.quantity
FROM orderitem oot
WHERE oot.id = cov.order_line_id
AND oot.pay_price = 0
AND oot.refund_status <> 5)) giftquantity
--赠品数量
FROM cux_order_all_info_v cov,kuayue_change_orderitem kcot
WHERE cov.status IN (2, 5, 10)
and cov.wdtorderitemid=kcot.wdtorderitemid(+)
AND cov.type  IN (0)--可选
--AND cov.order_number NOT LIKE 'SY%'--可选
AND cov.order_from = 'WECHAT'
AND (cov.source = 'ONLINE' or cov.source is null)
--and cov.order_number in （'JD20180828163117036156','JD20180828163257098954')
--and cov.order_number ='JD20180828164934014784'
--and cov.order_number ='JD20180828163257098954'
---and cov.dealers_id='xxx' 经销商
---and cov.milk_station_id='xxx' 奶站
-- and cov.order_from ='xxx' 订单来源
-- and cov.type='xxx' ------ 订单类型
--and cov.order_number='JD20180616163931027725'
--and cov.milk_station_id is null
--AND trunc(cov.createddate) BETWEEN
--trunc(to_date('2018-07-01', 'yyyy-mm-dd')) AND
--trunc(to_date('2018-07-31', 'yyyy-mm-dd'))
GROUP BY cov.dealers_id,cov.
dealers_name, ----经销商名字
cov.item_name,----物料名称
cov.order_number
/

