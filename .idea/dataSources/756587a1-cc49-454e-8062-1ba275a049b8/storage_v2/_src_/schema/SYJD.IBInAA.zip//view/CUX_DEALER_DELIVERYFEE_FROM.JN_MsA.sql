create view CUX_DEALER_DELIVERYFEE_FROM as
  SELECT d.DEALERS_CODE,
       d.DEALERS_NAME,
       ms.MILK_STATION_NAME,
       p.sn,
       p.qrname,
       sum(osi.QUANTITY) shipping_quantity,
       plh.id PRICE_ID,
       plh.PRICE_NAME,
       pll.PRICE_ZD,
       sum(PL.QUANTITY * (nvl(pll.MILK_STATION_SHIPPING_FEE, 0) +
           nvl(pll.DEALERS_SHIPPING_FEE, 0) +
           nvl(pll.MS_COURIER_SHIPPING_FEE, 0))) shipping_price,
       nvl(ot.PRICE, 0) PRICE,
       nvl(ot.PAY_PRICE, 0) PAY_PRICE,
       os.SHIPPING_DATE,
       flv.ATTRIBUTE1 order_type,
       sum((SELECT DISTINCT osi.QUANTITY
             FROM ORDERSHIPPINGITEM osi1,
                  ORDERS            od1,
                  ORDERITEM         ot1,
                  ORDERSHIPPING     os1
            WHERE ot1.ORDERS = od1.id
              AND os.ID = osi1.ORDERSHIPPING_ID
              AND osi1.orderitemid = ot1.id
              AND os1.ORDERS = od1.ID
              AND od1.TYPE <> 2
              AND osi1.id = osi.ID)) normal_order_quantity,
       sum((SELECT DISTINCT osi.QUANTITY
             FROM ORDERSHIPPINGITEM osi1,
                  ORDERS            od1,
                  ORDERITEM         ot1,
                  ORDERSHIPPING     os1
            WHERE ot1.ORDERS = od1.id
              AND os.ID = osi1.ORDERSHIPPING_ID
              AND osi1.orderitemid = ot1.id
              AND os1.ORDERS = od1.ID
              AND od1.TYPE = 2
              AND ot1.UNDERTAKER = 1
              AND osi1.id = osi.ID)) factory_order,
       sum((SELECT DISTINCT osi.QUANTITY
             FROM ORDERSHIPPINGITEM osi1,
                  ORDERS            od1,
                  ORDERITEM         ot1,
                  ORDERSHIPPING     os1
            WHERE ot1.ORDERS = od1.id
              AND os.ID = osi1.ORDERSHIPPING_ID
              AND osi1.orderitemid = ot1.id
              AND os1.ORDERS = od1.ID
              AND od1.TYPE = 2
              AND ot1.UNDERTAKER = 4
              AND osi1.id = osi.ID)) division_order,
       sum((SELECT DISTINCT osi.QUANTITY
             FROM ORDERSHIPPINGITEM osi1,
                  ORDERS            od1,
                  ORDERITEM         ot1,
                  ORDERSHIPPING     os1
            WHERE ot1.ORDERS = od1.id
              AND os.ID = osi1.ORDERSHIPPING_ID
              AND osi1.orderitemid = ot1.id
              AND os1.ORDERS = od1.ID
              AND od1.TYPE = 2
              AND ot1.UNDERTAKER = 2
              AND osi1.id = osi.ID)) stream_order,
       sum((SELECT DISTINCT osi.QUANTITY
             FROM ORDERSHIPPINGITEM osi1,
                  ORDERS            od1,
                  ORDERITEM         ot1,
                  ORDERSHIPPING     os1
            WHERE ot1.ORDERS = od1.id
              AND os.ID = osi1.ORDERSHIPPING_ID
              AND osi1.orderitemid = ot1.id
              AND os1.ORDERS = od1.ID
              AND od1.TYPE = 2
              AND ot1.UNDERTAKER = 5
              AND osi1.id = osi.ID)) dealer_order,
       sum((SELECT DISTINCT osi.QUANTITY
             FROM ORDERSHIPPINGITEM osi1,
                  ORDERS            od1,
                  ORDERITEM         ot1,
                  ORDERSHIPPING     os1
            WHERE ot1.ORDERS = od1.id
              AND os.ID = osi1.ORDERSHIPPING_ID
              AND osi1.orderitemid = ot1.id
              AND os1.ORDERS = od1.ID
              AND od1.TYPE = 2
              AND ot1.UNDERTAKER = 3
              AND osi1.id = osi.ID)) milkstation_order,
       sum((SELECT DISTINCT osi.QUANTITY
             FROM ORDERSHIPPINGITEM osi1,
                  ORDERS            od1,
                  ORDERITEM         ot1,
                  ORDERSHIPPING     os1
            WHERE ot1.ORDERS = od1.id
              AND os.ID = osi1.ORDERSHIPPING_ID
              AND osi1.orderitemid = ot1.id
              AND os1.ORDERS = od1.ID
              AND od1.TYPE = 2
              AND osi1.id = osi.ID)) sum_order

  FROM ORDERSHIPPINGITEM  osi,
       ORDERS             o,
       ORDERITEM          ot,
       ORDERSHIPPING      os,
       product            p,
       MILK_STATION       ms,
       MILK_STATION_LINE  msl,
       DEALERS            d,
       PRICE_LIST_HEADERS plh,
       PRICE_LIST_LINES   pll,
       FND_LOOKUP_VALUES  flv,
       PRODUCTCOMBO_LINE  PL
 WHERE os.ORDERS = o.ID
   AND ot.ORDERS = o.id
   AND os.ID = osi.ORDERSHIPPING_ID
   AND os.status = 'VALID'
   AND p.sn = osi.SN
   AND o.MILK_STATION_ID = ms.ID
   AND msl.HEADER_ID = ms.ID
   AND msl.DEALERS_ID = d.ID
   AND msl.PRICE_LIST_ID = plh.ID
   AND pll.HEADER_ID = plh.ID
   AND PL.Product_Id = pll.PRODUCT_ID
   AND plh.TYPE = flv.ATTRIBUTE1
   AND osi.orderitemid = ot.id
   AND flv.LOOKUP_TYPE = 'ORDER_FROM'
   AND flv.LOOKUP_CODE = o.ORDER_FROM
   AND flv.ATTRIBUTE1 = d.SOURCE
      --关联套餐表
   AND PL.PRODUCT_ID = pll.PRODUCT_ID
   and PL.COMBO_HEADER_ID = p.ID
   and p.type = 3
   and FND_UTIL.CRM_VALIDATE_AUTH(1, ms.ID) = 'Y'
-- and d.SOURCE='ONLINE'
-- and d.DEALERS_NAME like '三区线上'
--  AND os.SHIPPING_DATE >= to_date('2018-05-29','yyyy-mm-dd hh24:mi:ss')
--  AND os.SHIPPING_DATE <= to_date('2018-05-29','yyyy-mm-dd hh24:mi:ss')

 GROUP BY p.sn,
          p.QRNAME,
          d.DEALERS_NAME,
          ot.PRICE,
          d.DEALERS_CODE,
          ot.PAY_PRICE,
          os.SHIPPING_DATE,
          flv.ATTRIBUTE1,
          pll.PRICE_ZD,
          ms.MILK_STATION_NAME,
          plh.PRICE_NAME,
          pll.id,
          plh.id
--普通商品取配送费
union all
SELECT d.DEALERS_CODE,
       d.DEALERS_NAME,
       ms.MILK_STATION_NAME,
       p.sn,
       p.qrname,
       sum(osi.QUANTITY) shipping_quantity,
       plh.id PRICE_ID,
       plh.PRICE_NAME,
       pll.PRICE_ZD,
       (nvl(pll.MILK_STATION_SHIPPING_FEE, 0) +
       nvl(pll.DEALERS_SHIPPING_FEE, 0) +
       nvl(pll.MS_COURIER_SHIPPING_FEE, 0)) shipping_price,
       nvl(ot.PRICE, 0) PRICE,
       nvl(ot.PAY_PRICE, 0) PAY_PRICE,
       os.SHIPPING_DATE,
       flv.ATTRIBUTE1 order_type,
       sum((SELECT DISTINCT osi.QUANTITY
             FROM ORDERSHIPPINGITEM osi1,
                  ORDERS            od1,
                  ORDERITEM         ot1,
                  ORDERSHIPPING     os1
            WHERE ot1.ORDERS = od1.id
              AND os.ID = osi1.ORDERSHIPPING_ID
              AND osi1.orderitemid = ot1.id
              AND os1.ORDERS = od1.ID
              AND od1.TYPE <> 2
              AND osi1.id = osi.ID)) normal_order_quantity,
       sum((SELECT DISTINCT osi.QUANTITY
             FROM ORDERSHIPPINGITEM osi1,
                  ORDERS            od1,
                  ORDERITEM         ot1,
                  ORDERSHIPPING     os1
            WHERE ot1.ORDERS = od1.id
              AND os.ID = osi1.ORDERSHIPPING_ID
              AND osi1.orderitemid = ot1.id
              AND os1.ORDERS = od1.ID
              AND od1.TYPE = 2
              AND ot1.UNDERTAKER = 1
              AND osi1.id = osi.ID)) factory_order,
       sum((SELECT DISTINCT osi.QUANTITY
             FROM ORDERSHIPPINGITEM osi1,
                  ORDERS            od1,
                  ORDERITEM         ot1,
                  ORDERSHIPPING     os1
            WHERE ot1.ORDERS = od1.id
              AND os.ID = osi1.ORDERSHIPPING_ID
              AND osi1.orderitemid = ot1.id
              AND os1.ORDERS = od1.ID
              AND od1.TYPE = 2
              AND ot1.UNDERTAKER = 4
              AND osi1.id = osi.ID)) division_order,
       sum((SELECT DISTINCT osi.QUANTITY
             FROM ORDERSHIPPINGITEM osi1,
                  ORDERS            od1,
                  ORDERITEM         ot1,
                  ORDERSHIPPING     os1
            WHERE ot1.ORDERS = od1.id
              AND os.ID = osi1.ORDERSHIPPING_ID
              AND osi1.orderitemid = ot1.id
              AND os1.ORDERS = od1.ID
              AND od1.TYPE = 2
              AND ot1.UNDERTAKER = 2
              AND osi1.id = osi.ID)) stream_order,
       sum((SELECT DISTINCT osi.QUANTITY
             FROM ORDERSHIPPINGITEM osi1,
                  ORDERS            od1,
                  ORDERITEM         ot1,
                  ORDERSHIPPING     os1
            WHERE ot1.ORDERS = od1.id
              AND os.ID = osi1.ORDERSHIPPING_ID
              AND osi1.orderitemid = ot1.id
              AND os1.ORDERS = od1.ID
              AND od1.TYPE = 2
              AND ot1.UNDERTAKER = 5
              AND osi1.id = osi.ID)) dealer_order,
       sum((SELECT DISTINCT osi.QUANTITY
             FROM ORDERSHIPPINGITEM osi1,
                  ORDERS            od1,
                  ORDERITEM         ot1,
                  ORDERSHIPPING     os1
            WHERE ot1.ORDERS = od1.id
              AND os.ID = osi1.ORDERSHIPPING_ID
              AND osi1.orderitemid = ot1.id
              AND os1.ORDERS = od1.ID
              AND od1.TYPE = 2
              AND ot1.UNDERTAKER = 3
              AND osi1.id = osi.ID)) milkstation_order,
       sum((SELECT DISTINCT osi.QUANTITY
             FROM ORDERSHIPPINGITEM osi1,
                  ORDERS            od1,
                  ORDERITEM         ot1,
                  ORDERSHIPPING     os1
            WHERE ot1.ORDERS = od1.id
              AND os.ID = osi1.ORDERSHIPPING_ID
              AND osi1.orderitemid = ot1.id
              AND os1.ORDERS = od1.ID
              AND od1.TYPE = 2
              AND osi1.id = osi.ID)) sum_order
  FROM ORDERSHIPPINGITEM  osi,
       ORDERS             o,
       ORDERITEM          ot,
       ORDERSHIPPING      os,
       product            p,
       MILK_STATION       ms,
       MILK_STATION_LINE  msl,
       DEALERS            d,
       PRICE_LIST_HEADERS plh,
       PRICE_LIST_LINES   pll,
       FND_LOOKUP_VALUES  flv
 WHERE os.ORDERS = o.ID
   AND ot.ORDERS = o.id
   AND os.ID = osi.ORDERSHIPPING_ID
   AND os.status = 'VALID'
   AND p.sn = osi.SN
   AND o.MILK_STATION_ID = ms.ID
   AND msl.HEADER_ID = ms.ID
   AND msl.DEALERS_ID = d.ID
   AND msl.PRICE_LIST_ID = plh.ID(+)
   AND pll.HEADER_ID = plh.ID
   AND p.id = pll.PRODUCT_ID
   AND plh.TYPE = flv.ATTRIBUTE1
   AND osi.orderitemid = ot.id
   AND flv.LOOKUP_TYPE = 'ORDER_FROM'
   AND flv.LOOKUP_CODE = o.ORDER_FROM
   AND flv.ATTRIBUTE1 = d.SOURCE
   and FND_UTIL.CRM_VALIDATE_AUTH(1, ms.ID) = 'Y'
-- and d.SOURCE='ONLINE'
--and d.DEALERS_NAME like '三区线上'
-- AND os.SHIPPING_DATE >= to_date('2018-05-29','yyyy-mm-dd hh24:mi:ss')
-- AND os.SHIPPING_DATE <= to_date('2018-05-29','yyyy-mm-dd hh24:mi:ss')
 GROUP BY p.sn,
          p.QRNAME,
          d.DEALERS_NAME,
          ot.PRICE,
          d.DEALERS_CODE,
          ot.PAY_PRICE,
          os.SHIPPING_DATE,
          flv.ATTRIBUTE1,
          pll.PRICE_ZD,
          ms.MILK_STATION_NAME,
          plh.PRICE_NAME,
          pll.id,
          pll.MILK_STATION_SHIPPING_FEE,
          pll.DEALERS_SHIPPING_FEE,
          pll.MS_COURIER_SHIPPING_FEE,
          plh.id
/

