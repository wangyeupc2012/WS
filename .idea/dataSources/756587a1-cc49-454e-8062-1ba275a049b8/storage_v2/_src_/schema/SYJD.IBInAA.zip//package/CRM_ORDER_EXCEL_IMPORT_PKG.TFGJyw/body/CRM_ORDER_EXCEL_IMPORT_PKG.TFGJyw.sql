create package body CRM_ORDER_EXCEL_IMPORT_PKG is

  --校验数据是否规范
  procedure check_data_validate(p_batch_id            in number,
                                p_check_flag          out varchar2,
                                p_check_error_message out varchar2) is
    cursor cur_order_header is
      select *
        from crm_order_header_temp
       where batch_id = p_batch_id;
    cursor cur_order_line(p_orders in number) is
      select *
        from crm_order_line_temp
       where orders = p_orders;
    var_ord_header           cur_order_header%rowtype;
    var_ord_line             cur_order_line%rowtype;
    v_message                varchar2(200);
    v_flag                   varchar2(20) := 'Y';
    v_count                  number;
    v_cnt_e                  number;
		v_vnt_line_e             number;
    var_order_header_flag    varchar2(20);
    var_order_header_message varchar2(2000);
    var_order_line_flag      varchar2(20);
    var_order_line_message   varchar2(2000);
    v_line_flag              varchar2(20);
  begin
    for var_ord_header in cur_order_header loop
      v_flag:='Y';
      begin
        IF var_ord_header.mode_of_distribution is not null then
          --校验配送模式是否规范
          begin
            select count(1)
              into v_count
              from fnd_lookup_values flv
             where flv.lookup_type = 'MODE_OF_DISTRIBUTION'
               and flv.meaning = var_ord_header.mode_of_distribution;
          exception
            when others then
              null;
          end;
          IF v_count > 0 THEN
            update crm_order_header_temp coht
               set coht.mode_of_distribution =
                   (select flv.lookup_code
                      from fnd_lookup_values flv
                     where flv.lookup_type = 'MODE_OF_DISTRIBUTION'
                       and flv.meaning = var_ord_header.mode_of_distribution)
             where coht.id = var_ord_header.id;
          ELSE
            v_flag:='E';
            v_message := '配送模式有误；';
          /*  update crm_order_header_temp
               set check_flag = v_flag, 
                   check_error_message = v_message
             where id = var_ord_header.id;*/
            
          END IF;
        end if;
      
        if var_ord_header.oldcustomer_flag is not null  and v_flag='Y' then
          --校验分单依据是否规范
          begin
            select count(1)
              into v_count
              from fnd_lookup_values flv
             where flv.lookup_type = 'DISTRIBUTED_ORDER_ACCORDING_TO'
               and flv.meaning = var_ord_header.oldcustomer_flag;
          exception
            when others then
              null;
          end;
          if v_count > 0 then
            update crm_order_header_temp coht
               set coht.oldcustomer_flag =
                   (select flv.lookup_code
                      from fnd_lookup_values flv
                     where flv.lookup_type =
                           'DISTRIBUTED_ORDER_ACCORDING_TO'
                       and flv.meaning = var_ord_header.oldcustomer_flag)
             where coht.id = var_ord_header.id;
          else
            v_flag:='E';
            v_message := '分单依据有误；';
           /* update crm_order_header_temp
               set check_flag = v_flag, check_error_message = v_message
             where id = var_ord_header.id;*/
          end if;
        end if;
      
        if var_ord_header.milk_station_name is not null and v_flag='Y' then
          --校验零售仓名称是否规范
          select count(*)
            into v_count
            from milk_station
           where milk_station_name = var_ord_header.milk_station_name;
          if v_count > 0 then
            --v_flag := 'Y';
            update crm_order_header_temp
               set dealer_id             =
                   (select dealers_id
                      from milk_station
                     where milk_station_name =
                           var_ord_header.milk_station_name),
                   MILK_STATION_ID       =
                   (SELECT ID
                      FROM MILK_STATION
                     WHERE MILK_STATION_NAME =
                           var_ord_header.milk_station_name),
                   valid_milkstation_flag = 'Y'
             where id = var_ord_header.id;
          
          else
            v_flag:='E';
            v_message := '奶站名称有误；';
           /* update crm_order_header_temp
               set check_flag = v_flag, check_error_message = v_message
             where id = var_ord_header.id;
          */
          end if;
        end if;
      
        if var_ord_header.ms_courier_name is not null and  v_flag='Y' then
          --校验配送员名称是否规范
          select count(*)
            into v_count
            from ms_courier
           where ms_courier_name = var_ord_header.ms_courier_name;
          if v_count > 0 then
            -- v_flag := 'Y';
            update crm_order_header_temp
               set ms_courier_id =
                   (select id
                      from ms_courier
                     where ms_courier_name = var_ord_header.ms_courier_name)
             where id = var_ord_header.id;
          else
            v_flag:='E';
            v_message := '配送员名称有误；';
           /* update crm_order_header_temp
               set check_flag          = v_flag,
                   check_error_message = check_error_message || v_message
             where id = var_ord_header.id;*/
          
          end if;
        end if;
      
        if var_ord_header.areaname is not null and   v_flag='Y' then
          --校验收货区域是否规范
          select count(*)
            into v_count
            from area
           where to_char(fullname) = var_ord_header.areaname;
          if v_count > 0 then
            -- v_flag := 'Y';
            update crm_order_header_temp
               set area_id =
                   (select id
                      from area
                     where to_char(fullname) = var_ord_header.areaname)
             where id = var_ord_header.id;
          else
            v_flag:='E';
            v_message := '收获区域名称有误；';
          /*  update crm_order_header_temp
               set check_flag          = v_flag,
                   check_error_message = check_error_message || v_message
             where id = var_ord_header.id;*/
          end if;
        
        end if;
      
        --校验会员编码是否规范
        if var_ord_header.member_code is not null or
           var_ord_header.member_code != '' and  v_flag='Y' then
          select count(*)
            into v_count
            from member
           where member_code = var_ord_header.member_code;
          if v_count > 0 then
            /* v_flag := 'Y';
            update crm_order_header_temp
               set check_flag = v_flag
             where id = var_ord_header.id;*/
            null;
          else
            v_flag:='E';
            v_message := '会员编码有误；';
           /* update crm_order_header_temp
               set check_flag          = v_flag,
                   check_error_message = check_error_message || v_message
             where id = var_ord_header.id;*/
          end if;
        end if;
        --判断订单编码是否已存在
        if var_ord_header.sn is not null  and  v_flag='Y' then
          select count(*)
            into v_count
            from orders
           where sn = var_ord_header.sn;
          if v_count > 0 then
             v_flag:='E' ;
            v_message := '订单编码已存在；';
           /* update crm_order_header_temp
               set check_flag          = v_flag,
                   check_error_message = check_error_message || v_message
             where id = var_ord_header.id;*/
          end if;
        end if;
      
       if  v_flag='Y' then
        --判断配送方式是否规范（订单头表）
        select count(*)
          into v_count
          from fnd_lookup_values
         where lookup_type = 'SHIPPING_METHOD'
           and meaning = var_ord_header.shippingmethodname;
        if v_count > 0 then
          update crm_order_header_temp
             set shippingmethod_id =
                 (select lookup_code
                    from fnd_lookup_values
                   where lookup_type = 'SHIPPING_METHOD'
                     and meaning = var_ord_header.shippingmethodname)
           where id = var_ord_header.id;
          null;
        else
           v_flag:='E'; 
          v_message := '配送方式有误；';
         /* update crm_order_header_temp
             set check_flag          = v_flag,
                 check_error_message = check_error_message || v_message
           where id = var_ord_header.id;*/
        
        end if;
      end if;
      if  v_flag='Y' then 
        --判断订单类型是否规范
        select count(*)
          into v_count
          from fnd_lookup_values
         where lookup_type = 'ORDER_TYPE'
           and meaning = var_ord_header.type_name;
        if v_count > 0 then
          update crm_order_header_temp
             set type =
                 (select lookup_code
                    from fnd_lookup_values
                   where lookup_type = 'ORDER_TYPE'
                     and meaning = var_ord_header.type_name)
           where id = var_ord_header.id;
        else
          v_flag:='E';
          v_message := '订单类型有误；';
         /* update crm_order_header_temp
             set check_flag          = v_flag,
                 check_error_message = check_error_message || v_message
           where id = var_ord_header.id;*/
        end if;
       end if; 
       if  v_flag='Y' then
        --判断订单来源是否规范
        select count(*)
          into v_count
          from fnd_lookup_values
         where lookup_type = 'ORDER_FROM'
           and meaning = var_ord_header.order_from_name;
        if v_count > 0 then
          update crm_order_header_temp
             set order_from =
                 (select lookup_code
                    from fnd_lookup_values
                   where lookup_type = 'ORDER_FROM'
                     and meaning = var_ord_header.order_from_name)
           where id = var_ord_header.id;
        else
          v_flag:='E';
          v_message := '订单来源有误；';
         /* update crm_order_header_temp
             set check_flag          = v_flag,
                 check_error_message = check_error_message || v_message
           where id = var_ord_header.id;*/
        end if;
        end if;
        
        if  v_flag='Y' then 
            --判断订单头表状态是否规范
            select count(*)
              into v_count
              from fnd_lookup_values
             where lookup_type = 'ORDER_STATUS'
               and meaning = var_ord_header.status_name;
            if v_count > 0 then
              update crm_order_header_temp
                 set status =
                     (select lookup_code
                        from fnd_lookup_values
                       where lookup_type = 'ORDER_STATUS'
                         and meaning = var_ord_header.status_name)
               where id = var_ord_header.id;
            else
              v_flag:='E';
              v_message := '订单头状态有误；';
           /*   update crm_order_header_temp
                 set check_flag          = v_flag,
                     check_error_message = check_error_message || v_message
               where id = var_ord_header.id;*/
            end if;
       end if;
      /* insert into cux_test values('1','测试',v_flag);
       commit;*/
       if  v_flag='Y' then 
                  for var_ord_line in cur_order_line(var_ord_header.id) loop
                    v_line_flag:='Y';
                    if v_line_flag='Y' then
                                begin
                                  --判断产品编码是否规范
                                  select count(*)
                                    into v_count
                                    from product
                                   where sn = replace(var_ord_line.sn, '-', '.')
                                     and name = var_ord_line.name;
                                  if v_count > 0 then
                                    /*v_flag := 'Y';
                                    update crm_order_line_temp
                                       set check_flag = v_flag
                                     where id = var_ord_line.id;*/
                                    null;
                                  else
                                    v_flag:='E';
                                    v_message := '产品编码和产品说明没有对应；';
                                   /* update crm_order_line_temp
                                       set check_flag          = 'N',
                                           check_error_message = check_error_message || v_message
                                     where id = var_ord_line.id;
                                  */
                                  end if;
                                  if  v_flag='Y' then
                                        --校验订单行每日配送时间是否符合规范
                                        select count(*)
                                          into v_count
                                          from fnd_lookup_values
                                         where lookup_type = 'ORDERITEM_DAY_SHIPPING_TIME'
                                           and meaning = var_ord_line.day_shipping_time_name;
                                        if v_count > 0 then
                                        
                                          update crm_order_line_temp
                                             set day_shipping_time =
                                                 (select lookup_code
                                                    from fnd_lookup_values
                                                   where lookup_type = 'ORDERITEM_DAY_SHIPPING_TIME'
                                                     and meaning = var_ord_line.day_shipping_time_name)
                                           where id = var_ord_line.id;
                                        else
                                          v_line_flag:='E';
                                          v_message := '每日配送时间有误；';
                                          /*update crm_order_line_temp
                                             set check_flag          = 'N',
                                                 check_error_message = check_error_message || v_message
                                           where id = var_ord_line.id;*/
                                        
                                        end if;
                                  end if;
                                  if  v_line_flag='Y'  THEN
                                      --判断订单行配送类型是否符合规范
                                      select count(*)
                                        into v_count
                                        from fnd_lookup_values
                                       where lookup_type = 'ORDER_SHIPPING_TYPE'
                                         and meaning = var_ord_line.shipping_type_name;
                                      if v_count > 0 then
                                      --  v_flag := 'Y';
                                        update crm_order_line_temp
                                           set shipping_type =
                                               (select lookup_code
                                                  from fnd_lookup_values
                                                 where lookup_type = 'ORDER_SHIPPING_TYPE'
                                                   and meaning = var_ord_line.shipping_type_name)
                                         where id = var_ord_line.id;
                                      else
                                        v_line_flag:='E';
                                        v_message := '配送类型有误；';
                                       /* update crm_order_line_temp
                                           set check_flag          = 'N',
                                               check_error_message = check_error_message || v_message
                                         where id = var_ord_line.id;*/
                                      end if;
                                    end if;
                                  if  v_line_flag='Y' then  
                                        --校验订单行状态是否规范
                                        select count(*)
                                          into v_count
                                          from fnd_lookup_values
                                         where lookup_type = 'ORDERITEM_RETURN_STATUS'
                                           and meaning = var_ord_line.line_status_name;
                                        if v_count > 0 then
                                          update crm_order_line_temp
                                             set line_status =
                                                 (select lookup_code
                                                    from fnd_lookup_values
                                                   where lookup_type = 'ORDERITEM_RETURN_STATUS'
                                                     and meaning = var_ord_line.line_status_name)
                                           where id = var_ord_line.id;
                                        else
                                          v_line_flag:='E';
                                          v_message := '退款状态有误';
                                          /*update crm_order_line_temp
                                             set check_flag          = 'N',
                                                 check_error_message = check_error_message || v_message
                                           where id = var_ord_line.id;*/
                                        end if;
                                     end if; 
                                     
                                     if v_line_flag='Y'   then
                                       
                                      update crm_order_line_temp
                                       set check_flag = 'Y'
                                     where id = var_ord_line.id;
                                     
                                     else 
                                       
                                       update crm_order_line_temp
                                       set check_flag = v_line_flag
                                           ,check_error_message =v_message
                                       where id = var_ord_line.id;
                                       continue;
                                     end if;
                                 /* --更新行校验状态
                                  select check_flag, check_error_message
                                    into var_order_line_flag, var_order_line_message
                                    from crm_order_line_temp
                                   where id = var_ord_line.id;
                                  if nvl(var_order_line_flag, 'Y') <> 'N' then
                                    update crm_order_line_temp
                                       set check_flag = 'Y'
                                     where id = var_ord_line.id;
                                  end if;*/
                                end;
                         end if;
                    commit;
                  end loop;
                  
              update crm_order_header_temp
              set check_flag = 'Y', 
                  check_error_message = ''
               where id = var_ord_header.id;
    --      insert into cux_test values('3','测试',v_flag);                   
        else
      --     insert into cux_test values('3','测试',v_flag);
           update crm_order_header_temp
             set check_flag = 'N', 
                 check_error_message = v_message
           where id = var_ord_header.id;    
        commit;       
        end if;
       /* --更新头状态
        select check_flag, check_error_message
          into var_order_header_flag, var_order_header_message
          from crm_order_header_temp
         where id = var_ord_header.id;
        if nvl(var_order_header_flag, 'Y') <> 'N' then
          update crm_order_header_temp
             set check_flag = 'Y', check_error_message = null
           where id = var_ord_header.id;
          --p_check_flag:='Y';
        end if;*/
      end;
      commit;
    end loop;
  
   /* select count(*)
      into v_cnt_e
      from crm_order_header_temp
     where batch_id = p_batch_id
       and check_flag = 'N';
			 SELECT COUNT(1)
			 into v_vnt_line_e
			 from crm_order_line_temp colt
			 where colt.batch_id = p_batch_id
			 and colt.check_flag = 'N';
    if v_cnt_e > 0 then
      select '第' || TID || '行' || check_error_message
        into p_check_error_message
        from crm_order_header_temp
       where batch_id = p_batch_id
         and check_flag = 'N'
         and rownum = 1;
      if p_check_error_message = 'Y' then
        p_check_flag := 'Y';
      else
        p_check_flag := 'N';
      end if;
    elsif v_vnt_line_e > 0 then
			 select '第' || TID || '行' || check_error_message
        into p_check_error_message
        from crm_order_line_temp
       where batch_id = p_batch_id
         and check_flag = 'N'
         and rownum = 1;
				 p_check_flag := 'N';
		else
      p_check_flag := 'Y';
    end if;*/
    
    p_check_flag:='Y';
  
  exception
    when others then
      v_message := '错误信息：' || sqlerrm;
  --    dbms_output.put_line(v_message);
      update crm_order_header_temp
         set check_flag = v_flag, check_error_message = v_message
       where id = var_ord_header.id;
   commit;    
  end;

  --数据合并
  procedure merge_data(p_batch_id            in number,
                       p_merge_flag          out varchar2,
                       p_merge_error_message out varchar2) is
    cursor cur_crm_ord_header is
      select min(id) id,
             version,
             address,
             amount,
             amountpaid,
             areaname,
             consignee,
             coupondiscount,
             memo,
             phone,
             promotiondiscount,
             shippingmethodname,
             status,
             type,
             area_id,
             member_code,
             shippingmethod_id,
             order_from,
             milk_station_id,
             ms_courier_id,
             dealer_id,
             sn,
             poi_title
        from crm_order_header_temp t
       where check_flag = 'Y'
        and batch_id = p_batch_id
        and exists (
        select 1 from  crm_order_line_temp cl
        where cl.orders=t.id
        and cl.check_flag='Y'
        )
      --and sn is not null
       group by version,
                address,
                amount,
                amountpaid,
                areaname,
                consignee,
                coupondiscount,
                memo,
                phone,
                promotiondiscount,
                shippingmethodname,
                status,
                type,
                area_id,
                member_code,
                shippingmethod_id,
                order_from,
                milk_station_id,
                ms_courier_id,
                dealer_id,
                sn,
                poi_title;
    --order by createddate desc;
    var_crm_ord_header cur_crm_ord_header%rowtype;
    --v_header_id        number;
    v_message   varchar2(120);
    v_header_sn varchar2(120);
    --v_flag varchar2(20):='N';
  begin
    for var_crm_ord_header in cur_crm_ord_header loop
    
      /*select min(var_crm_ord_header.sn)
      into v_header_sn
      from crm_order_header_temp coht
      where coht.address = var_crm_ord_header.address
      and coht.amount = var_crm_ord_header.amount
      and coht.amountpaid = var_crm_ord_header.amountpaid
      and coht.member_code = var_crm_ord_header.member_code
      and coht.batch_id = p_batch_id;*/
      /*v_header_sn := to_char(sysdate, 'yyyymmdd') ||
      lpad(var_crm_ord_header.id, 6, '0');*/
      update crm_order_header_temp
         set sn               = var_crm_ord_header.sn,
             merge_flag       = 'Y',
             lastmodifieddate = sysdate
       where (version = var_crm_ord_header.version or
             (version is null and var_crm_ord_header.version is null))
         and (address = var_crm_ord_header.address or
             (address is null and var_crm_ord_header.address is null))
         and (amount = var_crm_ord_header.amount or
             (amount is null and var_crm_ord_header.amount is null))
         and (amountpaid = var_crm_ord_header.amountpaid or
             (amountpaid is null and var_crm_ord_header.amountpaid is null))
         and (areaname = var_crm_ord_header.areaname or
             (areaname is null and var_crm_ord_header.areaname is null))
         and (consignee = var_crm_ord_header.consignee or
             (consignee is null and var_crm_ord_header.consignee is null))
         and (coupondiscount = var_crm_ord_header.coupondiscount or
             (coupondiscount is null and
             var_crm_ord_header.coupondiscount is null))
         and (memo = var_crm_ord_header.memo or
             (memo is null and var_crm_ord_header.memo is null))
         and (phone = var_crm_ord_header.phone or
             (phone is null and var_crm_ord_header.phone is null))
         and (promotiondiscount = var_crm_ord_header.promotiondiscount or
             (promotiondiscount is null and
             var_crm_ord_header.promotiondiscount is null))
         and (shippingmethodname = var_crm_ord_header.shippingmethodname or
             (shippingmethodname is null and
             var_crm_ord_header.shippingmethodname is null))
         and (status = var_crm_ord_header.status or
             (status is null and var_crm_ord_header.status is null))
         and (type = var_crm_ord_header.type or
             (type is null and var_crm_ord_header.type is null))
         and (area_id = var_crm_ord_header.area_id or
             (area_id is null and var_crm_ord_header.area_id is null))
         and (member_code = var_crm_ord_header.member_code or
             (member_code is null and
             var_crm_ord_header.member_code is null))
         and (shippingmethod_id = var_crm_ord_header.shippingmethod_id or
             (shippingmethod_id is null and
             var_crm_ord_header.shippingmethod_id is null))
         and (order_from = var_crm_ord_header.order_from or
             (order_from is null and var_crm_ord_header.order_from is null))
         and (milk_station_id = var_crm_ord_header.milk_station_id or
             (milk_station_id is null and
             var_crm_ord_header.milk_station_id is null))
         and (ms_courier_id = var_crm_ord_header.ms_courier_id or
             (ms_courier_id is null and
             var_crm_ord_header.ms_courier_id is null))
         and (dealer_id = var_crm_ord_header.dealer_id or
             (dealer_id is null and var_crm_ord_header.dealer_id is null))
         and (poi_title = var_crm_ord_header.poi_title or
             (poi_title is null and var_crm_ord_header.poi_title is null))
         and batch_id = p_batch_id
         and merge_flag is null;
      --commit;
      p_merge_flag          := 'Y';
      p_merge_error_message := '';
      commit;
    end loop;
  
    p_merge_flag          := 'Y';
    p_merge_error_message := '';
  
  exception
    when others then
      v_message             := '错误信息：' || sqlerrm;
      p_merge_flag          := 'N';
      p_merge_error_message := v_message;
      dbms_output.put_line(v_message);
  end;

  --导入正式表
  procedure import_into_orders(p_batch_id             in number,
                               p_insert_flag          out varchar2,
                               p_insert_error_message out varchar2) is
    cursor cur_order_header is
      select *
        from crm_order_header_temp t
       where merge_flag = 'Y'
       and exists (
        select 1 from  crm_order_line_temp cl
        where cl.orders=t.id
        and cl.check_flag='Y')
         and batch_id = p_batch_id;
    cursor cur_order_line(p_sn crm_order_header_temp.sn%type) is
      select *
        from crm_order_line_temp
       where orders in
             (select id from crm_order_header_temp where sn = p_sn)
						 AND BATCH_ID = p_batch_id
       order by createddate desc;
    var_ord_header cur_order_header%rowtype;
    var_ord_line   cur_order_line%rowtype;
    v_message      varchar2(120);
    v_count        number;
    v_order_id     number;
    var_line_id    number;
    v_receiver_id  number;
    v_act_amount   number;
    v_amount       number;
    v_flag          varchar2(10);
    v_count1        number;
  begin
    for var_ord_header in cur_order_header loop
      v_flag:='Y';
      begin
        --判断订单是否已导入
        --p_orders:=var_ord_header.id;
        select count(*)
          into v_count
          from orders
         where sn = var_ord_header.sn;
        if v_count = 0 then
          v_order_id := get_primary_id('ORDERS');
          --获取收货地址ID
          begin
            select r.id
              into v_receiver_id
              from receiver r
             where r.areaname = var_ord_header.areaname
               and r.address = var_ord_header.address
               and r.phone = var_ord_header.phone
               and r.poititle = var_ord_header.poi_title
               and r.consignee = var_ord_header.consignee;
          exception
            when others then
            --  v_flag:='E';
              v_message := '错误信息：获取收货地址失败！' || sqlerrm;
              --dbms_output.put_line(v_message);
              /*update crm_order_header_temp
                 set insert_flag = 'N', insert_error_message = v_message
               where id = var_ord_header.id;*/
          end;
  /*         insert into cux_test values('1','测试',v_flag);
           commit;*/
          IF v_flag='Y' THEN
																--   if var_ord_header.milk_station_name
																--判断订单金额是否对应 实际单价对应实际金额 订购单价对应订单金额
																select sum(nvl(colt.act_price, 0) *
																					 nvl(colt.daily_delivery_quantity, 0) *
																					 nvl(colt.order_days, 0)),
																			 sum(nvl(colt.price, 0) *
																					 nvl(colt.daily_delivery_quantity, 0) *
																					 nvl(colt.order_days, 0))
																	into v_act_amount, v_amount
																	from crm_order_line_temp colt
																 where colt.orders in
																			 (select id
																					from crm_order_header_temp
																				 where sn = var_ord_header.sn
																				 AND batch_id = p_batch_id);
											        
																if v_act_amount = var_ord_header.actualamount and
																	 v_amount = var_ord_header.amount AND v_flag='Y' then
																	--插入订单头表
																	insert into orders
																		(id,
																		 CREATEDDATE,
																		 LASTMODIFIEDDATE,
																		 VERSION,
																		 ADDRESS,
																		 AMOUNT,
																		 AMOUNTPAID,
																		 AREANAME,
																		 --COMPLETEDATE,
																		 CONSIGNEE,
																		 COUPONDISCOUNT,
																		 EXCHANGEPOINT,
																		 EXPIRE,
																		 FEE,
																		 FREIGHT,
																		 --INVOICECONTENT,
																		 INVOICETITLE,
																		 ISALLOCATEDSTOCK,
																		 ISEXCHANGEPOINT,
																		 ISUSECOUPONCODE,
																		 MEMO,
																		 OFFSETAMOUNT,
																		 PAYMENTMETHODNAME,
																		 PAYMENTMETHODTYPE,
																		 PHONE,
																		 PRICE, --全部写为0
																		 PROMOTIONDISCOUNT,
																		 PROMOTIONNAMES,
																		 QUANTITY, --0
																		 REFUNDAMOUNT, --0
																		 RETURNEDQUANTITY, --0
																		 REWARDPOINT,
																		 SHIPPEDQUANTITY, --0
																		 SHIPPINGMETHODNAME,
																		 SN,
																		 STATUS,
																		 TAX,
																		 TYPE,
																		 WEIGHT,
																		 ZIPCODE,
																		 AREA_ID,
																		 COUPONCODE_ID,
																		 MEMBER_ID,
																		 PAYMENTMETHOD_ID,
																		 SHIPPINGMETHOD_ID, --配送到户 51
																		 STORE_ID,
																		 CREATED_BY, -- 默认为-1
																		 LAST_UPDATED_BY, --默认为-1
																		 ORDER_FROM,
																		 MILK_STATION_ID,
																		 MS_COURIER_ID,
																		 DEALER_ID,
																		 POI_UID,
																		 POI_TITLE,
																		 RECEIVER_ID,
																		 valid_milkstation_flag,
																		 OLDCUSTOMER_FLAG,
																		 MODE_OF_DISTRIBUTION,
																		 COUPONAMOUNT,
																		 REDPACKETAMOUNT,
																		 ACTUALAMOUNT,
																		 BUYER_REMARK
																		 --CONFIRM_AMOUNT,
																		 )
																	values
																		(v_order_id,
																		 sysdate,
																		 sysdate,
																		 1,
																		 var_ord_header.address,
																		 nvl(var_ord_header.amount, 0),
																		 nvl(var_ord_header.amountpaid, var_ord_header.amount),
																		 var_ord_header.areaname,
																		 var_ord_header.consignee,
																		 nvl(var_ord_header.coupondiscount,
																				 var_ord_header.couponamount),
																		 0,
																		 var_ord_header.expire,
																		 0,
																		 0,
																		 var_ord_header.invoicetitle,
																		 1,
																		 0,
																		 0,
																		 var_ord_header.memo,
																		 0,
																		 --var_ord_header.offsetamount,
																		 var_ord_header.paymentmethodname,
																		 0,
																		 var_ord_header.phone,
																		 0,
																		 var_ord_header.promotiondiscount,
																		 var_ord_header.promotionnames,
																		 0,
																		 0,
																		 0,
																		 --下面是积分 没找到
																		 0,
																		 0,
																		 var_ord_header.shippingmethodname,
																		 var_ord_header.sn,
																		 var_ord_header.status,
																		 0,
																		 --var_ord_header.tax,
																		 0,
																		 0,
																		 var_ord_header.zipcode,
																		 var_ord_header.area_id,
																		 var_ord_header.couponcode_id,
																		 (select id
																				from member
																			 where member_code = var_ord_header.member_code),
																		 var_ord_header.paymentmethodtype,
																		 51,
																		 51,
																		 -1,
																		 -1,
																		 var_ord_header.order_from,
																		 var_ord_header.milk_station_id,
																		 var_ord_header.ms_courier_id,
																		 var_ord_header.dealer_id,
																		 var_ord_header.poi,
																		 var_ord_header.poi_title,
																		 v_receiver_id,
																		 decode(var_ord_header.valid_milkstation_flag, 'Y', 'Y', 'N'),
																		 var_ord_header.oldcustomer_flag,
																		 var_ord_header.mode_of_distribution,
																		 var_ord_header.couponamount,
																		 var_ord_header.redpacketamount,
																		 var_ord_header.actualamount,
																		 var_ord_header.buyer_remark);
											          
																	/*update crm_order_header_temp
																		 set insert_flag = 'Y', tid = ''
																	 where id = var_ord_header.id;*/
																	--插入订单行表
																	for var_ord_line in cur_order_line(var_ord_header.sn) loop
																		begin
																			select get_primary_id('ORDERITEM')
																				into var_line_id
																				from dual;
											              
																			--缺少行编号字段！！！！ 需要新增字段
																			insert into orderitem
																				(id,
																				 createddate,
																				 lastmodifieddate,
																				 version,
																				 commissiontotals,
																				 isdelivery,
																				 name,
																				 price,
																				 quantity,
																				 returnedquantity,
																				 shippedquantity,
																				 sn,
																				 specifications,
																				 thumbnail,
																				 type,
																				 weight,
																				 orders,
																				 sku_id,
																				 created_by,
																				 last_updated_by,
																				 order_date_from,
																				 order_date_to,
																				 order_days,
																				 daily_delivery_quantity,
																				 delivery_days,
																				 remain_days,
																				 REFUND_STATUS,
																				 day_shipping_time,
																				 shipping_type,
																				 original_order_date_to,
																				 product_sn,
																				 PAY_PRICE,
																				 present_flag,
																				 TOTALPRICE,
																				 LINE_COUNT)
																			values
																				(var_line_id,
																				 sysdate,
																				 sysdate,
																				 1,
																				 0,
																				 1,
																				 var_ord_line.name,
																				 var_ord_line.price,
																				 var_ord_line.daily_delivery_quantity *
																				 var_ord_line.order_days, --每日配送数量* 订购天数
																				 0,
																				 0,
																				 var_ord_line.sn,
																				 var_ord_line.specifications,
																				 var_ord_line.thumbnail,
																				 0,
																				 --var_ord_line.type,
																				 var_ord_line.weight,
																				 v_order_id,
																				 var_ord_line.sku_id,
																				 -1,
																				 -1,
																				 var_ord_line.order_date_from,
																				 var_ord_line.order_date_to,
																				 var_ord_line.order_days,
																				 var_ord_line.daily_delivery_quantity,
																				 var_ord_line.delivery_days,
																				 var_ord_line.remain_days,
																				 var_ord_line.line_status,
																				 var_ord_line.day_shipping_time,
																				 var_ord_line.shipping_type,
																				 var_ord_line.original_order_date_to,
																				 var_ord_line.sn,
																				 var_ord_line.act_price,
																				 decode(var_ord_line.isgift, '是', '1', '0'),
																				 var_ord_line.saleprice,
																				 var_ord_line.line_count);
											              
																			/* update orderitem t
																				set t.order_days  = t.order_date_to - t.order_date_from + 1,
																						t.remain_days = t.order_date_to - t.order_date_from + 1
																			where t.id = var_line_id;*/
											              
																			update orderitem t
																				 set t.quantity = t.order_days * t.daily_delivery_quantity
																			 where t.id = var_line_id;
											              
																			update crm_order_line_temp
																				 set insert_flag = 'Y', tid = ''
																			 where id = var_ord_line.id;
																			 p_insert_flag          := 'Y';
																			 p_insert_error_message := '';
																		exception
																			when others then
																				v_flag          := 'E';
																				v_message := '错误信息：' || sqlerrm;
																				--dbms_output.put_line(v_message);
																				update crm_order_line_temp
																					 set insert_flag          = 'E',
																							 insert_error_message = v_message,
																							 tid                  = ''
																				 where id = var_ord_line.id;
																		end;
																		commit;
																	end loop;
											            
																else
																		v_flag          := 'E';
																		v_message := '订单金额不匹配，请重新计算后导入！';
																end if;
																
          END IF;
        else
          /*update crm_order_header_temp
             set insert_flag          = 'E',
                 insert_error_message = '该订单已导入！',
                 tid                  = ''
           where id = var_ord_header.id;*/
					   v_flag          := 'E';
              v_message := '该订单已导入！';
        end if;
				
				
				if   v_flag='Y'  THEN
					 update crm_order_header_temp
             set insert_flag          = 'Y',
                 insert_error_message = ' ',
                 tid                  = '';
				ELSE 
              update crm_order_header_temp
               set insert_flag          = v_flag,
                   insert_error_message = v_message,
                   tid                  = ''
             where id = var_ord_header.id;
			end if;			 
        commit;
      exception
        when others then
          v_message := '错误信息：' || sqlerrm;
        --  dbms_output.put_line(v_message);
          update crm_order_header_temp
             set insert_flag = 'N', insert_error_message = v_message
           where id = var_ord_header.id;
      end;
			commit;
    end loop;
    /*select insert_flag, insert_error_message
     into p_insert_flag, p_insert_error_message
     from crm_order_header_temp
    where batch_id = p_batch_id;*/
    
    SELECT COUNT(1)
    into v_count1
    FROM crm_order_line_temp L,
         crm_order_header_temp H
    WHERE L.ORDERS=H.ID
    AND H.BATCH_ID=p_batch_id
    AND (L.INSERT_FLAG<>'Y'
    or H.INSERT_FLAG<>'Y' );
   
    if v_count1 >1 then
      p_insert_flag:='N';
      p_insert_error_message:='导入有误，请查看明细！';
    else 
			p_insert_flag:='Y';
      p_insert_error_message:='导入成功！';
    end if;
   
    
  exception
    when others then
      v_message              := '错误信息：' || sqlerrm;
      p_insert_flag          := 'N';
      p_insert_error_message := v_message;
      dbms_output.put_line(v_message);
  end;

/* --main
  procedure main is
  begin
    check_data_validate;
    merge_data;
    import_into_orders;
  end;*/
   procedure import_orders(p_batch_id             in number,
                           p_insert_flag          out varchar2,
                           p_insert_error_message out varchar2)is
   cursor cur_order_header is
      select *
        from crm_order_header_temp
       where merge_flag = 'N'
         and batch_id = p_batch_id;                        
   begin
     null;
   end;                       
  function  check_order_validate(p_batch_id            in number,
                                 p_order               in varchar2)return varchar2 is
  begin
    null;
  end;                                
                                 
end CRM_ORDER_EXCEL_IMPORT_PKG;
/

