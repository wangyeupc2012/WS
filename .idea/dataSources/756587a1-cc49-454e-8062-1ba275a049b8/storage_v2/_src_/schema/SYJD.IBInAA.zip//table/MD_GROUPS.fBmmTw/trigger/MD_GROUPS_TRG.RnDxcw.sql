create trigger MD_GROUPS_TRG
  before insert or update
  on MD_GROUPS
  for each row
  BEGIN
  if inserting and :new.id is null then
        :new.id := MD_META.get_next_id;
    end if;
END;
/

