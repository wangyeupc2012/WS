create package body CUX_ORDER_EXCEL_PKG is

--CUX_ORDER_EXCEL_XX_T CUX_ORDER_EXCEL_T两张表
  PROCEDURE ORDER_UPLOAD_FROM_EXCEL IS
    CURSOR CUR_ORDER IS
      SELECT * FROM CUX_ORDER_EXCEL_XX_T;
    VAR_ORDER                CUR_ORDER%ROWTYPE;
    VAR_ORDER_ID             NUMBER;
    VAR_FLAG                 VARCHAR2(10);
    VAR_MSG                  VARCHAR2(255);
    VAR_MODE_OF_DIS          VARCHAR2(20);
    VAR_SEPARATE_BASIS       VARCHAR2(20);
    VAR_MILKSTATION_ID       NUMBER;
    VAR_SHIPPING_METHOD_TYPE VARCHAR2(20);
    VAR_ORDER_TYPE           VARCHAR2(20);
    VAR_ORDER_FROM           VARCHAR2(20);
    v_count                  NUMBER;
    VAR_SHIPPING_TIME        VARCHAR2(20);
    VAR_SHIPPING_TYPE        VARCHAR2(20);
    VAR_ORDER_STATUS         VARCHAR2(20);
    VAR_REFUND_STATUS        VARCHAR2(20);
		VAR_AREA_ID              NUMBER;
  BEGIN
    FOR VAR_ORDER IN CUR_ORDER LOOP
      --判断订单编码是否已存在于orders表中
      BEGIN
        SELECT OS.ID
          INTO VAR_ORDER_ID
          FROM ORDERS OS
         WHERE OS.SN = VAR_ORDER.ORDER_SN;
      EXCEPTION
        WHEN OTHERS THEN
          VAR_FLAG := 'N';
          VAR_MSG  := '错误信息：' || SQLERRM;
      END;
      IF VAR_FLAG = 'N' AND VAR_ORDER.MODE_OF_DISTRIBUTION IS NOT NULL THEN
        --执行插入头、行操作
        --VAR_ORDER_ID :=get_primary_id('ORDERS');
      
        --校验配送模式是否规范
        begin
          select FLV.LOOKUP_CODE
            into VAR_MODE_OF_DIS
            from fnd_lookup_values flv
           where flv.lookup_type = 'MODE_OF_DISTRIBUTION'
             and flv.meaning = VAR_ORDER.MODE_OF_DISTRIBUTION;
          VAR_FLAG := 'Y';
        exception
          when others then
            VAR_FLAG := 'N';
            VAR_MSG  := '错误信息：配送模式有误' || SQLERRM;
        end;
      
        IF VAR_FLAG = 'Y' AND VAR_ORDER.SEPARATE_BASIS IS NOT NULL THEN
          --校验分单依据是否规范
          begin
            select FLV.LOOKUP_CODE
              into VAR_SEPARATE_BASIS
              from fnd_lookup_values flv
             where flv.lookup_type = 'DISTRIBUTED_ORDER_ACCORDING_TO'
               and flv.meaning = VAR_ORDER.SEPARATE_BASIS;
            -- VAR_FLAG := 'Y';
          exception
            when others then
              VAR_FLAG := 'N';
              VAR_MSG  := '错误信息：分单依据有误' || SQLERRM;
          end;
        END IF;
      
        IF VAR_FLAG = 'Y' AND VAR_ORDER.MILK_STATION IS NOT NULL THEN
          BEGIN
            select ID
              into VAR_MILKSTATION_ID
              from milk_station
             where milk_station_name = VAR_ORDER.MILK_STATION;
          exception
            when others then
              VAR_FLAG := 'N';
              VAR_MSG  := '错误信息：奶站名有误' || SQLERRM;
          END;
        
          --判断配送方式是否规范
          IF VAR_FLAG = 'Y' AND VAR_ORDER.SHIPPING_METHOD_TYPE IS NOT NULL THEN
            BEGIN
              select LOOKUP_CODE
                into VAR_SHIPPING_METHOD_TYPE
                from fnd_lookup_values
               where lookup_type = 'SHIPPING_METHOD'
                 and meaning = VAR_ORDER.SHIPPING_METHOD_TYPE;
            EXCEPTION
              WHEN OTHERS THEN
                VAR_FLAG := 'N';
                VAR_MSG  := '错误信息：配送方式有误' || SQLERRM;
            END;
          END IF;
        
          --判断订单类型是否规范
          IF VAR_FLAG = 'Y' AND VAR_ORDER.ORDER_TYPE IS NOT NULL THEN
            BEGIN
              select LOOKUP_CODE
                into VAR_ORDER_TYPE
                from fnd_lookup_values
               where lookup_type = 'ORDER_TYPE'
                 and meaning = VAR_ORDER.ORDER_TYPE;
            EXCEPTION
              WHEN OTHERS THEN
                VAR_FLAG := 'N';
                VAR_MSG  := '错误信息：订单类型有误' || SQLERRM;
            END;
          END IF;
        
          --判断订单来源是否规范
          IF VAR_FLAG = 'Y' AND VAR_ORDER.ORDER_FROM IS NOT NULL THEN
            BEGIN
              select LOOKUP_CODE
                into VAR_ORDER_FROM
                from fnd_lookup_values
               where lookup_type = 'ORDER_FROM'
                 and meaning = VAR_ORDER.ORDER_FROM;
            EXCEPTION
              WHEN OTHERS THEN
                VAR_FLAG := 'N';
                VAR_MSG  := '错误信息：订单来源有误' || SQLERRM;
            END;
          END IF;
        
          --判断订单状态是否规范
          IF VAR_FLAG = 'Y' AND VAR_ORDER.Order_Status IS NOT NULL THEN
            BEGIN
              select LOOKUP_CODE
                into VAR_ORDER_STATUS
                from fnd_lookup_values
               where lookup_type = 'ORDER_STATUS'
                 and meaning = VAR_ORDER.Order_Status;
            EXCEPTION
              WHEN OTHERS THEN
                VAR_FLAG := 'N';
                VAR_MSG  := '错误信息：订单状态有误' || SQLERRM;
            END;
          END IF;
        
          --判断产品编码是否规范
          IF VAR_FLAG = 'Y' AND VAR_ORDER.ITEM_SN IS NOT NULL AND
             VAR_ORDER.ITEM_NAME IS NOT NULL THEN
            BEGIN
              select count(*)
                into v_count
                from product
               where sn = replace(VAR_ORDER.ITEM_SN, '-', '.')
                 and name = VAR_ORDER.ITEM_NAME;
              IF v_count = 0 THEN
                VAR_FLAG := 'N';
                VAR_MSG  := '错误信息：产品编码和产品说明没有对应';
              END IF;
            EXCEPTION
              WHEN OTHERS THEN
                VAR_FLAG := 'N';
                VAR_MSG  := '错误信息：产品编码和产品说明没有对应' || SQLERRM;
            END;
          END IF;
        
          --校验订单行每日配送时间是否符合规范
          IF VAR_FLAG = 'Y' AND VAR_ORDER.SHIPPING_TIME IS NOT NULL THEN
            BEGIN
              select LOOKUP_CODE
                into VAR_SHIPPING_TIME
                from fnd_lookup_values
               where lookup_type = 'ORDERITEM_DAY_SHIPPING_TIME'
                 and meaning = VAR_ORDER.SHIPPING_TIME;
            EXCEPTION
              WHEN OTHERS THEN
                VAR_FLAG := 'N';
                VAR_MSG  := '错误信息：每日配送时间有误' || SQLERRM;
            END;
          END IF;
        
          --判断订单行配送类型是否符合规范
          IF VAR_FLAG = 'Y' AND VAR_ORDER.SHIPPING_TYPE IS NOT NULL THEN
            BEGIN
              select LOOKUP_CODE
                into VAR_SHIPPING_TYPE
                from fnd_lookup_values
               where lookup_type = 'ORDER_SHIPPING_TYPE'
                 and meaning = VAR_ORDER.SHIPPING_TYPE;
            EXCEPTION
              WHEN OTHERS THEN
                VAR_FLAG := 'N';
                VAR_MSG  := '错误信息：配送类型有误' || SQLERRM;
            END;
          END IF;
					
					--判断收获区域
					IF VAR_FLAG = 'Y' AND VAR_ORDER.AREA_NAME IS NOT NULL THEN
						BEGIN
              select A.ID
                into VAR_AREA_ID
                from AREA A
               where A.FULLNAME_VAR = VAR_ORDER.AREA_NAME;
            EXCEPTION
              WHEN OTHERS THEN
                VAR_FLAG := 'N';
                VAR_MSG  := '错误信息：收货区域有误' || SQLERRM;
            END;
					END IF;
        
          --判断订单行状态是否符合规范
          IF VAR_FLAG = 'Y' AND VAR_ORDER.REFUND_STATUS IS NOT NULL THEN
            BEGIN
              select LOOKUP_CODE
                into VAR_REFUND_STATUS
                from fnd_lookup_values
               where lookup_type = 'ORDERITEM_RETURN_STATUS'
                 and meaning = VAR_ORDER.REFUND_STATUS;
            EXCEPTION
              WHEN OTHERS THEN
                VAR_FLAG := 'N';
                VAR_MSG  := '错误信息：退款状态有误' || SQLERRM;
            END;
          END IF;
        
          IF VAR_FLAG = 'Y' THEN
            --做插入操作
            VAR_ORDER_ID := get_primary_id('ORDERS');
            insert into orders
              (id,
               CREATEDDATE,
               LASTMODIFIEDDATE,
               VERSION,
               ADDRESS,
               AMOUNT,
               AMOUNTPAID,
               AREANAME,
               --COMPLETEDATE,
               CONSIGNEE,
               COUPONDISCOUNT,
               EXCHANGEPOINT,
               EXPIRE,
               FEE,
               FREIGHT,
               --INVOICECONTENT,
               INVOICETITLE,
               ISALLOCATEDSTOCK,
               ISEXCHANGEPOINT,
               ISUSECOUPONCODE,
               MEMO,
               OFFSETAMOUNT,
               PAYMENTMETHODNAME,
               PAYMENTMETHODTYPE,
               PHONE,
               PRICE, --全部写为0
               PROMOTIONDISCOUNT,
               PROMOTIONNAMES,
               QUANTITY, --0
               REFUNDAMOUNT, --0
               RETURNEDQUANTITY, --0
               REWARDPOINT,
               SHIPPEDQUANTITY, --0
               SHIPPINGMETHODNAME,
               SN,
               STATUS,
               TAX,
               TYPE,
               WEIGHT,
               ZIPCODE,
               AREA_ID,
               COUPONCODE_ID,
            --   MEMBER_ID,
               PAYMENTMETHOD_ID,
               SHIPPINGMETHOD_ID, --配送到户 51
               STORE_ID,
               CREATED_BY, -- 默认为-1
               LAST_UPDATED_BY, --默认为-1
               ORDER_FROM,
               MILK_STATION_ID,
               MS_COURIER_ID,
               DEALER_ID,
               POI_UID,
               POI_TITLE,
               RECEIVER_ID,
               valid_milkstation_flag,
               OLDCUSTOMER_FLAG,
               MODE_OF_DISTRIBUTION,
               COUPONAMOUNT,
               REDPACKETAMOUNT,
               ACTUALAMOUNT,
							 ACTIVITYAMOUNT,
               BUYER_REMARK,
							 OLD_FLAG
               --CONFIRM_AMOUNT,
               )
            values
              (VAR_ORDER_ID,
               sysdate,
               sysdate,
               1,
               VAR_ORDER.Detail_Address,
               nvl(VAR_ORDER.Order_Amount, 0),
               nvl(VAR_ORDER.Act_Amount, VAR_ORDER.Order_Amount),
               var_order.area_name,
               var_order.consignee,
               var_order.discount_amount,
               0,
               '',
               0,
               0,
               '',
               1,
               0,
               0,
               var_order.seller_remark,
               0,
               --var_ord_header.offsetamount,
               '',
               0,
               var_order.tel_numer,
               0,
               var_order.promotion_amount,
               '',
               0,
               0,
               0,
               --下面是积分 没找到
               0,
               0,
               var_order.shipping_method_type,
               var_order.order_sn,
               VAR_ORDER_STATUS,
               0,
               --var_ord_header.tax,
               VAR_ORDER_TYPE,
               0,
               '',
               VAR_AREA_ID,
               '',
               11,
               /* (select id
                from member
               where member_code = var_ord_header.member_code),*/
              -- '',
               51,
               51,
               -1,
               -1,
               VAR_ORDER_FROM,
               VAR_MILKSTATION_ID,
               '',
               '',
               '',
               var_order.poi_address,
               '',
               decode(var_order.is_distribution, '是', 'Y', 'N'),
               VAR_SEPARATE_BASIS,
               VAR_MODE_OF_DIS,
               var_order.discount_amount,
               var_order.redpacket_amount,
               var_order.act_amount,
							 var_order.Activity_Amount,
               var_order.buyer_remark,
							 1);
          
            --写入订单行表
            insert into orderitem
              (id,
               createddate,
               lastmodifieddate,
               version,
               commissiontotals,
               isdelivery,
               name,
               price,
               quantity,
               returnedquantity,
               shippedquantity,
               sn,
               specifications,
               thumbnail,
               type,
               weight,
               orders,
               sku_id,
               created_by,
               last_updated_by,
               order_date_from,
               order_date_to,
               order_days,
               daily_delivery_quantity,
               delivery_days,
               remain_days,
               REFUND_STATUS,
               day_shipping_time,
               shipping_type,
               original_order_date_to,
               product_sn,
               PAY_PRICE,
               present_flag,
               TOTALPRICE,
               LINE_COUNT)
            values
              (get_primary_id('ORDERITEM'),
               sysdate,
               sysdate,
               1,
               0,
               1,
               var_order.Item_Name,
               var_order.price,
               var_order.day_diliver_quantity * var_order.order_days, --每日配送数量* 订购天数
               0,
               0,
               var_order.item_sn,
               '',
               '',
               0,
               --var_ord_line.type,
               '',
               VAR_ORDER_ID,
               '',
               -1,
               -1,
               to_date(var_order.order_date_from, 'yyyy-MM-dd'),
               to_date(var_order.order_date_to, 'yyyy-MM-dd'),
               var_order.order_days,
               var_order.day_diliver_quantity,
               '',
               '',
               var_order.refund_status,
               VAR_SHIPPING_TIME,
               VAR_SHIPPING_TYPE,
               to_date(var_order.order_date_to, 'yyyy-MM-dd'),
               var_order.item_sn,
               var_order.act_price,
               decode(var_order.is_gift, '是', '1', '0'),
               var_order.sale_amount,
               var_order.line_count);
          ELSE
            --更新临时表状态 msg
            UPDATE CUX_ORDER_EXCEL_XX_T C
						SET C.FLAG = VAR_FLAG,C.MSG = VAR_MSG
						WHERE C.ID = var_order.Id;
						COMMIT;
						CONTINUE;
          END IF;
        
        END IF;
      ELSE
        --执行插入行操作
        SELECT OS.ID
          INTO VAR_ORDER_ID
          FROM ORDERS OS
         WHERE OS.SN = var_order.Order_Sn;
        --写入订单行表
        insert into orderitem
          (id,
           createddate,
           lastmodifieddate,
           version,
           commissiontotals,
           isdelivery,
           name,
           price,
           quantity,
           returnedquantity,
           shippedquantity,
           sn,
           specifications,
           thumbnail,
           type,
           weight,
           orders,
           sku_id,
           created_by,
           last_updated_by,
           order_date_from,
           order_date_to,
           order_days,
           daily_delivery_quantity,
           delivery_days,
           remain_days,
           REFUND_STATUS,
           day_shipping_time,
           shipping_type,
           original_order_date_to,
           product_sn,
           PAY_PRICE,
           present_flag,
           TOTALPRICE,
           LINE_COUNT)
        values
          (get_primary_id('ORDERITEM'),
           sysdate,
           sysdate,
           1,
           0,
           1,
           var_order.Item_Name,
           var_order.price,
           var_order.day_diliver_quantity * var_order.order_days, --每日配送数量* 订购天数
           0,
           0,
           var_order.item_sn,
           '',
           '',
           0,
           --var_ord_line.type,
           '',
           VAR_ORDER_ID,
           '',
           -1,
           -1,
           to_date(var_order.order_date_from, 'yyyy-MM-dd'),
           to_date(var_order.order_date_to, 'yyyy-MM-dd'),
           var_order.order_days,
           var_order.day_diliver_quantity,
           '',
           '',
           var_order.refund_status,
           VAR_SHIPPING_TIME,
           VAR_SHIPPING_TYPE,
           to_date(var_order.order_date_to, 'yyyy-MM-dd'),
           var_order.item_sn,
           var_order.act_price,
           decode(var_order.is_gift, '是', '1', '0'),
           var_order.sale_amount,
           var_order.line_count);
      END IF;
      COMMIT;
    END LOOP;
  END;
end CUX_ORDER_EXCEL_PKG;
/

