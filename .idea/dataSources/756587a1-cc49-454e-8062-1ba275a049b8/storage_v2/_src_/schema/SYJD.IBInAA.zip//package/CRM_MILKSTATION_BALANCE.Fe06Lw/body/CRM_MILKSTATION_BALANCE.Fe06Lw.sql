create package body CRM_MILKSTATION_BALANCE is
  procedure update_creditamount(p_milk_station_id in varchar2,
                                p_creditamount    in varchar2,
                                p_code            out varchar2,
                                p_message         out varchar2) is
  
    v_code      varchar2(100);
    v_error_msg varchar2(100);
  begin
    update milk_station ms
       set ms.creditamount = to_number(p_creditamount)
     where ms.id = to_number(p_milk_station_id);
    update milk_station ms
       set ms.balance = nvl(ms.creditamount, 0) + nvl(ms.prepayment, 0)
     where ms.id = to_number(p_milk_station_id);
    v_code := 'Y';
  exception
    when others then
      v_code      := 'N';
      v_error_msg := '错误信息：' || sqlerrm;
      --dbms_output.put_line(v_error_msg);
      p_code    := v_code;
      p_message := v_error_msg;
  end;
  procedure update_prepayment(p_milk_station_id in varchar2,
                              p_prepayment      in varchar2,
                              p_code            out varchar2,
                              p_message         out varchar2) is
  
    v_code      varchar2(100);
    v_error_msg varchar2(100);
  begin
    update milk_station ms
       set ms.prepayment = nvl(ms.prepayment,0)+to_number(p_prepayment)
     where ms.id = to_number(p_milk_station_id);
    update milk_station ms
       set ms.balance = nvl(ms.creditamount, 0) + nvl(ms.prepayment, 0)
     where ms.id = to_number(p_milk_station_id);
    v_code := 'Y';
  exception
    when others then
      v_code      := 'N';
      v_error_msg := '错误信息：' || sqlerrm;
      --dbms_output.put_line(v_error_msg);
      p_code    := v_code;
      p_message := v_error_msg;
  end;
end CRM_MILKSTATION_BALANCE;
/

