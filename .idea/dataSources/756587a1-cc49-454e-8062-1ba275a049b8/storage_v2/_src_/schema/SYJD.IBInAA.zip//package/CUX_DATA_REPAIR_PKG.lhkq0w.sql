create package cux_data_repair_pkg is

  -- Author  : WANGYE
  -- Created : 2018/10/15 14:15:44
  -- Purpose : cux_data_repair_pkg

  procedure cux_add_hot_item;

  procedure cux_add_item_attibute;

  procedure cux_add_item_promotion;

  procedure cux_add_item_special;

  procedure cux_radom_valid_item;

  procedure cux_add_special_ads;

  procedure cux_delete_members;

  procedure cux_add_item_attibute_others;
  
  --验证订单来源是线上还是线下
  function validate_order_status(p_order_source  varchar2,
                                 p_order_status  varchar2,
                                 p_show_platform varchar2) return varchar2;
end cux_data_repair_pkg;
/

