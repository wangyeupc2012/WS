create package CUX_ORDER_DAYS_PKG is

  -- Author  : WANGYE
  -- Created : 2018/4/3 20:28:53
  -- Purpose : CUX_ORDER_DAYS_PKG

  PROCEDURE ORDER_DAYS_UPDATE;

end CUX_ORDER_DAYS_PKG;
/

