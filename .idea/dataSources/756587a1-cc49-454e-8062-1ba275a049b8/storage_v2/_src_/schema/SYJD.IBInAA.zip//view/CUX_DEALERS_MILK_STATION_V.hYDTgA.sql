create view CUX_DEALERS_MILK_STATION_V as
  select ms.id milk_station_id,
      ms.milk_station_name,
      ds.dealers_name,
      ds.id dealers_id,
      ds.source
from milk_station  ms
    ,milk_station_line msl
    ,dealers ds
where ms.id=msl.header_id
and msl.dealers_id= ds.id
--and msl.status='VALID'
--and ds.status='VALID'
/

