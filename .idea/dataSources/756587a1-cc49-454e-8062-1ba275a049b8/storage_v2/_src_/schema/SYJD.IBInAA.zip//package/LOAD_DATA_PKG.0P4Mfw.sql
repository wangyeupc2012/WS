create package LOAD_DATA_PKG is

  -- Author  : 19228
  -- Created : 2018/3/30 21:25:28
  -- Purpose : 导入正式环境数据

  -- Public type declarations
  PROCEDURE LOAD_DATA_PRO;

end LOAD_DATA_PKG;
/

