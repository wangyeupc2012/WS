create package body cux_erp_syjd_pkg is

 function import_items(p_type varchar2,
                       p_items_id number
                       )return varchar2 is
   
 begin
   null;
 end;
end cux_erp_syjd_pkg;
/

