create package body cux_import_tw_pkg is

  --导入会员
  procedure import_customer is
    cursor cur_customer is
      select * from cux_syjd_member where status in ('N','E') order by login_date desc;
    var_customer cur_customer%rowtype;
    v_message    varchar2(200);
    v_id         number(20);
    v_count      number(4);
    member_rank  number(4);
  begin
    for var_customer in cur_customer loop
      begin
        v_id := get_primary_id('MEMBER');
        select id into member_rank  from memberrank where rownum<=1;
        --判断手机号是否已有注册信息
        select count(*)
          into v_count
          from member
         where attributevalue1 = var_customer.twid;
        if v_count = 0 then
          --插入会员同时插入用户
          insert into users
            (id,
             createddate,
             lastmodifieddate,
             version,
             isenabled,
             islocked,
             lastlogindate,
             lastloginip,
             lockdate)
          values
            (v_id,
             var_customer.create_date,
             var_customer.modify_date,
             0,
             var_customer.is_enabled,
             var_customer.is_locked,
             var_customer.login_date,
             var_customer.register_ip,
             null);
          --插入会员
          insert into member
            (id,
             address,
             amount,
             balance,
             birth,
             email,
             encodedpassword,
             gender,
             mobile,
             name,
             phone,
             point,
             safekeyexpire,
             safekeyvalue,
             username,
             zipcode,
             area_id,
             memberrank_id,
             --member_code,
             --identity_type,
             --identity_number,
             --member_point,
             image,
             member_source,
             member_type,
             --status,
             qrcode_image,
             qrcode_eps_image,
             sign_in_date,
             serial_sngn_intimes,
             --salesman_id,
             wechat,
             qq,
             alipay,
             --sina,
             last_time,
             --last_site,
             --last_update_date,
             --last_updated_by,
             --creation_date,
             --created_by,
             source,
             attributevalue1)
          values
            (v_id,
             var_customer.address,
             var_customer.amount,
             var_customer.balance,
             var_customer.birth,
             nvl(var_customer.email, var_customer.username || '@syjd.com'), --如果邮箱为空，默认username@syjd.com
             var_customer.password,
             var_customer.gender,
             var_customer.mobile,
             var_customer.name,
             var_customer.phone,
             var_customer.point,
             var_customer.safe_key_expire,
             var_customer.safe_key_value,
             var_customer.username,
             var_customer.zip_code,
             null, --同旺表中area字段全为空
             member_rank,--暂定这么写
             var_customer.image_name,
             var_customer.source,
             var_customer.member_type,
             var_customer.qrcode_image,
             var_customer.qrcode_eps_image,
             var_customer.sign_in_date,
             var_customer.serial_sign_in_times,
             var_customer.wechat_vip_id,
             var_customer.qq,
             var_customer.zhifubao,
             var_customer.login_date,
             var_customer.status,
             var_customer.twid);
        
          update cux_syjd_member
             set status = 'Y',error_message = '插入成功'
           where id = var_customer.id;
           else 
            update member set
            address = var_customer.address,
             amount = var_customer.amount,
             balance = var_customer.balance,
             birth = var_customer.birth,
             email =  nvl(var_customer.email, var_customer.username || '@syjd.com'),
             encodedpassword = var_customer.password,
             gender = var_customer.gender,
             mobile = var_customer.mobile,
             name = var_customer.name,
             phone = var_customer.phone,
             point = var_customer.point,
             safekeyexpire = var_customer.safe_key_expire,
             safekeyvalue = var_customer.safe_key_value,
             username = var_customer.username,
             zipcode = var_customer.zip_code,
             area_id = null,
             memberrank_id = member_rank,
             --member_code,
             --identity_type,
             --identity_number,
             --member_point,
             image =  var_customer.image_name,
             member_source = var_customer.source,
             member_type = var_customer.member_type,
             --status,
             qrcode_image = var_customer.qrcode_image,
             qrcode_eps_image =  var_customer.qrcode_eps_image,
             sign_in_date = var_customer.sign_in_date,
             serial_sngn_intimes = var_customer.serial_sign_in_times,
             --salesman_id,
             wechat = var_customer.wechat_vip_id,
             qq = var_customer.qq,
             alipay = var_customer.zhifubao,
             --sina,
             last_time = var_customer.login_date,
             --last_site,
             --last_update_date,
             --last_updated_by,
             --creation_date,
             --created_by,
             source = var_customer.status,
             attributevalue1 = var_customer.twid
             where attributevalue1 = var_customer.twid;
             
              update cux_syjd_member
             set status = 'Y',error_message = '更新成功'
           where id = var_customer.id;
        end if;
      exception
        when others then
          v_message := '错误信息：' || sqlerrm;
          update cux_syjd_member
             set status = 'E', error_message = v_message
           where id = var_customer.id;
       --   DBMS_OUTPUT.put_line(v_message);
           
      end;
      commit;
    end loop;
  end;

  --根据cux_syjd_order表member_id 反查 CRM member表member_id
  function get_member_id(p_member_id cux_syjd_order.member%type)
    return number is
    v_member_id member.id%type;
  begin
    select m.id
      into v_member_id
      from member m
     where m.attributevalue1 = p_member_id;
    --and m.encodedpassword = csm.password;--根据密码来判断
    return v_member_id;
  end get_member_id;

  --导入订单头信息&订单明细
  procedure import_order is
    cursor cur_ord is
      select *
        from cux_syjd_order
       where  status = 'N'
      /*and new_member_id is not null*/
     /*  AND CREATE_DATE > TO_DATE('2017-08-01', 'yyyy-mm-dd')*/
       order by create_date desc;
    cursor cur_ord_item is
      select * from cux_syjd_order_item where status = 'N';
    var_ord      cur_ord%rowtype;
    var_ord_item cur_ord_item%rowtype;
    v_message    varchar2(200);
    --v_order_id number:=get_primary_id('ORDERS');
    --v_order_item_id number:=get_primary_id('ORDERITEM');
    v_order_id            number(10);
    v_is_exchange_point   number;
    v_payment_method_type number;
    v_order_line_status   varchar2(10); --订单行状态
    v_cnt                 number;
    v_count               number;
    v_count_line          number;
    var_line_cnt          number;
		VAR_ORDERITEM_SN      VARCHAR2(50);
		VAR_ORDERITEM_NAME    VARCHAR2(50);
  
  begin
  v_cnt := 0;
    for var_ord in cur_ord loop
      begin
        --根据low_points_paid的值判断isexchangepoint 的值是1还是0
        if var_ord.low_points_paid = 0 or var_ord.low_points_paid is null then
          v_is_exchange_point := 0;
        else
          v_is_exchange_point := 1;
        end if;
        select count(1) into v_count from orders where twid = var_ord.twid;
        if v_count = 0 then
        v_order_id := get_primary_id('ORDERS');
        
      
        --根据payment_method_name 查出在fnd_lookup_values表中对应的lookup_code
       /* select lookup_code
          into v_payment_method_type
          from fnd_lookup_values flv
         where flv.meaning = var_ord.payment_method_name;*/
        /* --如果fnd_lookup_values表中没有对应的支付方式快码 那么直接将源数据的code赋值
        if v_payment_method_type is null then
          v_payment_method_type := var_ord.payment_method;
        end if;*/
      
        insert into orders
          (id,
           CREATEDDATE,
           LASTMODIFIEDDATE,
           VERSION,
           ADDRESS,
           AMOUNT,
           AMOUNTPAID,
           AREANAME,
           --COMPLETEDATE,
           CONSIGNEE,
           COUPONDISCOUNT,
           EXCHANGEPOINT,
           EXPIRE,
           FEE,
           FREIGHT,
           --INVOICECONTENT,
           INVOICETITLE,
           ISALLOCATEDSTOCK,
           ISEXCHANGEPOINT,
           ISUSECOUPONCODE,
           MEMO,
           OFFSETAMOUNT,
           PAYMENTMETHODNAME,
           PAYMENTMETHODTYPE,
           PHONE,
           PRICE, --全部写为0
           PROMOTIONDISCOUNT,
           PROMOTIONNAMES,
           QUANTITY, --0
           REFUNDAMOUNT, --0
           RETURNEDQUANTITY, --0
           REWARDPOINT,
           SHIPPEDQUANTITY, --0
           SHIPPINGMETHODNAME,
           SN,
           STATUS,
           TAX,
           TYPE,
           WEIGHT,
           ZIPCODE,
           AREA_ID,
           COUPONCODE_ID,
           MEMBER_ID,
           PAYMENTMETHOD_ID,
           SHIPPINGMETHOD_ID, --配送到户 51
           STORE_ID,
           CREATED_BY, -- 默认为-1
           LAST_UPDATED_BY, --默认为-1
           ORDER_FROM,
           MILK_STATION_ID,
           MS_COURIER_ID,
           DEALER_ID,
           twid
           --CONFIRM_AMOUNT,
           )
        values
          (v_order_id,
           var_ord.create_date,
           var_ord.modify_date,
           1,
           replace(var_ord.address, var_ord.area_name, ''),
           var_ord.amount_paid,
           var_ord.amount_paid,
           format_area_name(var_ord.area_name),
           var_ord.consignee,
           var_ord.coupon_discount,
           v_is_exchange_point,
           var_ord.expire,
           var_ord.fee,
           var_ord.freight,
           var_ord.invoice_title,
           var_ord.is_allocated_stock,
           v_is_exchange_point,
           nvl2(var_ord.coupon_name, 1, 0),
           var_ord.memo,
           var_ord.offset_amount,
           var_ord.payment_method_name,
           0,
           var_ord.phone,
           0,
           var_ord.promotion_discount,
           var_ord.promotion,
           0,
           0,
           0,
           var_ord.point,
           0,
           var_ord.shipping_method_name,
           var_ord.sn,
           decode(var_ord.order_status, 0, 1, 1, 2, 2, 5, 3, 7),
           var_ord.tax,
           0,
           0,
           var_ord.zip_code,
           get_area_id(format_area_name(var_ord.area_name)),
           var_ord.coupon_code,
           (select id from member where attributevalue1 = var_ord.member),
           11, -- v_payment_method_type, --在线支付 由于表中数据全部是在线支付 这里暂时写成固定为0
           51,
           51,
           -1,
           -1,
           'ONLINE_OLD_SYSTEM',
           null,--奶站配送员跟经销商的处理逻辑是什么
          null,
           null,
           var_ord.twid);
        update cux_syjd_order set status = 'Y',error_message = '插入成功' where twid = var_ord.twid;
        else
          update orders set
          LASTMODIFIEDDATE = var_ord.modify_date,                           
           VERSION = version+1,
           ADDRESS = replace(var_ord.address, var_ord.area_name, ''),
           AMOUNT = var_ord.amount_paid,
           AMOUNTPAID = var_ord.amount_paid,
           AREANAME = format_area_name(var_ord.area_name),
           order_from = 'ONLINE_OLD_SYSTEM',
           --COMPLETEDATE,
           CONSIGNEE = var_ord.consignee,
           COUPONDISCOUNT = var_ord.coupon_discount,
           EXCHANGEPOINT = v_is_exchange_point,
           EXPIRE = var_ord.expire,   
           FEE =  var_ord.fee,
           FREIGHT =  var_ord.freight,
           --INVOICECONTENT,
           INVOICETITLE = var_ord.invoice_title,
           ISALLOCATEDSTOCK =  var_ord.is_allocated_stock,
           ISEXCHANGEPOINT = v_is_exchange_point,
           ISUSECOUPONCODE = nvl2(var_ord.coupon_name, 1, 0),
           MEMO = var_ord.memo,
           OFFSETAMOUNT = var_ord.offset_amount,
           PAYMENTMETHODNAME = var_ord.payment_method_name,
           PAYMENTMETHODTYPE = 0,
           PHONE = var_ord.phone,
           PRICE = 0, --全部写为0
           PROMOTIONDISCOUNT = var_ord.promotion_discount,
           PROMOTIONNAMES = var_ord.promotion,
           QUANTITY  = 0, --0
           REFUNDAMOUNT = 0, --0
           RETURNEDQUANTITY = 0, --0
           REWARDPOINT = var_ord.point,
           SHIPPEDQUANTITY = 0, --0
           SHIPPINGMETHODNAME =  var_ord.shipping_method_name,
           SN =  var_ord.sn,
           STATUS = decode(var_ord.order_status, 0, 1, 1, 2, 2, 5, 3, 7),
           TAX = var_ord.tax,
           TYPE = 0,
           WEIGHT = 0,
           ZIPCODE = var_ord.zip_code,
           AREA_ID = get_area_id(format_area_name(var_ord.area_name)),
           COUPONCODE_ID = var_ord.coupon_code,
           MEMBER_ID = (select id from member where attributevalue1 = var_ord.member),
           PAYMENTMETHOD_ID = 11,
           SHIPPINGMETHOD_ID = 51, --配送到户 51
           STORE_ID =51,
           CREATED_BY = '-1', -- 默认为-1
           LAST_UPDATED_BY = '-1'--默认为-1
           where twid = var_ord.twid;
          update cux_syjd_order set status = 'Y',error_message = '编辑成功' where twid = var_ord.twid;
          end if;
        --var_ord.distributor);
      
        /*open cur_ord_item(var_ord.id);
        fetch cur_ord_item
        into l_quantity;
        close cur_ord_item;
        
        if nvl(l_quantity,0)!=0 then*/
        --v_order_line_status
      exception
        when others then
          v_message := '错误信息：' || sqlerrm;
     --     DBMS_OUTPUT.put_line(v_message);
          update cux_syjd_order
             set status = 'N', error_message = v_message
           where id = var_ord.id;
      end;
      if v_cnt = 10000 then
        commit;
        v_cnt := 0;
      end if;
      v_cnt := v_cnt + 1;
      commit;
    end loop;
    var_line_cnt := 0;
    for var_ord_item in cur_ord_item loop
          begin
             select count(1) into v_count_line from orderitem where twid = var_ord_item.twid;
            --判断订单行状态
           
            if var_ord_item.end_date < sysdate then
              v_order_line_status := 'FINISH';
            else
              v_order_line_status := 'CONFIRM';
            end if;
						--优选鲜牛乳 优选鲜牛乳(240ml*20)
						IF var_ord_item.Sn = '2016061412322' THEN
							VAR_ORDERITEM_SN := '9.001.0043';
						ELSIF var_ord_item.sn = '9.004.0166.2' THEN
							VAR_ORDERITEM_SN := '9.004.0293';
						ELSIF  var_ord_item.Sn = '2016061412323' THEN
							VAR_ORDERITEM_SN := '9.004.0199';
						ELSE
							VAR_ORDERITEM_SN := REPLACE(var_ord_item.Sn,'-','.');
						END IF;
						
						SELECT PRD.NAME
						INTO VAR_ORDERITEM_NAME
						FROM PRODUCT PRD 
						WHERE PRD.SN = VAR_ORDERITEM_SN;
						
           if v_count_line = 0 then
            insert into orderitem
              (ID,
               CREATEDDATE,
               LASTMODIFIEDDATE,
               VERSION,
               COMMISSIONTOTALS,
               ISDELIVERY,
               NAME,
               PRICE,
               PAY_PRICE,
               QUANTITY,
               RETURNEDQUANTITY,
               SHIPPEDQUANTITY,
               SN,
               PRODUCT_SN,
               --SPECIFICATIONS,
               --THUMBNAIL,
               TYPE,
               WEIGHT,
               ORDERS,
               --SKU_ID,
               CREATED_BY,
               LAST_UPDATED_BY,
               ORDER_DATE_FROM,
               ORDER_DATE_TO,
               ORDER_DAYS,
               DAILY_DELIVERY_QUANTITY,
               DELIVERY_DAYS, --0
               REMAIN_DAYS,
               LINE_STATUS, --''NEW,新建CONFIRM,确认CANCEL,取消PAUSE,暂停FINISH,完成
               DAY_SHIPPING_TIME,
               SHIPPING_TYPE,
               ORIGINAL_ORDER_DATE_TO,
               twid)
            values
              (get_primary_id('ORDERITEM'),
               var_ord_item.create_date,
               var_ord_item.modify_date,
               '1',
               '0.000000',
               '1',
               VAR_ORDERITEM_NAME,
               var_ord_item.price,
               var_ord_item.price,
               var_ord_item.total_quantity,
               0,
               0,
							 VAR_ORDERITEM_SN,
							 VAR_ORDERITEM_SN,
              /* var_ord_item.sn,
               var_ord_item.sn,*/
               0,
               --var_ord_item.thumbnail,
               var_ord_item.weight,
               (select id from orders where twid = var_ord_item.orders and rownum<=1),
               -1,
               -1,
               var_ord_item.start_date,
               var_ord_item.end_date,
               var_ord_item.total_days,
               var_ord_item.quantity,
               0,
               var_ord_item.total_days,
               v_order_line_status,
               var_ord_item.shipping_time,
               var_ord_item.shipping_method,
               var_ord_item.end_date,
               var_ord_item.twid);
            update cux_syjd_order_item
               set status = 'Y',error_message = '插入成功'
             where twid = var_ord_item.twid;
             else
               update orderitem
               set
               LASTMODIFIEDDATE = var_ord_item.modify_date,
               orders = (select id from orders where twid = var_ord_item.orders and rownum<=1),
               VERSION = version+1,
               NAME = var_ord_item.name,
               PRICE =  var_ord_item.price,
               PAY_PRICE =  var_ord_item.price,
               QUANTITY = var_ord_item.total_quantity,
               SN = var_ord_item.sn,
               PRODUCT_SN = var_ord_item.sn,
               --SPECIFICATIONS,
               --THUMBNAIL,
               WEIGHT = var_ord_item.weight,
               --SKU_ID,
               ORDER_DATE_FROM = var_ord_item.start_date,
               ORDER_DATE_TO = var_ord_item.end_date,
               ORDER_DAYS = var_ord_item.total_days,
               DAILY_DELIVERY_QUANTITY = var_ord_item.quantity,
               REMAIN_DAYS =  var_ord_item.total_days,
               LINE_STATUS = v_order_line_status, --''NEW,新建CONFIRM,确认CANCEL,取消PAUSE,暂停FINISH,完成
               DAY_SHIPPING_TIME = var_ord_item.shipping_time,
               SHIPPING_TYPE = var_ord_item.shipping_method
               where twid =  var_ord_item.twid;
               update cux_syjd_order_item
               set status = 'Y',error_message = '更新成功'
               where twid = var_ord_item.twid;
               end if;
               exception
        when others then
          v_message := '错误信息：' || sqlerrm;
    ---      DBMS_OUTPUT.put_line(v_message);
          update cux_syjd_order_item
             set status = 'N', error_message = v_message
           where id = var_ord.id;
      end;
      if var_line_cnt = 10000 then
        commit;
        var_line_cnt := 0;
      end if;
      var_line_cnt := var_line_cnt + 1;
      commit;
        end loop;
    COMMIT;
  end;

  --导入客户（经销商）
  procedure import_dealers is
    cursor cur_dealers is
      select * from cux_syjd_distributor order by create_date desc;
    var_dealers cur_dealers%rowtype;
    v_message   varchar2(120);
  begin
    for var_dealers in cur_dealers loop
      begin
        insert into dealers
          (id,
           dealers_code,
           dealers_name,
           --contactor,
           --tel_number,
           CREATION_DATE,
           LAST_UPDATE_DATE)
        values
          (get_primary_id('DEALERS'),
           var_dealers.code,
           var_dealers.name,
           var_dealers.create_date,
           var_dealers.modify_date);
        update cux_syjd_distributor
           set status = 'Y'
         where id = var_dealers.id;
      exception
        when others then
          v_message := '错误信息：' || sqlerrm;
       --   DBMS_OUTPUT.put_line(v_message);
          update cux_syjd_distributor
             set status = 'Y', error_message = v_message
           where id = var_dealers.id;
      end;
      commit;
    end loop;
  end;
  --导入奶站 
  procedure import_milkstation is
    cursor cur_ms is
      select * from cux_syjd_store order by create_date desc;
    var_ms                 cur_ms%rowtype;
    v_message              varchar2(120);
    var_new_milkstation_id number;
  begin
    for var_ms in cur_ms loop
      var_new_milkstation_id := get_primary_id('MILK_STATION');
      begin
        insert into milk_station
          (id,
           DEALERS_ID,
           MILK_STATION_CODE,
           MILK_STATION_NAME,
           MANAGER,
           TEL_NUMBER,
           AREA_ID,
           DETAILED_ADDRESS,
           LONGITUDE,
           LATITUDE,
           STATUS,
           JZ_FLAG,
           --CREDIT_SCORE,
           LAST_UPDATE_DATE,
           LAST_UPDATED_BY,
           CREATION_DATE,
           CREATED_BY)
        values
          (var_new_milkstation_id,
           get_dealers_id(var_ms.distributor_name),
           var_ms.code,
           var_ms.name,
           var_ms.apply_man,
           var_ms.contact_telephone,
           var_ms.area,
           var_ms.address,
           var_ms.mapy,
           var_ms.mapx,
           'NEW',
           --var_ms.check_status, --审核状态
           var_ms.is_main_store, --是否基站
           var_ms.modify_date,
           -1,
           var_ms.create_date,
           -1);
        update cux_syjd_store
           set status = 'Y', new_milk_station_id = var_new_milkstation_id
         where id = var_ms.id;
      exception
        when others then
          v_message := '错误信息：' || sqlerrm;
     ---     DBMS_OUTPUT.put_line(v_message);
          update cux_syjd_store
             set status = 'Y', error_message = v_message
           where id = var_ms.id;
      end;
      commit;
    end loop;
  end;
  --根据经销商名称 获取导入后的经销商id
  function get_dealers_id(p_dealers_name cux_syjd_store.distributor_name%type)
    return number is
    v_dealers_id dealers.id%type;
  begin
    select d.id
      into v_dealers_id
      from dealers d
     where d.dealers_name = p_dealers_name;
    return v_dealers_id;
  end get_dealers_id;

  --根据奶站名 获取导入后的经销商id
  function get_dealers_id_by_id(p_milk_station_id number) return number is
    v_dealers_id milk_station.dealers_id%type;
  begin
    select ms.dealers_id
      into v_dealers_id
      from milk_station ms
     where ms.id = p_milk_station_id;
    return v_dealers_id;
  end get_dealers_id_by_id;

  --根据奶站id获取导入后的奶站id
  function get_milk_station_id(p_milk_station_id xx_dilivery_man.store%type)
    return number is
    v_milk_station_id milk_station.id%type;
  begin
    select css.new_milk_station_id
      into v_milk_station_id
      from cux_syjd_store css
     where css.id = p_milk_station_id;
    return v_milk_station_id;
  end get_milk_station_id;

  --导入配送员
  procedure import_ms_courier is
    cursor cur_ms_cou is
      select * from xx_dilivery_man;
    v_ms_cou          cur_ms_cou%rowtype;
    v_message         varchar2(120);
    v_user_id         number(10);
    v_cnt             number;
    v_milk_station_id number;
    v_count           number;
  begin
    v_cnt := 0;
    for v_ms_cou in cur_ms_cou loop
      begin
        v_user_id         := fnd_user_s.nextval;
        v_milk_station_id := get_milk_station_id(v_ms_cou.store);
        select count(*)
          into v_count
          from fnd_users
         where mobilephone = v_ms_cou.phone;
        --判断该电话号是否已存在于fnd_users中
        if v_count = 0 then
          insert into fnd_users
            (user_id,
             user_type,
             login_username,
             login_password,
             status,
             name,
             --sex,
             --id_card,
             --photo,
             last_updated_by,
             start_date,
             last_update_date,
             creation_date,
             mobilephone)
          values
            (v_user_id,
             'MS_COURIER',
             'COURIER_' || v_user_id,
             '25F9E794323B453885F5181F1B624D0B', --默认密码为123456789 该密码是经过MD5加密后的值
             'VALID',
             v_ms_cou.username,
             -1,
             sysdate,
             sysdate,
             sysdate,
             v_ms_cou.phone);
        end if;
      
        insert into ms_courier
          (ID,
           DEALERS_ID,
           MILK_STATION_ID,
           MS_COURIER_CODE,
           MS_COURIER_NAME,
           CONTACTOR,
           TEL_NUMBER,
           STATUS,
           --SCORE,
           LAST_UPDATE_DATE,
           CREATION_DATE,
           last_updated_by,
           created_by,
           USER_ID)
        values
          (get_primary_id('MS_COURIER'),
           get_dealers_id_by_id(v_milk_station_id),
           v_milk_station_id,
           v_ms_cou.account,
           v_ms_cou.username,
           v_ms_cou.username,
           v_ms_cou.phone,
           'VALID',
           to_date(v_ms_cou.modify_date, 'YYYY-MM-DD HH24:MI:SS'),
           to_date(v_ms_cou.create_date, 'YYYY-MM-DD HH24:MI:SS'),
           -1,
           -1,
           v_user_id);
        update xx_dilivery_man set status = 'Y' where id = v_ms_cou.id;
        if v_cnt = 10000 then
          commit;
          v_cnt := 0;
        end if;
        v_cnt := v_cnt + 1;
      end;
    end loop;
    commit;
  exception
    when others then
      v_message := '错误信息：' || sqlerrm;
  ---    DBMS_OUTPUT.put_line(v_message);
      update xx_dilivery_man
         set status = 'Y', error_message = v_message
       where id = v_ms_cou.id;
  end;

  --订单area_name 格式化
  function format_area_name(p_area_name in cux_syjd_order.area_name%type)
    return varchar2 is
    v_area_name orders.areaname%type;
    v_area_sub  varchar2(120);
  begin
    select substr(p_area_name, 1, 3) into v_area_sub from dual;
    if v_area_sub = '北京市' then
      v_area_name := replace(p_area_name, '北京市', '北京市市辖区'); --暂时先写北京市和天津市，后面有需要再添加
    elsif v_area_sub = '天津市' then
      v_area_name := replace(p_area_name, '天津市', '天津市市辖区');
    else
      v_area_name := p_area_name;
    end if;
    return v_area_name;
  end;

  --根据同旺订单area_name，获取area_name格式化后的area_id
  function get_area_id(p_area_name cux_syjd_order.area_name%type)
    return number is
    v_area_id area.id%type;
  begin
    select id into v_area_id from area where fullname_var = p_area_name;
    return v_area_id;
  end;

  --从订单表orders导入地址到地址库(地址库已修改，这部分不执行了)
  procedure import_addressbase(p_order_id in orders.id%type) is
    cursor cur_ord is
      select * from orders where id = p_order_id;
    var_ord   cur_ord%rowtype;
    v_message varchar2(120);
    v_count   number(10);
  begin
    for var_ord in cur_ord loop
      begin
        --判断地址库是否存在
        select count(*)
          into v_count
          from addressbase
         where area_id = var_ord.area_id
           and detailed_address = var_ord.address;
        --如果不存在，插入一条新地址库数据  
        if v_count = 0 then
          insert into addressbase
            (id,
             area_id,
             detailed_address,
             priority,
             dealers_id,
             milk_station_id,
             ms_courier_id,
             last_update_date,
             creation_date,
             last_updated_by,
             created_by)
          values
            (get_primary_id('ADDRESSBASE'),
             var_ord.area_id,
             var_ord.address,
             '0', --优先级 默认为0
             var_ord.dealer_id,
             var_ord.milk_station_id,
             var_ord.ms_courier_id,
             var_ord.lastmodifieddate,
             var_ord.createddate,
             -1,
             -1);
        end if;
      exception
        when others then
          v_message := '错误信息：' || sqlerrm;
       ---   DBMS_OUTPUT.put_line(v_message);
      end;
    end loop;
    commit;
  end import_addressbase;

  --每10000条 commit 一次
  procedure import_addressbase_batch is
    cursor cur_ord_bat is
      select * from orders order by createddate desc;
    v_ord_bat cur_ord_bat%rowtype;
    v_message varchar2(120);
    v_cnt     number;
    -- v_begin_number number(10):=1;
    -- v_end_number number(10):=5000;
  begin
    v_cnt := 0;
    for v_ord_bat in cur_ord_bat loop
      import_addressbase(v_ord_bat.id);
      if v_cnt = 10000 then
        commit;
      end if;
      v_cnt := v_cnt + 1;
    end loop;
  exception
    when others then
      v_message := '错误信息：' || sqlerrm;
 --     DBMS_OUTPUT.put_line(v_message);
  end;

  --根据配送员姓名，奶站id，获取导入后的配送员id
  function get_ms_courier_id(p_ms_courier_name cux_syjd_order.send_people%type,
                             p_milk_station_id cux_syjd_order.stores%type)
    return number is
    v_ms_courier_id ms_courier.id%type;
  begin
    select mc.id
      into v_ms_courier_id
      from ms_courier mc
     where mc.ms_courier_name = p_ms_courier_name
       and mc.milk_station_id = get_milk_station_id(p_milk_station_id)
       and rownum = 1;
    return v_ms_courier_id;
  end;

  --先在cux_syjd_order表中将需要更新的数据更新到新字段中，然后再导入，目的提升速度
  procedure update_cux_order is
    cursor cur_ord is
      select cso.id,
             --cso.member,
             cso.distributor,
             cso.stores,
             cso.send_people
      -- format_area_name(area_name) format_area_name
        from cux_syjd_order cso
      --where cso.status is null
      --and rownum <= 150000
       order by cso.create_date desc;
    var_ord   cur_ord%rowtype;
    v_message varchar2(120);
    v_cnt     number;
    --v_store_name varchar2(20);
  begin
    v_cnt := 0;
    for var_ord in cur_ord loop
      /*select name
       into v_store_name
       from cux_syjd_store
      where id = var_ord.stores;*/
      update cux_syjd_order
         set --format_area_name    = var_ord.format_area_name,
             --new_area_id         = get_area_id(var_ord.format_area_name),
             --new_member_id       = get_member_id(var_ord.member),
                   new_dealers_id = get_dealers_id(var_ord.distributor),
             new_milk_station_id = get_milk_station_id(var_ord.stores),
             new_ms_courier_id   = get_ms_courier_id(var_ord.send_people,
                                                     var_ord.stores)
      --status = 'R',
      --error_message = ''
       where id = var_ord.id;
      if v_cnt = 10000 then
        commit;
        v_cnt := 0;
      end if;
      v_cnt := v_cnt + 1;
    end loop;
    commit;
  exception
    when others then
      v_message := '错误信息：' || sqlerrm;
  ---    DBMS_OUTPUT.put_line(v_message);
  end;
  --导入收货地址
  procedure import_receiver is
    cursor cur_rec is
      select * from xx_receiver where status = 'N';
    var_rec       cur_rec%rowtype;
    v_message     varchar2(120);
    var_area_name varchar2(120);
    var_count     number(10);
  begin
    for var_rec in cur_rec loop
      begin
        select count(*) into var_count from receiver where twid = var_rec.twid;
        var_area_name := format_area_name(var_rec.area_name);
        if var_count = 0 then
        insert into receiver
          (id,
           createddate,
           lastmodifieddate,
           version,
           address,
           areaname,
           consignee,
           isdefault,
           phone,
           zipcode,
           area_id,
           member_id,
           last_updated_by,
           --milk_station_id,
           --courier_id,
           status,
           twid)
        values
          (get_primary_id('RECEIVER'),
           sysdate,
           sysdate,
           1,
           var_rec.address,
           var_area_name,
           var_rec.consignee,
           nvl(var_rec.is_default, 0),
           var_rec.phone,
           var_rec.zip_code,
           get_area_id(var_area_name),
           get_member_id(var_rec.member),
           -1,
           var_rec.status,
           var_rec.twid);
           update xx_receiver
           set status = 'Y', error_message = '插入成功'
         where id = var_rec.id;
          else
            update receiver set
           lastmodifieddate = sysdate,
           version = version + 1,
           address = var_rec.address,
           areaname = var_area_name,
           consignee = var_rec.consignee,
           isdefault = nvl(var_rec.is_default, 0),
           phone =  var_rec.phone,
           zipcode = var_rec.zip_code,
           area_id = get_area_id(var_area_name),
           member_id = get_member_id(var_rec.member),
           last_updated_by = -1,
           --milk_station_id,
           --courier_id,
           status = var_rec.status,
           twid = var_rec.twid
           where twid = var_rec.twid;
            update xx_receiver
           set status = 'Y', error_message = '更新成功'
         where twid = var_rec.twid;
            end if;
      exception
        when others then
          v_message := '错误信息：' || sqlerrm;
       ---   DBMS_OUTPUT.put_line(v_message);
          update xx_receiver
             set status = 'N', error_message = v_message
           where id = var_rec.id;
      end;
			 commit;
    end loop;
  end;

  procedure main is
  begin
    import_customer;
    import_order;
    import_dealers;
    import_milkstation;
    import_ms_courier;
    import_addressbase_batch;
    import_receiver;
  end;
end cux_import_tw_pkg;
/

