create view CUX_ORDERITEM_V as
  select id,name,sn from orderitem
/

