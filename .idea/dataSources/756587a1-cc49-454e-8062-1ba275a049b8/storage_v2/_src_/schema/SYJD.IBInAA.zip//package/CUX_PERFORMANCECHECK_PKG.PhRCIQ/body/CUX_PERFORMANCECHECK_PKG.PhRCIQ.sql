create package body cux_performancecheck_pkg is

  procedure load_performance(p_yearnum         number,
                             p_milk_station_id number,
                             p_dealer_name     varchar2) is
    cursor cur_item is
      select *
        from cux_saletask_t cst
       where 1 = 1
         and nvl(year, cst.year) = cst.year
         and nvl(p_milk_station_id, cst.milk_station_id) =
             cst.milk_station_id
         and nvl(p_dealer_name, cst.dealer_name) = cst.dealer_name;
  begin
    FOR var_saletask IN cur_item LOOP
      MERGE INTO cux_performance_check_t t --目标表
      USING (SELECT var_saletask.dealer_name     dealer_name,
                    var_saletask.milk_station_id milk_station_id,
                    var_saletask.year            year
               FROM dual) l
      ON (t.year = l.year and t.milk_station_id = l.milk_station_id)
      
      WHEN MATCHED THEN
        UPDATE
           SET id = performance_check_s.nextval,
               -- dealer_name         = var_saletask.dealer_name,
               -- milk_station_id     = var_saletask.milk_station_id,
               -- year                = p_yearnum,
               month1_performance  = getperformance(var_saletask.milk_station_id,
                                                    p_yearnum,
                                                    1),
               month1_task         = var_saletask.month1_task,
               month2_performance  = getperformance(var_saletask.milk_station_id,
                                                    p_yearnum,
                                                    2),
               month2_task         = var_saletask.month2_task,
               month3_performance  = getperformance(var_saletask.milk_station_id,
                                                    p_yearnum,
                                                    3),
               month3_task         = var_saletask.month3_task,
               month4_performance  = getperformance(var_saletask.milk_station_id,
                                                    p_yearnum,
                                                    4),
               month4_task         = var_saletask.month4_task,
               month5_performance  = getperformance(var_saletask.milk_station_id,
                                                    p_yearnum,
                                                    5),
               month5_task         = var_saletask.month5_task,
               month6_performance  = getperformance(var_saletask.milk_station_id,
                                                    p_yearnum,
                                                    6),
               month6_task         = var_saletask.month6_task,
               month7_performance  = getperformance(var_saletask.milk_station_id,
                                                    p_yearnum,
                                                    7),
               month7_task         = var_saletask.month7_task,
               month8_performance  = getperformance(var_saletask.milk_station_id,
                                                    p_yearnum,
                                                    8),
               month8_task         = var_saletask.month8_task,
               month9_performance  = getperformance(var_saletask.milk_station_id,
                                                    p_yearnum,
                                                    9),
               month9_task         = var_saletask.month9_task,
               month10_performance = getperformance(var_saletask.milk_station_id,
                                                    p_yearnum,
                                                    10),
               month10_task        = var_saletask.month10_task,
               month11_performance = getperformance(var_saletask.milk_station_id,
                                                    p_yearnum,
                                                    11),
               month11_task        = var_saletask.month11_task,
               month12_performance = getperformance(var_saletask.milk_station_id,
                                                    p_yearnum,
                                                    12),
               month12_task        = var_saletask.month12_task,
               created_by          = -1,
               creation_date       = sysdate,
               last_update_login   = -1,
               last_updated_by     = -1,
               last_update_date    = sysdate
      WHEN NOT MATCHED THEN
        insert
          (id,
           dealer_name,
           milk_station_id,
           year,
           month1_performance,
           month1_task,
           month2_performance,
           month2_task,
           month3_performance,
           month3_task,
           month4_performance,
           month4_task,
           month5_performance,
           month5_task,
           month6_performance,
           month6_task,
           month7_performance,
           month7_task,
           month8_performance,
           month8_task,
           month9_performance,
           month9_task,
           month10_performance,
           month10_task,
           month11_performance,
           month11_task,
           month12_performance,
           month12_task,
           created_by,
           creation_date,
           last_update_login,
           last_updated_by,
           last_update_date)
        values
          (performance_check_s.nextval,
           var_saletask.dealer_name,
           var_saletask.milk_station_id,
           p_yearnum,
           getperformance(var_saletask.milk_station_id, p_yearnum, 1),
           var_saletask.month1_task,
           getperformance(var_saletask.milk_station_id, p_yearnum, 2),
           var_saletask.month2_task,
           getperformance(var_saletask.milk_station_id, p_yearnum, 3),
           var_saletask.month3_task,
           getperformance(var_saletask.milk_station_id, p_yearnum, 4),
           var_saletask.month4_task,
           getperformance(var_saletask.milk_station_id, p_yearnum, 5),
           var_saletask.month5_task,
           getperformance(var_saletask.milk_station_id, p_yearnum, 6),
           var_saletask.month6_task,
           getperformance(var_saletask.milk_station_id, p_yearnum, 7),
           var_saletask.month7_task,
           getperformance(var_saletask.milk_station_id, p_yearnum, 8),
           var_saletask.month8_task,
           getperformance(var_saletask.milk_station_id, p_yearnum, 9),
           var_saletask.month9_task,
           getperformance(var_saletask.milk_station_id, p_yearnum, 10),
           var_saletask.month10_task,
           getperformance(var_saletask.milk_station_id, p_yearnum, 11),
           var_saletask.month11_task,
           getperformance(var_saletask.milk_station_id, p_yearnum, 12),
           var_saletask.month12_task,
           -1,
           sysdate,
           -1,
           -1,
           sysdate);
    end loop;
  end;

  FUNCTION getperformance(p_milk_station_id number,
                          p_yearnum         number,
                          p_monthnum        number) return number is
    v_performance number;
  BEGIN
    begin
    
      select sum(oi.QUANTITY * p.coefficient)
        into v_performance
        from Orders o, ORDERITEM oi, product p
       where o.id = oi.orders
         and oi.PRODUCT_SN = p.SN
         and o.milk_station_id = p_milk_station_id
         and TO_CHAR(oi.CREATEDDATE, 'yyyy- mm') =
             to_char(p_yearnum) || '-' || to_char(p_monthnum, '09');
    exception
      when others then
        v_performance := 0;
    end;
    return v_performance;
  END;

  function getdealerid(p_id number) return number is
    v_dealers_id number;
  begin
    select dealers_id
      into v_dealers_id
      from milk_station_line
     where id = p_id;
    return v_dealers_id;
  EXCEPTION
    WHEN NO_DATA_FOUND THEN
      RAISE_APPLICATION_ERROR(-20000, '不存在经销商id');
  end getdealerid;
  procedure load_saletask is
    cursor cur_saletask is
      select * from cux_saletask_temp cst;
    cursor cur_saletask_t is
      select * from cux_saletask_t;
    v_count           number;
    v_status          varchar2(10) := 'Y';
    v_error_message   varchar2(1000);
    v_milk_station_id number;
    repetFlag         boolean := false;
    ex exception;
  begin
    for var_saletask in cur_saletask loop
      begin
        ---判断经销商
        begin
          select count(*)
            into v_count
            from dealers dls, milk_station ms, milk_station_line msl
           where ms.id = msl.header_id
             and msl.dealers_id = dls.id
             and dls.abbreviation = var_saletask.dealer_name
             and ms.milk_station_name = var_saletask.milk_station_name;
          if v_count = 0 then
            v_status        := 'E';
            v_error_message := '经销商与奶站不匹配！';
          end if;
        end;
        ------获取奶站ID        
        begin
          select id
            into v_milk_station_id
            from milk_station
           where milk_station_name = var_saletask.milk_station_name;
        exception
          when others then
            v_status        := 'E';
            v_error_message := '未能找到正确的奶站！';
        end;
      
        if v_status = 'Y' then
        
          repetFlag := false;
        
          ---查找重复行并且更新
          for var_item in cur_saletask_t loop
          
            if v_milk_station_id = var_item.milk_station_id and
               var_saletask.dealer_name = var_item.dealer_name and
               var_saletask.year = var_item.year then
              update cux_saletask_t
                 set month1_task  = var_saletask.month1_task,
                     month2_task  = var_saletask.month2_task,
                     month3_task  = var_saletask.month3_task,
                     month4_task  = var_saletask.month4_task,
                     month5_task  = var_saletask.month5_task,
                     month6_task  = var_saletask.month6_task,
                     month7_task  = var_saletask.month7_task,
                     month8_task  = var_saletask.month8_task,
                     month9_task  = var_saletask.month9_task,
                     month10_task = var_saletask.month10_task,
                     month11_task = var_saletask.month11_task,
                     month12_task = var_saletask.month12_task
               where year = var_saletask.year
                 and dealer_name = var_saletask.dealer_name
                 and milk_station_id = v_milk_station_id;   
              repetFlag := true;
               exit;
            end if;
          end loop;
          ---查找重复行并且更新
        
          if repetFlag = false then
            ---在正式表不存在测插入
            insert into cux_saletask_t
              (id,
               milk_station_id,
               dealer_name,
               year,
               month1_task,
               month2_task,
               month3_task,
               month4_task,
               month5_task,
               month6_task,
               month7_task,
               month8_task,
               month9_task,
               month10_task,
               month11_task,
               month12_task,
               created_by,
               creation_date,
               last_update_login,
               last_updated_by,
               last_update_date)
            values
              (saletask_s.nextval,
               v_milk_station_id,
               var_saletask.dealer_name,
               var_saletask.year,
               var_saletask.month1_task,
               var_saletask.month2_task,
               var_saletask.month3_task,
               var_saletask.month4_task,
               var_saletask.month5_task,
               var_saletask.month6_task,
               var_saletask.month7_task,
               var_saletask.month8_task,
               var_saletask.month9_task,
               var_saletask.month10_task,
               var_saletask.month11_task,
               var_saletask.month12_task,
               -1,
               sysdate,
               -1,
               -1,
               sysdate);
          end if;
        
          update cux_saletask_temp
             set status = 'Y', error_message = '正确'
           where id = var_saletask.id;
        else
          update CUX_SALETASK_TEMP
             set status = v_status, error_message = v_error_message
           where id = var_saletask.id;
        end if;
      
      exception
        when others then
          update CUX_SALETASK_TEMP
             set status = v_status, error_message = '数据异常！'
           where id = var_saletask.id;
          rollback;
      end;
    end loop;
  end load_saletask;
end cux_performancecheck_pkg;
/

