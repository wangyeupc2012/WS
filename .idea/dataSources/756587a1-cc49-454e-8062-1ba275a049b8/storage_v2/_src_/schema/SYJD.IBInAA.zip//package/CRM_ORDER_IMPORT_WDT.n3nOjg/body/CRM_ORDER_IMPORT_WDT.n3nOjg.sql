create package body crm_order_import_wdt is

  --导入正式表
  procedure import_into_orders(p_batch_id             in number,
                               p_insert_flag          out varchar2,
                               p_insert_error_message out varchar2) is
    cursor cur_order_header is
      select * from crm_order_header_temp t where batch_id = p_batch_id;
    -- and sn = 'JD20180511163347059612'
    --  and (t.insert_flag = '' OR T.INSERT_FLAG IS NULL);
    --   order by createddate desc;
    cursor cur_order_line(p_id crm_order_line_temp.orders%type) is
      select clt.*
        from crm_order_header_temp coh, crm_order_line_temp clt
       where coh.id = clt.orders
         and clt.orders = p_id --输入参数订单头id
            --  and (coh.insert_flag='' OR coh.insert_flag IS NULL)
         and coh.batch_id = p_batch_id;
  
    cursor cur_crm_order_line(p_ord_header_sn orders.sn%type) is
      select * --crm订单行
        from orderitem
       where orders = (select id from orders where sn = p_ord_header_sn);
  
    /*orders in
    (select id from crm_order_header_temp where sn = p_sn and batch_id =p_batch_id)*/
    -- order by createddate desc;
    var_ord_header cur_order_header%rowtype;
    var_ord_line   cur_order_line%rowtype;
  
    v_message      varchar2(1000);
    v_count        number;
    v_line_count   number;
    v_order_id     number;
    var_line_id    number;
    VAR_MEMBERRANK NUMBER;
    v_countline    number;
    v_wdtlinecount number := 0;
    v_newcountline number;
  
    v_edit_orderitemid number; --编辑订单行的时候订单行的ID；
  
    wdtOdLineExistInCrm boolean := false;
    crmOdLineExistInWdt boolean := false;
  begin
    for var_ord_header in cur_order_header loop
      begin
        --判断订单是否已导入
        --p_orders:=var_ord_header.id;
        select count(*)
          into v_count
          from orders
         where sn = var_ord_header.sn;
        ---订单头在crm不存在 新增订单头 订单行 商品 促销
        if v_count = 0 then
          --  begin
          v_order_id := get_primary_id('ORDERS');
          --插入订单头表
          insert into orders
            (id,
             CREATEDDATE,
             LASTMODIFIEDDATE,
             VERSION,
             ADDRESS,
             AMOUNT,
             AMOUNTPAID,
             AREANAME,
             --COMPLETEDATE,
             CONSIGNEE,
             COUPONDISCOUNT,
             EXCHANGEPOINT,
             EXPIRE,
             FEE,
             FREIGHT,
             --INVOICECONTENT,
             INVOICETITLE,
             ISALLOCATEDSTOCK,
             ISEXCHANGEPOINT,
             ISUSECOUPONCODE,
             MEMO,
             OFFSETAMOUNT,
             PAYMENTMETHODNAME,
             PAYMENTMETHODTYPE,
             PHONE,
             PRICE, --全部写为0
             PROMOTIONDISCOUNT,
             PROMOTIONNAMES,
             QUANTITY,
             REFUNDAMOUNT, --0
             RETURNEDQUANTITY, --0
             REWARDPOINT,
             SHIPPEDQUANTITY, --0
             SHIPPINGMETHODNAME,
             SN,
             STATUS,
             TAX,
             TYPE,
             WEIGHT,
             ZIPCODE,
             AREA_ID,
             COUPONCODE_ID,
             MEMBER_ID,
             SHIPPINGMETHOD_ID, --配送到户 51
             STORE_ID,
             CREATED_BY, -- 默认为-1
             LAST_UPDATED_BY, --默认为-1
             ORDER_FROM,
             MILK_STATION_ID,
             DEALER_ID,
             poi_uid,
             poi_title,
             complete_address,
             buyer_remark,
             seller_remark,
             pay_date,
             receiver_id,
             DEL_FLAG,
             ORDERREFUNDS_STATUS,
             ACTUALAMOUNT,
             mode_of_distribution,
             exchange_flag,
             exchange_flag_money,
             CRM_WRITE_DATE,
             MAIN_ORDER_SN,
             milk_card_sn,
             alias_code)
          values
            (v_order_id,
             var_ord_header.createddate,
             var_ord_header.lastmodifieddate,
             1,
             var_ord_header.address,
             nvl(var_ord_header.amount, 0),
             nvl(var_ord_header.amountpaid, 0),
             (select to_char(a.fullname)
                from area a
               where to_char(a.fullname) = decode(var_ord_header.province_name,
                                                  '北京',
                                                  '北京市',
                                                  '天津',
                                                  '天津市',
                                                  var_ord_header.province_name) ||
                     decode(var_ord_header.city_name,
                                                  '北京市',
                                                  '市辖区',
                                                  '天津市',
                                                  '市辖区',
                                                  var_ord_header.city_name) ||
                     var_ord_header.areaname),
             --var_ord_header.areaname,
             var_ord_header.consignee,
             var_ord_header.coupondiscount,
             var_ord_header.exchangepoint,
             var_ord_header.expire,
             var_ord_header.fee,
             var_ord_header.freight,
             var_ord_header.invoicetitle,
             var_ord_header.isallocatedstock,
             var_ord_header.isexchangepoint,
             var_ord_header.isusecouponcode,
             var_ord_header.seller_remark,
             var_ord_header.offsetamount,
             (select distinct meaning
                from fnd_lookup_values
               where lookup_type = 'PAYMENT_METHOD'
                 and lookup_code = var_ord_header.paymentmethodtype),
             var_ord_header.paymentmethodtype, --支付方式orders获取
             var_ord_header.phone,
             0,
             var_ord_header.promotiondiscount,
             var_ord_header.promotionnames,
             var_ord_header.quantity,
             var_ord_header.refundamount,
             var_ord_header.returnedquantity,
             --下面是积分 没找到
             var_ord_header.rewardpoint,
             var_ord_header.shippedquantity,
             var_ord_header.shippingmethodname,
             var_ord_header.sn,
             -- (select flv.lookup_code from fnd_lookup_values flv where flv.lookup_type = 'ORDER_STATUS' and flv.meaning = var_ord_header.status_name),
             --转换成旺店通订单的状态
             (select CRM_ORDER_STATUS_CODE
                from ORDER_STATUS_CONTRAST_T
               where WDT_ORDERSTATUS_CODE = var_ord_header.status_name),
             var_ord_header.tax,
             var_ord_header.type,
             var_ord_header.weight,
             var_ord_header.zipcode,
             (select id
                from area
               where to_char(fullname) = decode(var_ord_header.province_name,
                                                '北京',
                                                '北京市',
                                                '天津',
                                                '天津市',
                                                var_ord_header.province_name) ||
                     decode(var_ord_header.city_name,
                                                '北京市',
                                                '市辖区',
                                                '天津市',
                                                '市辖区',
                                                var_ord_header.city_name) ||
                     var_ord_header.areaname),
             var_ord_header.couponcode_id,
             var_ord_header.member_id,
             51,
             51,
             -1,
             -1,
             'WECHAT', --是否改成WDT
             (select id
                from milk_station
               where MILK_STATION_CODE = var_ord_header.milkstation_code),
             (select ms.dealers_id
                from milk_station ms
               where ms.id =
                     (select id
                        from milk_station
                       where MILK_STATION_CODE =
                             var_ord_header.milkstation_code)),
             var_ord_header.poi_uid,
             var_ord_header.poi_title,
             var_ord_header.complete_address,
             var_ord_header.buyer_remark,
             var_ord_header.seller_remark,
             var_ord_header.pay_time,
             (select r.id
                from receiver r
               where r.wdtid = var_ord_header.wdt_address_id),
             var_ord_header.del_flag,
             var_ord_header.refund_status,
             nvl(var_ord_header.amountpaid, 0),
             var_ord_header.mode_of_distribution,
             var_ord_header.exchange_flag,
             var_ord_header.exchange_flag_money,
             sysdate,
             var_ord_header.main_order_sn,
             var_ord_header.milk_card_sn,
             var_ord_header.alias_code);
        
          update crm_order_header_temp
             set insert_flag = 'Y', tid = ''
           where id = var_ord_header.id;
          --插入订单行表
          for var_ord_line in cur_order_line(var_ord_header.id) loop
            -- begin
            select get_primary_id('ORDERITEM') into var_line_id from dual;
            insert into orderitem
              (id,
               createddate,
               lastmodifieddate,
               version,
               commissiontotals,
               isdelivery,
               name,
               price,
               quantity,
               returnedquantity,
               shippedquantity,
               sn,
               specifications,
               thumbnail,
               type,
               weight,
               orders,
               sku_id,
               created_by,
               last_updated_by,
               order_date_from,
               order_date_to,
               order_days,
               daily_delivery_quantity,
               delivery_days,
               remain_days,
               line_status,
               day_shipping_time,
               shipping_type,
               original_order_date_to,
               product_sn,
               PROMOTION_ID,
               PAY_PRICE,
               wdtorderitemid,
               refund_status,
               TOTALPRICE,
               present_flag,
               change_wdtid,
               kuayue_change_flag)
            values
              (var_line_id,
               var_ord_line.createddate,
               var_ord_line.lastmodifieddate,
               var_ord_line.version,
               var_ord_line.commissiontotals,
               var_ord_line.isdelivery,
               var_ord_line.name,
               var_ord_line.price,
               var_ord_line.quantity,
               var_ord_line.returnedquantity,
               var_ord_line.shippedquantity,
               var_ord_line.sn,
               var_ord_line.specifications,
               var_ord_line.thumbnail,
               var_ord_line.type,
               var_ord_line.weight,
               v_order_id,
               var_ord_line.sku_id,
               -1,
               -1,
               var_ord_line.order_date_from,
               var_ord_line.order_date_to,
               var_ord_line.order_days,
               var_ord_line.daily_delivery_quantity,
               var_ord_line.delivery_days,
               var_ord_line.remain_days,
               var_ord_line.line_status,
               var_ord_line.day_shipping_time,
               var_ord_line.shipping_type,
               var_ord_line.original_order_date_to,
               var_ord_line.sn,
               var_ord_line.promotion_id,
               var_ord_line.pay_price,
               var_ord_line.wdtorderitemid,
               var_ord_line.refund_status,
               var_ord_line.totalprice,
               var_ord_line.present_flag,
               var_ord_line.change_wdtid,
               var_ord_line.kuayue_change_flag);
            update crm_order_line_temp
               set insert_flag = 'Y', tid = ''
             where id = var_ord_line.id;
          
            --暂停，促销
            import_into_pause_promotion(var_ord_line.id,
                                        p_batch_id,
                                        var_line_id);
          end loop;
        
          --更新会员等级
          /*SELECT MEM.MEMBERRANK_ID
          INTO VAR_MEMBERRANK
          FROM MEMBER MEM
          WHERE MEM.ID = var_ord_header.Member_Id;*/
          COMMIT;
        else
          ---订单头在crm存在
          update orders
             set LASTMODIFIEDDATE = sysdate,
                 VERSION          = VERSION + 1,
                 ADDRESS          = var_ord_header.address,
                 AMOUNT           = nvl(var_ord_header.amount, 0),
                 AMOUNTPAID       = nvl(var_ord_header.amountpaid, 0),
                 ACTUALAMOUNT     = nvl(var_ord_header.amountpaid, 0),
                 AREANAME        =
                 (select to_char(a.fullname)
                    from area a
                   where to_char(a.fullname) = decode(var_ord_header.province_name,
                                                      '北京',
                                                      '北京市',
                                                      var_ord_header.province_name) ||
                         decode(var_ord_header.city_name,
                                                      '北京市',
                                                      '市辖区',
                                                      var_ord_header.city_name) ||
                         var_ord_header.areaname),
                 --COMPLETEDATE,
                 CONSIGNEE      = var_ord_header.consignee,
                 COUPONDISCOUNT = var_ord_header.coupondiscount,
                 EXCHANGEPOINT  = var_ord_header.exchangepoint,
                 EXPIRE         = var_ord_header.expire,
                 FEE            = var_ord_header.fee,
                 FREIGHT        = var_ord_header.freight,
                 --INVOICECONTENT,
                 INVOICETITLE     = var_ord_header.invoicetitle,
                 ISALLOCATEDSTOCK = var_ord_header.isallocatedstock,
                 ISEXCHANGEPOINT  = var_ord_header.isexchangepoint,
                 ISUSECOUPONCODE  = var_ord_header.isusecouponcode,
                 /*MEMO               = var_ord_header.memo,*/
                 OFFSETAMOUNT       = var_ord_header.offsetamount,
                 PHONE              = var_ord_header.phone,
                 PRICE              = 0, --全部写为0
                 PROMOTIONDISCOUNT  = var_ord_header.promotiondiscount,
                 PROMOTIONNAMES     = var_ord_header.promotionnames,
                 QUANTITY           = var_ord_header.quantity,
                 REFUNDAMOUNT       = var_ord_header.refundamount,
                 RETURNEDQUANTITY   = var_ord_header.returnedquantity,
                 REWARDPOINT        = var_ord_header.rewardpoint,
                 SHIPPEDQUANTITY    = var_ord_header.shippedquantity,
                 SHIPPINGMETHODNAME = var_ord_header.shippingmethodname,
                 STATUS            =
                 (select CRM_ORDER_STATUS_CODE
                    from ORDER_STATUS_CONTRAST_T
                   where WDT_ORDERSTATUS_CODE = var_ord_header.status_name),
                 TAX                = var_ord_header.tax,
                 /* TYPE               = var_ord_header.type,*/
                 WEIGHT              = var_ord_header.weight,
                 ZIPCODE             = var_ord_header.zipcode,
                 AREA_ID            =
                 (select id
                    from area
                   where to_char(fullname) = decode(var_ord_header.province_name,
                                                    '北京',
                                                    '北京市',
                                                    var_ord_header.province_name) ||
                         decode(var_ord_header.city_name,
                                                    '北京市',
                                                    '市辖区',
                                                    var_ord_header.city_name) ||
                         var_ord_header.areaname),
                 COUPONCODE_ID       = var_ord_header.couponcode_id,
                 MEMBER_ID           = var_ord_header.member_id,
                 del_flag            = var_ord_header.del_flag,
                 ORDERREFUNDS_STATUS = var_ord_header.refund_status,
                 paymentmethodname  =
                 (select distinct meaning
                    from fnd_lookup_values
                   where lookup_type = 'PAYMENT_METHOD'
                     and lookup_code = var_ord_header.paymentmethodtype),
                 PAYMENTMETHODTYPE   = var_ord_header.paymentmethodtype,
                 /* MILK_STATION_ID = 暂时不会出现更换奶站的情况
                 (select id
                    from milk_station
                   where MILK_STATION_CODE = var_ord_header.milkstation_code),
                 DEALER_ID       =
                 (select ms.dealers_id
                    from milk_station ms
                   where ms.id =
                         (select id
                            from milk_station
                           where MILK_STATION_CODE =
                                 var_ord_header.milkstation_code)),*/
                 poi_uid              = var_ord_header.poi_uid,
                 poi_title            = var_ord_header.poi_title,
                 complete_address     = var_ord_header.complete_address,
                 buyer_remark         = var_ord_header.buyer_remark,
                 seller_remark        = var_ord_header.seller_remark,
                 pay_date             = var_ord_header.pay_time,
                 receiver_id         =
                 (select r.id
                    from receiver r
                   where r.wdtid = var_ord_header.wdt_address_id),
                 mode_of_distribution = var_ord_header.mode_of_distribution,
                 EXCHANGE_FLAG        = var_ord_header.exchange_flag,
                 EXCHANGE_FLAG_MONEY  = var_ord_header.exchange_flag_money,
                 MAIN_ORDER_SN        = var_ord_header.main_order_sn,
                 milk_card_sn         = var_ord_header.milk_card_sn,
                 alias_code           = var_ord_header.alias_code
           where sn = var_ord_header.sn;
        
          ---added by yuchao on 2018--06-21  begin
          update crm_order_header_temp
             set insert_flag = 'Y', tid = ''
           where id = var_ord_header.id;
          ---added by yuchao on 2018--06-21  end
          --added by longwy 2018-06-29 start
        
          --清掉接口表中没有 crm存在的订单行start
          delete from orderitem ot
           where ot.orders =
                 (select id from orders where sn = var_ord_header.sn)
             and not exists
           (select clt.*
                    from crm_order_header_temp coh, crm_order_line_temp clt
                   where coh.id = clt.orders
                     and clt.orders = var_ord_header.id --输入参数订单头id
                     and clt.wdtorderitemid = ot.wdtorderitemid
                     and coh.batch_id = p_batch_id);
          --清掉接口表中没有 crm存在的订单行end
          --根据接口表更新与插入
          for var_wdt_ord_line in cur_order_line(var_ord_header.id) loop
          
            select count(1)
              into v_wdtlinecount
              from orderitem ot
             where ot.wdtorderitemid = var_wdt_ord_line.wdtorderitemid;
          
            if v_wdtlinecount > 0 then
              --更新订单行
              --更新crm订单行
              update orderitem
                 set lastmodifieddate        = sysdate,
                     version                 = version + 1,
                     commissiontotals        = var_wdt_ord_line.commissiontotals,
                     isdelivery              = var_wdt_ord_line.isdelivery,
                     name                    = var_wdt_ord_line.name,
                     price                   = var_wdt_ord_line.price,
                     quantity                = var_wdt_ord_line.quantity,
                     returnedquantity        = var_wdt_ord_line.returnedquantity,
                     shippedquantity         = var_wdt_ord_line.shippedquantity,
                     sn                      = var_wdt_ord_line.sn,
                     specifications          = var_wdt_ord_line.specifications,
                     thumbnail               = var_wdt_ord_line.thumbnail,
                     type                    = var_wdt_ord_line.type,
                     weight                  = var_wdt_ord_line.weight,
                     sku_id                  = var_wdt_ord_line.sku_id,
                     order_date_from         = var_wdt_ord_line.order_date_from,
                     order_date_to           = var_wdt_ord_line.order_date_to,
                     order_days              = var_wdt_ord_line.order_days,
                     daily_delivery_quantity = var_wdt_ord_line.daily_delivery_quantity,
                     delivery_days           = var_wdt_ord_line.delivery_days,
                     remain_days             = var_wdt_ord_line.remain_days,
                     line_status             = var_wdt_ord_line.line_status,
                     day_shipping_time       = var_wdt_ord_line.day_shipping_time,
                     shipping_type           = var_wdt_ord_line.shipping_type,
                     original_order_date_to  = var_wdt_ord_line.original_order_date_to,
                     product_sn              = var_wdt_ord_line.sn,
                     PROMOTION_ID            = var_wdt_ord_line.promotion_id,
                     PAY_PRICE               = var_wdt_ord_line.pay_price,
                     refund_status           = var_wdt_ord_line.refund_status,
                     present_flag            = var_wdt_ord_line.present_flag,
                     totalprice              = var_wdt_ord_line.totalprice,
                     change_wdtid            = var_wdt_ord_line.change_wdtid,
                     kuayue_change_flag      = var_wdt_ord_line.kuayue_change_flag
               where wdtorderitemid = var_wdt_ord_line.wdtorderitemid
                 and orders =
                     (select id from orders where sn = var_ord_header.sn);
              update crm_order_line_temp
                 set insert_flag = 'Y', tid = ''
               where id = var_wdt_ord_line.id;
              SELECT ID
                into v_edit_orderitemid
                FROM ORDERITEM
               WHERE wdtorderitemid = var_wdt_ord_line.wdtorderitemid
                 and orders =
                     (select id from orders where sn = var_ord_header.sn);
            
              crm_order_import_wdt.import_into_pause_promotion(var_wdt_ord_line.id,
                                                               p_batch_id,
                                                               v_edit_orderitemid);
            
              ----根据wdtorderitemid 更新对应的退款行 crm的orderitemid      added by longwy 2018/07/11               
              if var_wdt_ord_line.refund_status = 5 then
                update orderrefundsitem orfit
                   set orfit.orderitem_id =
                       (select id
                          from orderitem
                         where wdtorderitemid =
                               var_wdt_ord_line.wdtorderitemid)
                 where orfit.new_wdtorderitemid =
                       var_wdt_ord_line.wdtorderitemid;
              end if;
              ----根据wdtorderitemid 更新对应的退款行 crm的orderitemid      added by longwy 2018/07/11       
            
            else
              --插入wdt订单行
              select get_primary_id('ORDERITEM')
                into var_line_id
                from dual;
              insert into orderitem
                (id,
                 createddate,
                 lastmodifieddate,
                 version,
                 commissiontotals,
                 isdelivery,
                 name,
                 price,
                 quantity,
                 returnedquantity,
                 shippedquantity,
                 sn,
                 specifications,
                 thumbnail,
                 type,
                 weight,
                 orders,
                 sku_id,
                 created_by,
                 last_updated_by,
                 order_date_from,
                 order_date_to,
                 order_days,
                 daily_delivery_quantity,
                 delivery_days,
                 remain_days,
                 line_status,
                 day_shipping_time,
                 shipping_type,
                 original_order_date_to,
                 product_sn,
                 PROMOTION_ID,
                 PAY_PRICE,
                 wdtorderitemid,
                 refund_status,
                 TOTALPRICE,
                 present_flag,
                 change_wdtid,
                 kuayue_change_flag)
              values
                (var_line_id,
                 var_wdt_ord_line.createddate,
                 var_wdt_ord_line.lastmodifieddate,
                 var_wdt_ord_line.version,
                 var_wdt_ord_line.commissiontotals,
                 var_wdt_ord_line.isdelivery,
                 var_wdt_ord_line.name,
                 var_wdt_ord_line.price,
                 var_wdt_ord_line.quantity,
                 var_wdt_ord_line.returnedquantity,
                 var_wdt_ord_line.shippedquantity,
                 var_wdt_ord_line.sn,
                 var_wdt_ord_line.specifications,
                 var_wdt_ord_line.thumbnail,
                 var_wdt_ord_line.type,
                 var_wdt_ord_line.weight,
                 (select id from orders where sn = var_ord_header.sn),
                 var_wdt_ord_line.sku_id,
                 -1,
                 -1,
                 var_wdt_ord_line.order_date_from,
                 var_wdt_ord_line.order_date_to,
                 var_wdt_ord_line.order_days,
                 var_wdt_ord_line.daily_delivery_quantity,
                 var_wdt_ord_line.delivery_days,
                 var_wdt_ord_line.remain_days,
                 var_wdt_ord_line.line_status,
                 var_wdt_ord_line.day_shipping_time,
                 var_wdt_ord_line.shipping_type,
                 var_wdt_ord_line.original_order_date_to,
                 var_wdt_ord_line.sn,
                 var_wdt_ord_line.promotion_id,
                 var_wdt_ord_line.pay_price,
                 var_wdt_ord_line.wdtorderitemid,
                 var_wdt_ord_line.refund_status,
                 var_wdt_ord_line.Totalprice,
                 var_wdt_ord_line.present_flag,
                 var_wdt_ord_line.change_wdtid,
                 var_wdt_ord_line.kuayue_change_flag);
            
              update crm_order_line_temp
                 set insert_flag = 'Y', tid = ''
               where id = var_wdt_ord_line.id;
              crm_order_import_wdt.import_into_pause_promotion(var_wdt_ord_line.id,
                                                               p_batch_id,
                                                               var_line_id);
            
              ----根据wdtorderitemid 更新对应的退款行 crm的orderitemid      added by longwy 2018/07/11               
              if var_wdt_ord_line.refund_status = 5 then
                update orderrefundsitem orfit
                   set orfit.orderitem_id =
                       (select id
                          from orderitem
                         where wdtorderitemid =
                               var_wdt_ord_line.wdtorderitemid)
                 where orfit.new_wdtorderitemid =
                       var_wdt_ord_line.wdtorderitemid;
              end if;
              ----根据wdtorderitemid 更新对应的退款行 crm的orderitemid      added by longwy 2018/07/11   
            
            end if;
          end loop;
          commit;
          --added by longwy 2018-06-29 end
        
        end if;
      exception
        when others then
          rollback;
          v_message := '错误信息：' || sqlerrm;
          -- dbms_output.put_line(v_message);
          update crm_order_header_temp
             set insert_flag = 'E', insert_error_message = v_message
           where id = var_ord_header.id;
      end;
      COMMIT;
    end loop;
  exception
    when others then
      v_message              := '错误信息：' || sqlerrm;
      p_insert_flag          := 'E';
      p_insert_error_message := v_message;
      dbms_output.put_line(v_message);
  end;

  procedure import_into_pause_promotion(p_orderitemid in number, --订单行中间表ID
                                        p_batchId     in number, --批次id
                                        p_line_id     in number) is
    --索引生成的新crm订单行id
    --正式表行ID
    --新表中间行ID
    --暂停
    --暂停。
    cursor cur_order_pause_insertval(orderitemid order_pause_interval_temp.orderitem_id%type) is
      select opit.*
        from order_pause_interval_temp opit
       where opit.orderitem_id = p_orderitemid --输入参数订单行id
         and opit.batch_id = p_batchId;
    --促销
    cursor CUR_ORDER_PROMOTION(l_orderitemid ORDER_PROMOTION_TEMP.Orderitem_Id%type) is
      select cpt.*
        from ORDER_PROMOTION_TEMP cpt
       where cpt.orderitemid = p_orderitemid --输入参数订单行id
         and cpt.batch_id = p_batchId;
    var_pause_inerval   cur_order_pause_insertval%rowtype;
    VAR_ORDER_PROMOTION CUR_ORDER_PROMOTION%rowtype;
    v_pause_id          number;
  begin
    delete from order_pause_interval
     where orderitem_id = p_line_id;
       --and pause_from <> 'CRM_BATCH_PAUSE';
    delete from order_promotion where orderitem_id = p_line_id;
    for var_pause_inerval in cur_order_pause_insertval(p_orderitemid) loop
      select GET_PRIMARY_ID('ORDER_PAUSE_INTERVAL')
        into v_pause_id
        from dual;
      insert into order_pause_interval
        (id,
         createddate,
         lastmodifieddate,
         version,
         created_by,
         last_updated_by,
         orderitem_id,
         pause_status,
         quantity,
         pause_date_from,
         recovery_date,
         pause_index,
         pause_from,
         wdtpauseId,
         CRM_WRITE_DATE,
         batch_pause_id)
      VALUES
        (v_pause_id,
         var_pause_inerval.createddate,
         var_pause_inerval.lastmodifieddate,
         1,
         '-1',
         '-1',
         p_line_id,
         'Y',
         var_pause_inerval.quantity,
         var_pause_inerval.pause_date_from,
         var_pause_inerval.recovery_date + 1,
         0,
         nvl2(var_pause_inerval.batch_pause_id,'CRM_BATCH_PAUSE','WDT_PAUSE'),
         var_pause_inerval.wdtpauseid,
         sysdate,
         var_pause_inerval.batch_pause_id);
    end loop;
    update order_pause_interval_temp
       set message = 'Y'
     where orderitem_id = p_orderitemid
       and batch_id = p_batchId;
    for VAR_ORDER_PROMOTION in CUR_ORDER_PROMOTION(p_orderitemid) loop
      -- DBMS_OUTPUT.put_line(VAR_ORDER_PROMOTION.order_sn || VAR_ORDER_PROMOTION.product_sn || VAR_ORDER_PROMOTION.discount_price);
      INSERT INTO ORDER_PROMOTION
        (ID,
         ORDERS,
         ORDER_SN,
         PRODUCT_SN,
         PRODUCT_QUANTITY,
         PROMOTION_ID,
         DISCOUNT_PRICE,
         VERSION,
         CREATEDDATE,
         LASTMODIFIEDDATE,
         LAST_UPDATED_BY,
         CREATED_BY,
         ORDERITEM_ID,
         DISCOUNT_TYPE,
         CRM_PROMOTION_ID,
         WDT_PROMOTION_ID)
      VALUES
        (GET_PRIMARY_ID('ORDER_PROMOTION'),
         '',
         VAR_ORDER_PROMOTION.order_sn,
         VAR_ORDER_PROMOTION.product_sn,
         VAR_ORDER_PROMOTION.product_quantity,
         '',
         VAR_ORDER_PROMOTION.discount_price,
         1,
         sysdate,
         sysdate,
         -1,
         -1,
         p_line_id,
         VAR_ORDER_PROMOTION.discount_type,
         VAR_ORDER_PROMOTION.crm_promotion_id,
         VAR_ORDER_PROMOTION.wdt_promotion_id);
    end loop;
    update ORDER_PROMOTION_temp
       set message = 'Y'
     where orderitem_id = p_orderitemid
       and batch_id = p_batchId;
    commit;
  end;

  --导入公众号订单
  procedure import_other_province_orders(p_batch_id in number,
                                         p_result   out varchar2) is
    cursor cur_op is
      select *
        from cux_other_province_order_t t
       where t.batch_id = p_batch_id;
    var_op                cur_op%rowtype;
    var_flag              varchar2(20);
    var_total_deliver_num number;
    var_order_date_from   date;
    v_order_id            number;
    var_milk_station_id   number;
    var_last_num          number;
    var_total_quantity    number;
    var_each_quantity     number;
  begin
    for var_op in cur_op loop
      var_flag            := 'Y';
      var_order_date_from := to_date(var_op.deliver_start_date,
                                     'yyyy-MM-dd') + 1;
      if var_op.goods_sn = '9.004.0318' then
        var_total_quantity := var_op.total_quantity / 5;
        var_each_quantity  := var_op.each_deliver_num / 5;
      else
        var_total_quantity := var_op.total_quantity;
        var_each_quantity  := var_op.each_deliver_num;
      end if;
      var_total_deliver_num := ceil(var_total_quantity / var_each_quantity);
      var_last_num          := var_total_quantity - (var_total_deliver_num - 1) *
                               var_each_quantity;
    
      for i in 1 .. var_total_deliver_num loop
        begin
          v_order_id := get_primary_id('ORDERS');
          if var_op.province in ('北京', '天津', '河北省') then
            var_milk_station_id := '';
          else
            var_milk_station_id := 4747; --华传顺丰快递专送
          end if;
          --插入订单头表
          insert into orders
            (id,
             CREATEDDATE,
             LASTMODIFIEDDATE,
             VERSION,
             ADDRESS,
             AMOUNT,
             AMOUNTPAID,
             AREANAME,
             CONSIGNEE,
             COUPONDISCOUNT,
             EXCHANGEPOINT,
             EXPIRE,
             FEE,
             FREIGHT,
             INVOICETITLE,
             ISALLOCATEDSTOCK,
             ISEXCHANGEPOINT,
             ISUSECOUPONCODE,
             MEMO,
             OFFSETAMOUNT,
             PAYMENTMETHODNAME,
             PAYMENTMETHODTYPE,
             PHONE,
             PRICE, --全部写为0
             PROMOTIONDISCOUNT,
             PROMOTIONNAMES,
             QUANTITY,
             REFUNDAMOUNT, --0
             RETURNEDQUANTITY, --0
             REWARDPOINT,
             SHIPPEDQUANTITY, --0
             SHIPPINGMETHODNAME,
             SN,
             STATUS,
             TAX,
             TYPE,
             WEIGHT,
             ZIPCODE,
             AREA_ID,
             COUPONCODE_ID,
             MEMBER_ID,
             PAYMENTMETHOD_ID,
             SHIPPINGMETHOD_ID, --配送到户 51
             STORE_ID,
             CREATED_BY, -- 默认为-1
             LAST_UPDATED_BY, --默认为-1
             ORDER_FROM,
             MILK_STATION_ID,
             DEALER_ID,
             poi_uid,
             poi_title,
             complete_address,
             buyer_remark,
             seller_remark,
             pay_date,
             receiver_id,
             DEL_FLAG,
             ORDERREFUNDS_STATUS,
             ACTUALAMOUNT,
             mode_of_distribution,
             exchange_flag,
             exchange_flag_money,
             CRM_WRITE_DATE,
             MAIN_ORDER_SN,
             milk_card_sn,
             VALID_MILKSTATION_FLAG)
          values
            (v_order_id,
             sysdate,
             sysdate,
             1, --version
             var_op.detail_addr,
             var_op.total_quantity * var_op.goods_price, --amount
             0, --amountpaid
             (select to_char(a.fullname)
                from area a
               where to_char(a.fullname) =
                     decode(var_op.province,
                            '北京',
                            '北京市',
                            '天津',
                            '天津市',
                            '上海',
                            '上海市',
                            var_op.province) ||
                     decode(var_op.city,
                            '北京市',
                            '市辖区',
                            '天津市',
                            '市辖区',
                            '上海市',
                            '市辖区',
                            var_op.city) || var_op.district), --areaname
             var_op.addressee, --consignee
             0,
             0,
             '',
             0,
             0,
             '',
             0,
             0,
             0,
             '',
             0,
             '',
             '', --支付方式orders获取
             var_op.mobile,
             0,
             0,
             0,
             0,
             0,
             0,
             0,
             0,
             0,
             get_auto_order_sn('OPMC'), --order_sn
             2, --status 等待发货
             0, --tax
             1, --type 兑换订单
             0,
             '',
             (select id
                from area a
               where to_char(a.fullname) =
                     decode(var_op.province,
                            '北京',
                            '北京市',
                            '天津',
                            '天津市',
                            '上海',
                            '上海市',
                            var_op.province) ||
                     decode(var_op.city,
                            '北京市',
                            '市辖区',
                            '天津市',
                            '市辖区',
                            '上海市',
                            '市辖区',
                            var_op.city) || var_op.district),
             '',
             '',
             '', --支付方式ID获取还是获取orders序列
             51,
             51,
             -1,
             -1,
             'GZH', --order_sn
             var_milk_station_id,
             '',
             '',
             '',
             var_op.detail_addr,
             var_op.remark,
             '',
             to_date(var_op.create_time, 'yyyy-MM-dd HH24:mi:ss'),
             '',
             0,
             2,
             0,
             1, --一次性配送订单
             '',
             '',
             sysdate,
             var_op.order_sn,
             var_op.card_sn,
             decode(var_milk_station_id, 4747, 'Y', ''));
        
          insert into orderitem
            (id,
             createddate,
             lastmodifieddate,
             version,
             commissiontotals,
             isdelivery,
             name,
             price,
             quantity,
             returnedquantity,
             shippedquantity,
             sn,
             specifications,
             thumbnail,
             type,
             weight,
             orders,
             sku_id,
             created_by,
             last_updated_by,
             order_date_from,
             order_date_to,
             order_days,
             daily_delivery_quantity,
             delivery_days,
             remain_days,
             line_status,
             day_shipping_time,
             shipping_type,
             original_order_date_to,
             product_sn,
             PROMOTION_ID,
             PAY_PRICE,
             wdtorderitemid,
             refund_status,
             TOTALPRICE,
             present_flag,
             change_wdtid,
             kuayue_change_flag)
          values
            (get_primary_id('ORDERITEM'),
             sysdate,
             sysdate,
             0,
             0,
             0,
             decode(var_op.goods_sn,
                    '9.004.0318',
                    '166瓶装益生菌风味发酵乳（箱）',
                    var_op.goods_name),
             var_op.goods_price,
             var_each_quantity,
             /*decode(var_op.goods_sn,'9.004.0318',
             decode(i,
                     var_total_deliver_num,
                     var_last_num,
                     var_each_quantity),
             decode(i,
                    var_total_deliver_num,
                    var_last_num,
                    var_op.each_deliver_num)),*/
             0,
             0,
             decode(var_op.goods_sn,
                    '9.004.0318',
                    'TC20180604001',
                    var_op.goods_sn),
             '',
             '',
             0,
             0,
             v_order_id,
             '',
             -1,
             -1,
             var_order_date_from,
             var_order_date_from,
             1,
             /*decode(var_op.order_sn,
             '9.004.0318',
             (decode(i,
                     var_total_deliver_num,
                     var_last_num,
                     var_op.each_deliver_num) / 5),
             decode(i,
                    var_total_deliver_num,
                    var_last_num,
                    var_op.each_deliver_num)),*/
             var_each_quantity,
             0,
             1,
             0,
             0,
             0,
             var_order_date_from,
             decode(var_op.goods_sn,
                    '9.004.0318',
                    'TC20180604001',
                    var_op.goods_sn),
             '',
             var_op.goods_price,
             '',
             0,
             var_op.goods_price *
             var_each_quantity,
             0,
             '',
             '');
          var_order_date_from := var_order_date_from + var_op.interval_days + 1;
        exception
          when others then
            var_flag := 'N';
            -- dbms_output.put_line('====='||sqlerrm);
        end;
      end loop;
      update cux_other_province_order_t t
         set t.import_flag = var_flag
       where t.batch_id = p_batch_id
         and t.order_sn = var_op.order_sn;
      p_result := var_flag;
    end loop;
  end;

  --获取订单编码 尾数无随机数
  function get_auto_order_sn(p_header varchar2) return varchar2 is
    var_order_sn varchar2(120);
    var_radom    number;
  begin
    var_radom := DBMS_RANDOM.VALUE(1,99);
    SELECT p_header || to_char(systimestamp, 'yyyymmddHHmissff')||trunc(var_radom)
      into var_order_sn
      FROM dual;
    return var_order_sn;
  end;

end crm_order_import_wdt;
/

