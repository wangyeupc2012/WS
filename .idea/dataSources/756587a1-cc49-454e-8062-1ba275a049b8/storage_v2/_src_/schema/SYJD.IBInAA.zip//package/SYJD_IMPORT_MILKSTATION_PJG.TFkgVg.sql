create PACKAGE syjd_import_milkstation_pjg IS

  --导入奶站
  PROCEDURE syjd_import_milkstation;
  --插入用户 分配权限
  procedure insert_fnd_users(p_mobilephone in varchar2, p_name in varchar2);

END syjd_import_milkstation_pjg;
/

