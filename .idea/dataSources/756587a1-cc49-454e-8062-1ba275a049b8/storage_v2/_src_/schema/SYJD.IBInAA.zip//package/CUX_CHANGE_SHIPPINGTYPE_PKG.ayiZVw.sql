create package CUX_CHANGE_SHIPPINGTYPE_PKG is

  -- Author  : WANGYE
  -- Created : 2018/4/11 15:34:36
  -- Purpose : CUX_SYJD_CHANGE_SHIPPINGTYPE_PKG
  --更换配送类型
  PROCEDURE CHANGE_SHIPPING_TYPE(P_ORDERITEM_ID  IN VARCHAR2,
                                 P_CHANGE_DATE   IN VARCHAR2,
                                 P_SHIPPING_TYPE IN NUMBER,
                                 P_ORI_SHIP_TYPE IN NUMBER,
                                 P_CREATED_BY    IN NUMBER,
                                 P_FLAG          OUT VARCHAR2,
                                 P_MSG           OUT VARCHAR2);
  PROCEDURE GET_REFUND_INFO(P_ORDER_ID      IN VARCHAR2,
                            P_ORDERITEM_ID  IN VARCHAR2,
                            P_REFUND_DATE   IN VARCHAR2,
                            P_REFUND_NUM    OUT NUMBER,
                            P_REFUND_AMOUNT OUT NUMBER,
														P_ACT_PRICE     OUT NUMBER,
                            P_PRICE         OUT NUMBER,
                            P_FLAG          OUT VARCHAR2,
                            P_MSG           OUT VARCHAR2);

end CUX_CHANGE_SHIPPINGTYPE_PKG;
/

