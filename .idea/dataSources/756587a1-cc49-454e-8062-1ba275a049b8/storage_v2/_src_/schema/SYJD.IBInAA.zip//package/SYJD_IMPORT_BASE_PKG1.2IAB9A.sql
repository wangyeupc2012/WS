create package syjd_import_base_pkg1 is

  -- Author  : YUCHAO
  -- Created : 2017/8/15 AM 10:38:09
  -- Purpose : 

  procedure import_base_data(p_base_type varchar2);

  procedure import_item;
  procedure import_price;

end syjd_import_base_pkg1;
/

