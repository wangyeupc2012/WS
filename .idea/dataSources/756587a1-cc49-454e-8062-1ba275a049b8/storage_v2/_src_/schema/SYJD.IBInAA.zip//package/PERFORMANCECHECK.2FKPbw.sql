create package PerformanceCheck is
  procedure load_performance(yearnum number);
  FUNCTION getperformance(var_milk_station_id number,
                          yearnum             number,
                          monthnum            number) RETURN number;
  function getdealerid(p_id number) return number;
end PerformanceCheck;
/

