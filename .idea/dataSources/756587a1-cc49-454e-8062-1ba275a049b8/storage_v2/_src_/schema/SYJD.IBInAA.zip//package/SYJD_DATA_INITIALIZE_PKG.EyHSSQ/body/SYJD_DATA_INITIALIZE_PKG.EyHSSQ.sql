create package body syjd_data_initialize_pkg is

  PROCEDURE crm_data_initialize is
    v_errormessage varchar2(200);
  begin
    begin
      --删除订单，配送单
      DELETE FROM ORDERITEM;
      DELETE FROM ORDERSHIPPING;
      DELETE FROM ORDERSHIPPINGITEM;
      DELETE FROM ORDER_PAUSE_INTERVAL;
      DELETE FROM ORDER_PROMOTION;
      DELETE FROM API_RECORD;
      DELETE FROM ORDERLOG;
      DELETE FROM ORDERREFUNDS;
      DELETE FROM ORDERS;
    
    exception
      when others then
        v_errormessage := '错误信息:' || sqlerrm;
        saveErrorMessage('orders', v_errormessage);
    end;
    begin
      --删除物料中间表
      delete from mtl_system_items_temp;
    exception
      when others then
        v_errormessage := '错误信息:' || sqlerrm;
        saveErrorMessage('mtl_system_items_temp', v_errormessage);
    end;
    begin
      --删除物料表 
      delete from PROMOTION_SKU;
      delete from PRODUCT_STOREPRODUCTTAG;
      delete from PRODUCT_PROMOTION;
      delete from PRODUCT_PRODUCTTAG;
      delete from CONSULTATION;
      delete from review;
      delete from PRODUCTFAVORITE;
      DELETE FROM STOCKLOG;
      delete from sku;
      delete from product;
    exception
      when others then
        v_errormessage := '错误信息:' || sqlerrm;
        saveErrorMessage('product', v_errormessage);
    end;
  
    begin
      --删除价目行表中间表
      delete from qp_list_lines_temp;
    exception
      when others then
        v_errormessage := '错误信息:' || sqlerrm;
        saveErrorMessage('qp_list_lines_temp', v_errormessage);
    end;
  
    begin
      --删除价目头表中间表
      delete from p_secu_list_headers_temp;
    exception
      when others then
        v_errormessage := '错误信息:' || sqlerrm;
        saveErrorMessage('p_secu_list_headers_temp', v_errormessage);
    end;
  
    begin
      --删除价目头表
      delete from price_list_headers;
    exception
      when others then
        v_errormessage := '错误信息:' || sqlerrm;
        saveErrorMessage('price_list_headers', v_errormessage);
    end;
  
    begin
      --删除价目行表
      delete from price_list_lines;
    exception
      when others then
        v_errormessage := '错误信息:' || sqlerrm;
        saveErrorMessage('price_list_lines', v_errormessage);
    end;
  
    begin
      --删除经销商
      delete from dealers;
    exception
      when others then
        v_errormessage := '错误信息:' || sqlerrm;
        saveErrorMessage('price_list_lines', v_errormessage);
    end;
  
    begin
      --删除奶站
      delete from milk_station;
    exception
      when others then
        v_errormessage := '错误信息:' || sqlerrm;
        saveErrorMessage('milk_station', v_errormessage);
    end;
  
    begin
      --删除配送员
      delete from ms_courier;
    exception
      when others then
        v_errormessage := '错误信息:' || sqlerrm;
        saveErrorMessage('ms_courier', v_errormessage);
    end;
  
    begin
      --删除会员
      delete from receiver;
      delete from CARTITEM;
      delete from CART;
      DELETE from POINTLOG;
      delete from message;
      delete from COUPONCODE;
      delete from member;
    exception
      when others then
        v_errormessage := '错误信息:' || sqlerrm;
        saveErrorMessage('member', v_errormessage);
    end;
  
    begin
      --删除会员等级
      delete from PROMOTION_MEMBERRANK;
      delete from appmember;
      delete from memberrank;
    exception
      when others then
        v_errormessage := '错误信息:' || sqlerrm;
        saveErrorMessage('memberrank', v_errormessage);
    end;
  
    begin
      --删除POI地址库
      delete from poi_address_base;
    exception
      when others then
        v_errormessage := '错误信息:' || sqlerrm;
        saveErrorMessage('poi_address_base', v_errormessage);
    end;
  
    begin
      --删除销售员
      delete from salesman;
    exception
      when others then
        v_errormessage := '错误信息:' || sqlerrm;
        saveErrorMessage('poi_address_base', v_errormessage);
    end;
  
    begin
      --删除用户
      delete from fnd_users WHERE USER_ID <> '1';
      DELETE FROM FND_USER_ASSESS_AUTH;
    exception
      when others then
        v_errormessage := '错误信息:' || sqlerrm;
        saveErrorMessage('fnd_users', v_errormessage);
    end;
    commit;
  end;

  PROCEDURE saveErrorMessage(tablename    in varchar2,
                             errormessage in varchar2) is
  begin
    insert into initialize_data_message
      (tablename, created_by, createddate, lastupdated_by, lastupdatedate)
    values
      (tablename, '-1', sysdate, '-1', sysdate);
    commit;
  end;
  PROCEDURE syjd_import_milkstation is
    cursor c_temp_milk_station is
      select * from temp_milk_station;
  
    cursor cur_jz_station is
      select ms.id milk_station_id, ms1.id jz_milk_station_id
        from temp_milk_station tms, milk_station ms, milk_station ms1
       where tms.milk_station_name = ms.milk_station_name
         and tms.jz_belong_to_name = ms1.milk_station_name;
    cursor cur_receiver_jz_station is
      select ms.id milk_station_id, ms1.id jz_milk_station_id
        from temp_milk_station tms, milk_station ms, milk_station ms1
       where tms.milk_station_name = ms.milk_station_name
         and tms.receive_jz_name = ms1.milk_station_name;
    var_jz_station   cur_jz_station%rowtype;
    v_milkstation_id number;
  begin
    --先删除原奶站的数据
    delete from milk_station;
    COMMIT;
    FOR v_temp_milk_station in c_temp_milk_station loop
      begin
        select get_primary_id('MILK_STATION')
          into v_milkstation_id
          from dual;
        insert into milk_station
          (ID,
           DEALERS_ID,
           MILK_STATION_CODE,
           MILK_STATION_NAME,
           MANAGER,
           TEL_NUMBER,
           AREA_ID,
           DETAILED_ADDRESS,
           LONGITUDE,
           LATITUDE,
           STATUS,
           JZ_FLAG,
           CREDIT_SCORE,
           LAST_UPDATE_DATE,
           LAST_UPDATED_BY,
           CREATION_DATE,
           CREATED_BY,
           PROVINCE_ID,
           CITY_ID,
           JZ_BELONG_TO,
           PRICE_ID,
           PRINT_ZONE,
           DELIVERY_LINE,
           POI_UID,
           POI_TITLE,
           SALESMAN_ID,
           ONE_OFF_DISTRIBUTION,
           SALESMAN_NAME,
           QR_MILKSTATION_CODE,
           NAME_FOR_SHORT,
           LOGISTICS,
           DRIVEWAY,
           DRIVE_TIMES,
           BILL,
           LogisticFeePayer,
           old_dealers_name,
           Permissions_on_the_tree)
        values
          (v_milkstation_id,
           v_temp_milk_station.DEALERS_ID,
           'NZ' || MILK_STATION_S.NEXTVAL,
           v_temp_milk_station.MILK_STATION_NAME,
           v_temp_milk_station.MANAGER,
           v_temp_milk_station.TEL_NUMBER,
           v_temp_milk_station.AREA_ID,
           v_temp_milk_station.DETAILED_ADDRESS,
           v_temp_milk_station.LONGITUDE,
           v_temp_milk_station.LATITUDE,
           'NEW',
           v_temp_milk_station.JZ_FLAG,
           '100',
           SYSDATE,
           -1,
           SYSDATE,
           -1,
           v_temp_milk_station.PROVINCE_ID,
           v_temp_milk_station.CITY_ID,
           v_temp_milk_station.JZ_BELONG_TO,
           v_temp_milk_station.PRICE_ID,
           v_temp_milk_station.PRINT_ZONE,
           v_temp_milk_station.DELIVERY_LINE,
           v_temp_milk_station.POI_UID,
           v_temp_milk_station.POI_TITLE,
           (select id
              from salesman
             where name = v_temp_milk_station.SALESMAN_NAME),
           '',
           v_temp_milk_station.SALESMAN_NAME,
           v_temp_milk_station.QR_MILKSTATION_CODE,
           v_temp_milk_station.NAME_FOR_SHORT,
           v_temp_milk_station.LOGISTICS,
           v_temp_milk_station.DRIVEWAY,
           v_temp_milk_station.DRIVE_TIMES,
           v_temp_milk_station.BILL,
           v_temp_milk_station.LogisticFeePayer,
           v_temp_milk_station.old_dealers_name,
           v_temp_milk_station.Permissions_on_the_tree);
        update temp_milk_station tms
           set tms.flag = 'Y'
         where tms.milk_station_name = tms.milk_station_name;
        --插入用户 分配权限
        /* if v_temp_milk_station.tel_number is not null then
          insert_fnd_users(v_temp_milk_station.tel_number,
                           v_temp_milk_station.manager,
                           v_milkstation_id);
        end if;*/
        /*exception
        when others then
          update temp_milk_station tms
             set tms.flag = 'E'
           where tms.milk_station_name = tms.milk_station_name;*/
      end;
      commit;
    end loop;
    --将基站信息更新
    for var_jz_station in cur_jz_station loop
      update milk_station ms
         set ms.jz_belong_to = var_jz_station.jz_milk_station_id,
             jz_flag         = 'Y'
       where ms.id = var_jz_station.milk_station_id;
      commit;
    end loop;
    update milk_station ms set jz_flag = 'N' where jz_belong_to is null;
    commit;
    for var_receiver_jz_station in cur_receiver_jz_station loop
      update milk_station ms
         set ms.receive_jz_id = var_receiver_jz_station.jz_milk_station_id
       where ms.id = var_receiver_jz_station.milk_station_id;
      commit;
    end loop;
  end;

  --插入用户 分配权限
  procedure insert_fnd_users(p_mobilephone    in varchar2,
                             p_name           in varchar2,
                             p_milkstation_id in number) is
    v_user_id   number;
    v_error_msg varchar2(120);
  begin
    select fnd_user_s.nextval into v_user_id from dual;
    --新增用户
    insert into fnd_users
      (user_id,
       user_code,
       user_type,
       login_username,
       login_password,
       start_date,
       mobilephone,
       last_update_date,
       last_updated_by,
       created_by,
       CREATION_DATE,
       status,
       name)
    values
      (v_user_id,
       LPAD(v_user_id, 7, 0),
       'MILK_STATION',
       p_mobilephone,
       '25F9E794323B453885F5181F1B624D0B', --默认密码为采用MD5加密后的 1-9数字
       sysdate,
       p_mobilephone,
       sysdate,
       -1,
       -1,
       sysdate,
       'VALID',
       p_name);
    --新增用户权限
    insert into fnd_user_assess_auth
      (id,
       version,
       user_id,
       milk_station_id,
       ms_courier_id,
       created_by,
       last_updated_by,
       auth_type,
       createddate,
       lastmodifieddate,
       VALID_FLAG)
    values
      (get_primary_id('fnd_user_assess_auth'),
       0,
       v_user_id,
       p_milkstation_id,
       -1,
       -1,
       -1,
       'INCLUDE',
       sysdate,
       sysdate,
       'Y');
    commit;
  exception
    when others then
      v_error_msg := '错误信息：' || sqlerrm;
      --dbms_output.put_line(v_error_msg);
  end;

  /*PROCEDURE syjd_import_DEALER IS
    cursor c_temp_DEALERS is
      select * from temp_DEALERS;
    v_errormessage varchar2(200);
  begin
    --先删除数据
    delete from DEALERS;
    COMMIT;
    FOR v_temp_DEALERS in c_temp_DEALERS loop
      BEGIN
        INSERT INTO DEALERS
          (ID,
           DEALERS_CODE,
           DEALERS_NAME,
           CHANNEL,
           SOURCE,
           STATUS,
           ABBREVIATION,
           attribute2,
           attribute1)
        VALUES
          (GET_PRIMARY_ID('DEALERS'),
           v_temp_DEALERS.Dealers_Code,
           v_temp_DEALERS.DEALERS_NAME,
           (SELECT LOOKUP_CODE
              FROM FND_LOOKUP_VALUES
             WHERE LOOKUP_TYPE = 'DEALERS_CHANNEL'
               AND MEANING = v_temp_DEALERS.ATTRIBUTE2),
           (CASE
             WHEN v_temp_DEALERS.DEALERS_NAME like '%线下%' THEN
              'OFFLINE'
             ELSE
              'ONLINE'
           END),
           'NEW',
           v_temp_DEALERS.ABERVIATION,
           v_temp_DEALERS.attribute2,
           v_temp_DEALERS.Contactor);
        UPDATE temp_DEALERS
           SET ATTRIBUTE1 = 'Y', ATTRIBUTE3 = ''
         WHERE Dealers_Code = v_temp_DEALERS.Dealers_Code;
      exception
        when others then
          v_errormessage := '错误信息:' || sqlerrm;
          UPDATE temp_DEALERS
             SET ATTRIBUTE1 = 'N', ATTRIBUTE3 = v_errormessage
           WHERE Dealers_Code = v_temp_DEALERS.Dealers_Code;
      end;
      commit;
    end loop;
  end;*/

  --将奶站关联上线上经销商
  PROCEDURE dealers_for_milkstation IS
    cursor t_milkstation is
      select * from milk_station;
    error_message varchar2(255);
  begin
    for v_milkstation in t_milkstation loop
      begin
        --线上
        insert into milk_station_line
          (id,
           header_id,
           dealers_id,
           price_list_id,
           status,
           createddate,
           lastmodifieddate,
           created_by,
           last_updated_by,
           milk_station_line_code,
           erp_error_message)
        values
          (GET_PRIMARY_ID('MILK_STATION_LINE'),
           v_milkstation.ID,
           (SELECT ID
              FROM DEALERS
             WHERE dealers_code =
                   (SELECT online_dealer_name
                      FROM TEMP_MILK_STATION t
                     WHERE t.MILK_STATION_NAME =
                           v_milkstation.milk_station_name)
               and source = 'ONLINE'),
           (SELECT ID
              FROM PRICE_LIST_HEADERS
             WHERE PRICE_NAME =
                   (SELECT ONLINE_PRICE
                      FROM TEMP_MILK_STATION
                     WHERE MILK_STATION_NAME =
                           v_milkstation.milk_station_name)),
           'NEW',
           SYSDATE,
           SYSDATE,
           '-1',
           '-1',
           'NZ' || substr(v_milkstation.milk_station_code, 3) || '001',
           null);
        insert into milk_station_line
          (id,
           header_id,
           dealers_id,
           price_list_id,
           status,
           createddate,
           lastmodifieddate,
           created_by,
           last_updated_by,
           milk_station_line_code,
           erp_error_message)
        values
          (GET_PRIMARY_ID('MILK_STATION_LINE'),
           v_milkstation.ID,
           (SELECT ID
              FROM DEALERS
             WHERE dealers_code =
                   (SELECT dealer_name
                      FROM TEMP_MILK_STATION t
                     WHERE t.MILK_STATION_NAME =
                           v_milkstation.milk_station_name)
               and source = 'OFFLINE'),
           (SELECT ID
              FROM PRICE_LIST_HEADERS
             WHERE PRICE_NAME =
                   (SELECT PRICE_ID
                      FROM TEMP_MILK_STATION
                     WHERE MILK_STATION_NAME =
                           v_milkstation.milk_station_name)),
           'NEW',
           SYSDATE,
           SYSDATE,
           '-1',
           '-1',
           'NZ' || substr(v_milkstation.milk_station_code, 3) || '002',
           null);
        UPDATE temp_milk_station
           SET error_message = 'Y'
         WHERE milk_station_name = v_milkstation.milk_station_name;
      exception
        when others then
          error_message := '错误信息:' || sqlerrm;
          UPDATE temp_milk_station
             SET error_message = error_message
           WHERE milk_station_name = v_milkstation.milk_station_name;
      end;
    end loop;
  end;

  --从中间表导入POI
  procedure import_poi is
    cursor v_temp is
      select * from temp_poi;
    error_message varchar2(1000);
    v_count       number;
  begin
    for t_temp in v_temp loop
      begin
        select count(1)
          into v_count
          from milk_station
         where milk_station_code = t_temp.milkstationcode;
        if v_count = 0 then
          insert into errmessage
            (err_message)
          values
            ('奶站编码无对应奶站' || t_temp.milkstationcode);
        else
          insert into poi_address_base
            (id,
             poi_uid,
             poi_title,
             poi_address,
             poi_lat,
             poi_lng,
             province_name,
             city_name,
             district_name,
             milkstation_id,
             creation_date,
             created_by,
             last_update_date,
             last_updated_by,
             province_id,
             city_id,
             area_id)
          values
            (GET_PRIMARY_ID('poi_address_base'),
             t_temp.poiuid,
             t_temp.poititle,
             t_temp.poiaddress,
             t_temp.poilat,
             t_temp.poilng,
             '北京市',
             '市辖区',
             t_temp.area,
             (select id
                from milk_station
               where milk_station_code = t_temp.milkstationcode),
             sysdate,
             '-1',
             sysdate,
             '-1',
             '1',
             '2',
             '');
        end if;
      exception
        when others then
          error_message := '错误信息:' || sqlerrm;
          insert into errmessage (err_message) values (error_message);
        
      end;
      commit;
    end loop;
  end;

  --CUX_ORDER_EXCEL_XX_T CUX_ORDER_EXCEL_T两张表
  PROCEDURE ORDER_UPLOAD_FROM_EXCEL(P_BATCH_ID IN VARCHAR2,
                                    P_CODE     OUT VARCHAR2) IS
    CURSOR CUR_ORDER IS
      /*SELECT *
        FROM CUX_ORDER_EXCEL_T
       WHERE FLAG is null
         AND BATCH_ID = P_BATCH_ID;
         */
         SELECT *
        FROM CUX_ORDER_EXCEL_T t
       WHERE T.FLAG is null
         AND BATCH_ID = P_BATCH_ID;
         
    VAR_ORDER                CUR_ORDER%ROWTYPE;
    VAR_ORDER_ID             NUMBER;
    VAR_FLAG                 VARCHAR2(10);
    VAR_MSG                  VARCHAR2(255);
    VAR_MODE_OF_DIS          VARCHAR2(20);
    VAR_SEPARATE_BASIS       VARCHAR2(20);
    VAR_MILKSTATION_ID       NUMBER;
    VAR_SHIPPING_METHOD_TYPE VARCHAR2(20);
    VAR_ORDER_TYPE           VARCHAR2(20);
    VAR_ORDER_FROM           VARCHAR2(20);
    v_count                  NUMBER;
    VAR_SHIPPING_TIME        VARCHAR2(20);
    VAR_SHIPPING_TYPE        VARCHAR2(20);
    VAR_ORDER_STATUS         VARCHAR2(20);
    VAR_REFUND_STATUS        VARCHAR2(20);
    VAR_AREA_ID              NUMBER;
    V_RES                    NUMBER;
    VAR_ERROR_CNT            NUMBER;
    V_SAMEBATCH_CNT          NUMBER;
    v_receiver_id            NUMBER;
    v_order_count            NUMBER;
  BEGIN
    FOR VAR_ORDER IN CUR_ORDER LOOP
 /*    --判断该订单号在系统中是否已存在@added by longwy start
    SELECT COUNT(1)
      INTO V_ORDER_COUNT
      FROM ORDERS OS
     WHERE OS.SN = VAR_ORDER.ORDER_SN;
    IF V_ORDER_COUNT > 0 THEN
      VAR_FLAG := 'N';
      VAR_MSG  := '错误信息：' || '该订单号在系统中已存在！';
      RETURN;
    END IF;
    
     BEGIN
        SELECT OS.ID
          INTO VAR_ORDER_ID
          FROM ORDERS OS
         WHERE OS.SN = VAR_ORDER.ORDER_SN;
      EXCEPTION
        WHEN OTHERS THEN
          VAR_FLAG := 'N';
          VAR_MSG  := '错误信息：' || SQLERRM;
      END;
    
     ---判断该订单号在系统中是否已存在@added by longwy end*/
      --判断订单编码是否已存在于orders表中
      BEGIN
        SELECT OS.ID
          INTO VAR_ORDER_ID
          FROM ORDERS OS
         WHERE OS.SN = VAR_ORDER.ORDER_SN
         and os.status <> 9;
      EXCEPTION
        WHEN OTHERS THEN
          VAR_FLAG := 'N';
          VAR_MSG  := '错误信息：' || SQLERRM;
      END;
      IF VAR_FLAG = 'N' AND VAR_ORDER.MODE_OF_DISTRIBUTION IS NOT NULL THEN
        --执行插入头、行操作
        --VAR_ORDER_ID :=get_primary_id('ORDERS');
      
        --校验配送模式是否规范
        begin
          select FLV.LOOKUP_CODE
            into VAR_MODE_OF_DIS
            from fnd_lookup_values flv
           where flv.lookup_type = 'MODE_OF_DISTRIBUTION'
             and flv.meaning = VAR_ORDER.MODE_OF_DISTRIBUTION;
          VAR_FLAG := 'Y';
        exception
          when others then
            VAR_FLAG := 'N';
            VAR_MSG  := '错误信息：序号' || VAR_ORDER.Id || '配送模式有误' || SQLERRM;
        end;
      
        IF VAR_FLAG = 'Y' AND VAR_ORDER.SEPARATE_BASIS IS NOT NULL THEN
          --校验分单依据是否规范
          begin
            select FLV.LOOKUP_CODE
              into VAR_SEPARATE_BASIS
              from fnd_lookup_values flv
             where flv.lookup_type = 'DISTRIBUTED_ORDER_ACCORDING_TO'
               and flv.meaning = VAR_ORDER.SEPARATE_BASIS;
            -- VAR_FLAG := 'Y';
          exception
            when others then
              VAR_FLAG := 'N';
              VAR_MSG  := '错误信息：序号' || VAR_ORDER.Id || '分单依据有误' || SQLERRM;
          end;
        END IF;
      
        IF VAR_FLAG = 'Y' AND VAR_ORDER.MILK_STATION IS NOT NULL THEN
          BEGIN
            select ID
              into VAR_MILKSTATION_ID
              from milk_station
             where milk_station_name = VAR_ORDER.MILK_STATION;
          exception
            when others then
              VAR_FLAG := 'N';
              VAR_MSG  := '错误信息：序号' || VAR_ORDER.Id || '奶站名有误' || SQLERRM;
          END;
        END IF;
      
        --判断配送方式是否规范
        IF VAR_FLAG = 'Y' AND VAR_ORDER.SHIPPING_METHOD_TYPE IS NOT NULL THEN
          BEGIN
            select LOOKUP_CODE
              into VAR_SHIPPING_METHOD_TYPE
              from fnd_lookup_values
             where lookup_type = 'SHIPPING_METHOD'
               and meaning = VAR_ORDER.SHIPPING_METHOD_TYPE;
          EXCEPTION
            WHEN OTHERS THEN
              VAR_FLAG := 'N';
              VAR_MSG  := '错误信息：序号' || VAR_ORDER.Id || '配送方式有误' || SQLERRM;
          END;
        END IF;
      
        --判断订单类型是否规范
        IF VAR_FLAG = 'Y' AND VAR_ORDER.ORDER_TYPE IS NOT NULL THEN
          BEGIN
            select LOOKUP_CODE
              into VAR_ORDER_TYPE
              from fnd_lookup_values
             where lookup_type = 'ORDER_TYPE'
               and meaning = VAR_ORDER.ORDER_TYPE;
          EXCEPTION
            WHEN OTHERS THEN
              VAR_FLAG := 'N';
              VAR_MSG  := '错误信息：序号' || VAR_ORDER.Id || '订单类型有误' || SQLERRM;
          END;
        END IF;
      
        --判断订单来源是否规范
        IF VAR_FLAG = 'Y' AND VAR_ORDER.ORDER_FROM IS NOT NULL THEN
          BEGIN
            select LOOKUP_CODE
              into VAR_ORDER_FROM
              from fnd_lookup_values
             where lookup_type = 'ORDER_FROM'
               and meaning = VAR_ORDER.ORDER_FROM;
          EXCEPTION
            WHEN OTHERS THEN
              VAR_FLAG := 'N';
              VAR_MSG  := '错误信息：序号' || VAR_ORDER.Id || '订单来源有误' || SQLERRM;
          END;
        END IF;
      
        --判断订单状态是否规范
        IF VAR_FLAG = 'Y' AND VAR_ORDER.Order_Status IS NOT NULL THEN
          BEGIN
            select flv.lookup_code
              into VAR_ORDER_STATUS
              from fnd_lookup_values flv
             where flv.lookup_type = 'ORDER_STATUS'
               and flv.meaning = VAR_ORDER.Order_Status
               and flv.enabled_flag = 'Y';
          EXCEPTION
            WHEN OTHERS THEN
              VAR_FLAG := 'N';
              VAR_MSG  := '错误信息：序号' || VAR_ORDER.Id || '订单状态有误' || SQLERRM;
          END;
        END IF;
      
        --判断产品编码是否规范
        IF VAR_FLAG = 'Y' AND VAR_ORDER.ITEM_SN IS NOT NULL AND
           VAR_ORDER.ITEM_NAME IS NOT NULL THEN
          BEGIN
            select count(*)
              into v_count
              from product
             where sn = replace(VAR_ORDER.ITEM_SN, '-', '.');
            --  and name = VAR_ORDER.ITEM_NAME;
            IF v_count = 0 THEN
              VAR_FLAG := 'N';
              VAR_MSG  := '错误信息：序号' || VAR_ORDER.Id || '产品编码和产品说明没有对应';
            END IF;
          EXCEPTION
            WHEN OTHERS THEN
              VAR_FLAG := 'N';
              VAR_MSG  := '错误信息：序号' || VAR_ORDER.Id || '产品编码和产品说明没有对应' ||
                          SQLERRM;
          END;
          INSERT INTO EXCEL_TEST
          VALUES
            (get_primary_id('EXCEL_TEST'),
             VAR_ORDER.ITEM_SN,
             VAR_MSG,
             '',
             '',
             '',
             '');
        END IF;
      
        --校验订单行每日配送时间是否符合规范
        IF VAR_FLAG = 'Y' AND VAR_ORDER.SHIPPING_TIME IS NOT NULL THEN
          BEGIN
            select LOOKUP_CODE
              into VAR_SHIPPING_TIME
              from fnd_lookup_values
             where lookup_type = 'ORDERITEM_DAY_SHIPPING_TIME'
               and meaning = VAR_ORDER.SHIPPING_TIME;
          EXCEPTION
            WHEN OTHERS THEN
              VAR_FLAG := 'N';
              VAR_MSG  := '错误信息：序号' || VAR_ORDER.Id || '每日配送时间有误' ||
                          SQLERRM;
          END;
        END IF;
      
        --判断订单行配送类型是否符合规范
        IF VAR_FLAG = 'Y' AND VAR_ORDER.SHIPPING_TYPE IS NOT NULL THEN
          BEGIN
            select LOOKUP_CODE
              into VAR_SHIPPING_TYPE
              from fnd_lookup_values
             where lookup_type = 'ORDER_SHIPPING_TYPE'
               and meaning = VAR_ORDER.SHIPPING_TYPE;
          EXCEPTION
            WHEN OTHERS THEN
              VAR_FLAG := 'N';
              VAR_MSG  := '错误信息：序号' || VAR_ORDER.Id || '配送类型有误' || SQLERRM;
          END;
        END IF;
      
        --判断收获区域
        IF VAR_FLAG = 'Y' AND VAR_ORDER.AREA_NAME IS NOT NULL THEN
          BEGIN
            select A.ID
              into VAR_AREA_ID
              from AREA A
             where A.FULLNAME_VAR = VAR_ORDER.AREA_NAME;
          EXCEPTION
            WHEN OTHERS THEN
              VAR_FLAG := 'N';
              VAR_MSG  := '错误信息：序号' || VAR_ORDER.Id || '收货区域有误' || SQLERRM;
          END;
        END IF;
      
        --判断订单行状态是否符合规范
        IF VAR_FLAG = 'Y' AND VAR_ORDER.REFUND_STATUS IS NOT NULL THEN
          BEGIN
            select LOOKUP_CODE
              into VAR_REFUND_STATUS
              from fnd_lookup_values
             where lookup_type = 'ORDERITEM_RETURN_STATUS'
               and meaning = VAR_ORDER.REFUND_STATUS;
          EXCEPTION
            WHEN OTHERS THEN
              VAR_FLAG := 'N';
              VAR_MSG  := '错误信息：序号' || VAR_ORDER.Id || '退款状态有误' || SQLERRM;
          END;
        END IF;
      
        IF VAR_FLAG = 'Y' AND VAR_ORDER.AREA_NAME IS NOT NULL AND
           VAR_ORDER.DETAIL_ADDRESS IS NOT NULL AND
           VAR_ORDER.TEL_NUMER IS NOT NULL AND
          --VAR_ORDER.POI_ADDRESS IS NOT NULL AND
           VAR_ORDER.CONSIGNEE IS NOT NULL THEN
          BEGIN
            select r.id
              into v_receiver_id
              from receiver r
             where r.areaname = VAR_ORDER.AREA_NAME
               and r.address = VAR_ORDER.DETAIL_ADDRESS
               and r.phone = VAR_ORDER.TEL_NUMER
               and r.poititle = VAR_ORDER.POI_ADDRESS
               and r.consignee = VAR_ORDER.CONSIGNEE
               AND ROWNUM = 1;
          EXCEPTION
            WHEN OTHERS THEN
              NULL;
          END;
        END IF;
      
        --最后判断本批次相同订单是否已经校验通过
        IF VAR_FLAG = 'Y' AND VAR_ORDER.REFUND_STATUS IS NOT NULL THEN
          BEGIN
            SELECT COUNT(1)
              INTO VAR_ERROR_CNT
              FROM CUX_ORDER_EXCEL_T T
             WHERE T.ORDER_SN = VAR_ORDER.ORDER_SN
               AND T.FLAG = 'N'
               AND T.BATCH_ID = P_BATCH_ID;
          
            IF VAR_ERROR_CNT > 0 THEN
              UPDATE CUX_ORDER_EXCEL_T T
                 SET T.FLAG = 'N', T.MSG = '该订单其他行信息有误！'
               WHERE T.ID = VAR_ORDER.ID;
              COMMIT;
              CONTINUE;
            END IF;
          EXCEPTION
            WHEN OTHERS THEN
              NULL;
          END;
        END IF;
      
        IF VAR_FLAG = 'Y' THEN
          --做插入操作
          VAR_ORDER_ID := get_primary_id('ORDERS');
          --CUX_ORDER_TEST_T
          insert into ORDERS
            (id,
             CREATEDDATE,
             LASTMODIFIEDDATE,
             VERSION,
             ADDRESS,
             AMOUNT,
             AMOUNTPAID,
             AREANAME,
             --COMPLETEDATE,
             CONSIGNEE,
             COUPONDISCOUNT,
             EXCHANGEPOINT,
             EXPIRE,
             FEE,
             FREIGHT,
             --INVOICECONTENT,
             INVOICETITLE,
             ISALLOCATEDSTOCK,
             ISEXCHANGEPOINT,
             ISUSECOUPONCODE,
             MEMO,
             OFFSETAMOUNT,
             PAYMENTMETHODNAME,
             PAYMENTMETHODTYPE,
             PHONE,
             PRICE, --全部写为0
             PROMOTIONDISCOUNT,
             PROMOTIONNAMES,
             QUANTITY, --0
             REFUNDAMOUNT, --0
             RETURNEDQUANTITY, --0
             REWARDPOINT,
             SHIPPEDQUANTITY, --0
             SHIPPINGMETHODNAME,
             SN,
             STATUS,
             TAX,
             TYPE,
             WEIGHT,
             ZIPCODE,
             AREA_ID,
             COUPONCODE_ID,
             --   MEMBER_ID,
             PAYMENTMETHOD_ID,
             SHIPPINGMETHOD_ID, --配送到户 51
             STORE_ID,
             CREATED_BY, -- 默认为-1
             LAST_UPDATED_BY, --默认为-1
             ORDER_FROM,
             MILK_STATION_ID,
             MS_COURIER_ID,
             DEALER_ID,
             POI_UID,
             POI_TITLE,
             RECEIVER_ID,
             valid_milkstation_flag,
             OLDCUSTOMER_FLAG,
             MODE_OF_DISTRIBUTION,
             COUPONAMOUNT,
             REDPACKETAMOUNT,
             ACTUALAMOUNT,
             ACTIVITYAMOUNT,
             BUYER_REMARK,
             OLD_FLAG,
             DEL_FLAG,
             ORDERREFUNDS_STATUS
             --CONFIRM_AMOUNT,
             )
          values
            (VAR_ORDER_ID,
             sysdate,
             sysdate,
             1,
             VAR_ORDER.Detail_Address,
             nvl(VAR_ORDER.Order_Amount, 0),
             nvl(VAR_ORDER.Act_Amount, VAR_ORDER.Order_Amount),
             var_order.area_name,
             var_order.consignee,
             var_order.discount_amount,
             0,
             '',
             0,
             0,
             '',
             1,
             0,
             0,
             var_order.seller_remark,
             0,
             --var_ord_header.offsetamount,
             '',
             0,
             var_order.tel_numer,
             0,
             var_order.promotion_amount,
             '',
             0,
             0,
             0,
             --下面是积分 没找到
             0,
             0,
             var_order.shipping_method_type,
             var_order.order_sn,
             VAR_ORDER_STATUS,
             0,
             --var_ord_header.tax,
             VAR_ORDER_TYPE,
             0,
             '',
             VAR_AREA_ID,
             '',
             11,
             /* (select id
              from member
             where member_code = var_ord_header.member_code),*/
             -- '',
             51,
             51,
             -1,
             -1,
             VAR_ORDER_FROM,
             VAR_MILKSTATION_ID,
             '',
             '',
             '',
             var_order.poi_address,
             v_receiver_id,
             decode(var_order.is_distribution, '是', 'Y', 'N'),
             VAR_SEPARATE_BASIS,
             VAR_MODE_OF_DIS,
             var_order.discount_amount,
             var_order.redpacket_amount,
             var_order.act_amount,
             var_order.Activity_Amount,
             var_order.buyer_remark,
             1,
             0,
             2);
        
          --写入订单行表CUX_ORDERITEM_TEST_T
          insert into ORDERITEM
            (id,
             createddate,
             lastmodifieddate,
             version,
             commissiontotals,
             isdelivery,
             name,
             price,
             quantity,
             returnedquantity,
             shippedquantity,
             sn,
             specifications,
             thumbnail,
             type,
             weight,
             orders,
             sku_id,
             created_by,
             last_updated_by,
             order_date_from,
             order_date_to,
             order_days,
             daily_delivery_quantity,
             delivery_days,
             remain_days,
             REFUND_STATUS,
             day_shipping_time,
             shipping_type,
             original_order_date_to,
             product_sn,
             PAY_PRICE,
             present_flag,
             TOTALPRICE,
             LINE_COUNT)
          values
            (get_primary_id('ORDERITEM'),
             sysdate,
             sysdate,
             1,
             0,
             1,
             var_order.Item_Name,
             var_order.price,
             var_order.day_diliver_quantity * var_order.order_days, --每日配送数量* 订购天数
             0,
             0,
             var_order.item_sn,
             '',
             '',
             0,
             --var_ord_line.type,
             '',
             VAR_ORDER_ID,
             '',
             -1,
             -1,
             to_date(var_order.order_date_from, 'yyyy-MM-dd'),
             to_date(var_order.order_date_to, 'yyyy-MM-dd'),
             var_order.order_days,
             var_order.day_diliver_quantity,
             '',
             '',
             VAR_REFUND_STATUS,
             VAR_SHIPPING_TIME,
             VAR_SHIPPING_TYPE,
             to_date(var_order.order_date_to, 'yyyy-MM-dd'),
             var_order.item_sn,
             var_order.act_price,
             decode(var_order.is_gift, '是', '1', '0'),
             var_order.sale_amount,
             var_order.line_count);
        
          UPDATE CUX_ORDER_EXCEL_T T
             SET T.FLAG = 'Y'
           WHERE T.ID = var_order.Id
             AND T.BATCH_ID = P_BATCH_ID;
          COMMIT;
        ELSE
          --更新临时表状态 msg
          UPDATE CUX_ORDER_EXCEL_T C
             SET C.FLAG = VAR_FLAG, C.MSG = VAR_MSG
           WHERE C.ORDER_SN = VAR_ORDER.ORDER_SN
             AND C.BATCH_ID = P_BATCH_ID;
          COMMIT;
          CONTINUE;
        END IF;
      
      ELSE
        --执行插入行操作
        VAR_FLAG := 'Y';
        BEGIN
          SELECT OS.ID
            INTO VAR_ORDER_ID
            FROM ORDERS OS
           WHERE OS.SN = var_order.Order_Sn;
        EXCEPTION
          WHEN OTHERS THEN
            VAR_FLAG := 'N';
            VAR_MSG  := '未找到对应的订单头信息！';
        END;
      
        --判断该订单是否是本批次插入的
        IF VAR_FLAG = 'Y' THEN
          BEGIN
            SELECT COUNT(1)
              INTO V_SAMEBATCH_CNT
              FROM CUX_ORDER_EXCEL_T T
             WHERE T.ORDER_SN = VAR_ORDER.ORDER_SN
               AND T.FLAG = 'Y'
               AND T.BATCH_ID = P_BATCH_ID;
            IF V_SAMEBATCH_CNT > 0 THEN
              VAR_FLAG := 'Y';
            ELSIF V_SAMEBATCH_CNT = 0 THEN
              VAR_FLAG := 'E';
              VAR_MSG  := '订单编码和历史订单重复，请核对！';
            END IF;
          EXCEPTION
            WHEN OTHERS THEN
              VAR_FLAG := 'N';
              VAR_MSG  := '订单编码存在问题！';
          END;
        END IF;
      
        --判断产品编码是否规范
        IF VAR_FLAG = 'Y' AND VAR_ORDER.ITEM_SN IS NOT NULL AND
           VAR_ORDER.ITEM_NAME IS NOT NULL THEN
          BEGIN
            select count(*)
              into v_count
              from product
             where sn = replace(VAR_ORDER.ITEM_SN, '-', '.');
              -- and name = VAR_ORDER.ITEM_NAME;
            IF v_count = 0 THEN
              VAR_FLAG := 'N';
              VAR_MSG  := '错误信息：产品编码和产品说明没有对应';
            END IF;
          EXCEPTION
            WHEN OTHERS THEN
              VAR_FLAG := 'N';
              VAR_MSG  := '错误信息：产品编码和产品说明没有对应' || SQLERRM;
          END;
          INSERT INTO EXCEL_TEST
          VALUES
            (get_primary_id('EXCEL_TEST'),
             VAR_ORDER.ITEM_SN,
             VAR_MSG,
             '',
             '',
             '',
             '');
        END IF;
      
        --校验订单行每日配送时间是否符合规范
        IF VAR_FLAG = 'Y' AND VAR_ORDER.SHIPPING_TIME IS NOT NULL THEN
          BEGIN
            select LOOKUP_CODE
              into VAR_SHIPPING_TIME
              from fnd_lookup_values
             where lookup_type = 'ORDERITEM_DAY_SHIPPING_TIME'
               and meaning = VAR_ORDER.SHIPPING_TIME;
          EXCEPTION
            WHEN OTHERS THEN
              VAR_FLAG := 'N';
              VAR_MSG  := '错误信息：每日配送时间有误' || SQLERRM;
          END;
        END IF;
      
        --判断订单行配送类型是否符合规范
        IF VAR_FLAG = 'Y' AND VAR_ORDER.SHIPPING_TYPE IS NOT NULL THEN
          BEGIN
            select LOOKUP_CODE
              into VAR_SHIPPING_TYPE
              from fnd_lookup_values
             where lookup_type = 'ORDER_SHIPPING_TYPE'
               and meaning = VAR_ORDER.SHIPPING_TYPE;
          EXCEPTION
            WHEN OTHERS THEN
              VAR_FLAG := 'N';
              VAR_MSG  := '错误信息：配送类型有误' || SQLERRM;
          END;
        END IF;
        
      
        /*     --判断收获区域
        IF VAR_FLAG = 'Y' AND VAR_ORDER.AREA_NAME IS NOT NULL THEN
          BEGIN
            select A.ID
              into VAR_AREA_ID
              from AREA A
             where A.FULLNAME_VAR = VAR_ORDER.AREA_NAME;
          EXCEPTION
            WHEN OTHERS THEN
              VAR_FLAG := 'N';
              VAR_MSG  := '错误信息：收货区域有误' || SQLERRM;
          END;
        END IF;*/
      
        --判断订单行状态是否符合规范
        IF VAR_FLAG = 'Y' AND VAR_ORDER.REFUND_STATUS IS NOT NULL THEN
          BEGIN
            select LOOKUP_CODE
              into VAR_REFUND_STATUS
              from fnd_lookup_values
             where lookup_type = 'ORDERITEM_RETURN_STATUS'
               and meaning = VAR_ORDER.REFUND_STATUS;
          EXCEPTION
            WHEN OTHERS THEN
              VAR_FLAG := 'N';
              VAR_MSG  := '错误信息：退款状态有误' || SQLERRM;
          END;
        END IF;
        /*--判断订单行表是否已有此行
        BEGIN
          SELECT 
          FROM ORDERITEM
         EXCEPTION WHEN OTHERS THEN
           NULL;
        END;*/
        --写入订单行表
        --    dbms_output.put_line('测试====='||var_order.order_days);
        IF VAR_FLAG = 'Y' THEN
          insert into ORDERITEM
            (id,
             createddate,
             lastmodifieddate,
             version,
             commissiontotals,
             isdelivery,
             name,
             price,
             quantity,
             returnedquantity,
             shippedquantity,
             sn,
             specifications,
             thumbnail,
             type,
             weight,
             orders,
             sku_id,
             created_by,
             last_updated_by,
             order_date_from,
             order_date_to,
             order_days,
             daily_delivery_quantity,
             delivery_days,
             remain_days,
             REFUND_STATUS,
             day_shipping_time,
             shipping_type,
             original_order_date_to,
             product_sn,
             PAY_PRICE,
             present_flag,
             TOTALPRICE,
             LINE_COUNT)
          values
            (get_primary_id('ORDERITEM'),
             sysdate,
             sysdate,
             1,
             0,
             1,
             var_order.Item_Name,
             var_order.price,
             var_order.day_diliver_quantity * var_order.order_days, --每日配送数量* 订购天数
             0,
             0,
             var_order.item_sn,
             '',
             '',
             0,
             --var_ord_line.type,
             '',
             VAR_ORDER_ID,
             '',
             -1,
             -1,
             to_date(var_order.order_date_from, 'yyyy-MM-dd'),
             to_date(var_order.order_date_to, 'yyyy-MM-dd'),
             var_order.order_days,
             var_order.day_diliver_quantity,
             '',
             var_order.remain_days,
             VAR_REFUND_STATUS,
             VAR_SHIPPING_TIME,
             VAR_SHIPPING_TYPE,
             to_date(var_order.order_date_to, 'yyyy-MM-dd'),
             var_order.item_sn,
             var_order.act_price,
             decode(var_order.is_gift, '是', '1', '0'),
             var_order.sale_amount,
             var_order.line_count);
        
          UPDATE CUX_ORDER_EXCEL_T T
             SET T.FLAG = 'Y'
           WHERE T.ID = var_order.Id
             AND T.BATCH_ID = P_BATCH_ID;
        ELSE
          --失败了  需要删除ORDERS表中数据 并且更新临时表状态
          IF VAR_FLAG = 'N' THEN
            BEGIN
            DELETE FROM ORDERITEM WHERE ORDERS = VAR_ORDER_ID;
          EXCEPTION
            WHEN OTHERS THEN
              NULL;
          END;
        
          BEGIN
            DELETE FROM ORDERS WHERE ID = VAR_ORDER_ID;
          EXCEPTION
            WHEN OTHERS THEN
              NULL;
          END;
          END IF;
          
        
          UPDATE CUX_ORDER_EXCEL_T T
             SET T.FLAG = 'N', T.MSG = VAR_MSG
           WHERE T.ORDER_SN = VAR_ORDER.ORDER_SN
             AND T.BATCH_ID = P_BATCH_ID;
        END IF;
      
      END IF;
      COMMIT;
    END LOOP;
    SELECT COUNT(1)
      INTO V_RES
      FROM CUX_ORDER_EXCEL_T
     WHERE BATCH_ID = P_BATCH_ID
       AND FLAG = 'N';
    IF V_RES > 0 THEN
      P_CODE := 'N';
    ELSE
      P_CODE := 'Y';
    END IF;
  END;

  PROCEDURE GEN_MILKSTATION_USERS IS
    CURSOR CUR_MILKSTATION IS
      SELECT *
        FROM MILK_STATION
       WHERE ID IN (SELECT DISTINCT (MSL.HEADER_ID)
                      FROM MILK_STATION_LINE MSL
                     WHERE MSL.STATUS = 'VALID');
    --  and jz_flag = 'Y';
    VAR_MILK_STATION CUR_MILKSTATION%ROWTYPE;
    VAR_USER_ID      NUMBER;
    VAR_USER_ASSE_ID NUMBER;
    v_cnt            number;
    VAR_ASSESS_CNT   number;
  BEGIN
    --判断
    FOR VAR_MILK_STATION IN CUR_MILKSTATION LOOP
      BEGIN
        select count(1)
          into v_cnt
          from fnd_users fu
         where fu.mobilephone = VAR_MILK_STATION.Tel_Number;
        if v_cnt = 0 then
          SELECT fnd_user_s.nextval INTO VAR_USER_ID FROM dual;
          INSERT INTO FND_USERS
            (USER_ID,
             USER_TYPE,
             LOGIN_USERNAME,
             LOGIN_PASSWORD,
             START_DATE,
             MOBILEPHONE,
             LAST_UPDATE_DATE,
             LAST_UPDATED_BY,
             CREATION_DATE,
             CREATED_BY,
             STATUS,
             SEX,
             NAME,
             USER_CODE)
          VALUES
            (VAR_USER_ID,
             'MILK_STATION',
             VAR_MILK_STATION.TEL_NUMBER,
             '25F9E794323B453885F5181F1B624D0B',
             SYSDATE,
             VAR_MILK_STATION.TEL_NUMBER,
             SYSDATE,
             -1,
             SYSDATE,
             -1,
             'VALID',
             0,
             VAR_MILK_STATION.MANAGER,
             lpad(VAR_USER_ID, 7, 0));
        
          FND_UTIL.GET_PRIMARY_ID('FND_USER_ASSESS_AUTH', VAR_USER_ASSE_ID);
        
          INSERT INTO FND_USER_ASSESS_AUTH
            (USER_ID,
             MILK_STATION_ID,
             MS_COURIER_ID,
             VALID_FLAG,
             CREATED_BY,
             LAST_UPDATED_BY,
             AUTH_TYPE,
             CREATEDDATE,
             LASTMODIFIEDDATE,
             ID,
             VERSION)
          VALUES
            (VAR_USER_ID,
             VAR_MILK_STATION.ID,
             -1,
             'Y',
             -1,
             -1,
             'INCLUDE',
             SYSDATE,
             SYSDATE,
             VAR_USER_ASSE_ID,
             0);
        
          insert into fnd_user_resps
            (user_id,
             responsibility_id,
             start_date,
             end_date,
             last_update_date,
             last_updated_by,
             creation_date,
             created_by,
             attribute1,
             attribute2)
          values
            (VAR_USER_ID,
             168,
             sysdate,
             '',
             sysdate,
             -1,
             sysdate,
             -1,
             '站长',
             '站长');
        
        ELSE
          BEGIN
            SELECT FU.USER_ID
              INTO VAR_USER_ID
              FROM FND_USERS FU
             WHERE fu.mobilephone = VAR_MILK_STATION.Tel_Number;
          
            --判断是否已有当前奶站权限
            SELECT COUNT(1)
              INTO VAR_ASSESS_CNT
              FROM FND_USER_ASSESS_AUTH FUAA
             WHERE FUAA.USER_ID = VAR_USER_ID
               AND FUAA.MILK_STATION_ID = VAR_MILK_STATION.ID
               AND FUAA.MS_COURIER_ID = -1;
          
            IF VAR_ASSESS_CNT = 0 THEN
              FND_UTIL.GET_PRIMARY_ID('FND_USER_ASSESS_AUTH',
                                      VAR_USER_ASSE_ID);
            
              INSERT INTO FND_USER_ASSESS_AUTH
                (USER_ID,
                 MILK_STATION_ID,
                 MS_COURIER_ID,
                 VALID_FLAG,
                 CREATED_BY,
                 LAST_UPDATED_BY,
                 AUTH_TYPE,
                 CREATEDDATE,
                 LASTMODIFIEDDATE,
                 ID,
                 VERSION)
              VALUES
                (VAR_USER_ID,
                 VAR_MILK_STATION.ID,
                 -1,
                 'Y',
                 -1,
                 -1,
                 'INCLUDE',
                 SYSDATE,
                 SYSDATE,
                 VAR_USER_ASSE_ID,
                 0);
            END IF;
          EXCEPTION
            WHEN OTHERS THEN
              NULL;
          END;
        end if;
      EXCEPTION
        WHEN OTHERS THEN
          NULL;
      END;
    END LOOP;
  END;

  PROCEDURE IMPORT_PAUSE IS
    CURSOR CUR_PAU IS
      SELECT * FROM PAUSE_TEST WHERE FLAG = 'N';
    VAR_PAU          CUR_PAU%ROWTYPE;
    VAR_ID           NUMBER;
    VAR_ORDERITEM_ID NUMBER;
  BEGIN
    FOR VAR_PAU IN CUR_PAU LOOP
      begin
        FND_UTIL.GET_PRIMARY_ID('ORDER_PAUSE_INTERVAL', VAR_ID);
        begin
          select oi.id
            into VAR_ORDERITEM_ID
            from orderitem oi
           where oi.orders = (select id from orders where sn = VAR_PAU.SN)
             and oi.line_count = VAR_PAU.Line_Count;
        exception
          when others then
            update PAUSE_TEST
               set flag = 'E', MSG = '未找到对应的订单行'
             where id = VAR_PAU.Id;
            continue;
        end;
        INSERT INTO ORDER_PAUSE_INTERVAL
          (ID,
           createddate,
           lastmodifieddate,
           version,
           created_by,
           last_updated_by,
           orderitem_id,
           pause_status,
           quantity,
           pause_index,
           pause_date_from,
           RECOVERY_DATE,
           is_expiry_date_flag,
           pause_from)
        VALUES
          (VAR_ID,
           SYSDATE,
           SYSDATE,
           1,
           -1,
           -1,
           VAR_ORDERITEM_ID,
           'Y',
           VAR_PAU.QUANTITY,
           0,
           to_date(VAR_PAU.PAUSE_DATE, 'yyyy-MM-dd'),
           to_date(VAR_PAU.Recovy_Date, 'yyyy-MM-dd'),
           '',
           'CRM_ORDER_PAUSE');
        update PAUSE_TEST set flag = 'Y' where id = VAR_PAU.Id;
      
      exception
        when others then
          rollback;
      end;
      commit;
    END LOOP;
  END;

  PROCEDURE IMPORT_PRICE_LIST_FEE IS
    CURSOR CUR_PRI_LIST IS
      SELECT * FROM PRICE_LIST_TEST;
    VAR_PRI_LIST      CUR_PRI_LIST%ROWTYPE;
    VAR_PRI_HEADER_ID NUMBER;
    VAR_PRI_LINE_ID   NUMBER;
    VAR_FLAG          VARCHAR2(20);
    VAR_MSG           VARCHAR2(520);
  BEGIN
    FOR VAR_PRI_LIST IN CUR_PRI_LIST LOOP
      --判断价目表名称是否存在
      VAR_FLAG := 'Y';
      BEGIN
        SELECT PLH.ID
          INTO VAR_PRI_HEADER_ID
          FROM PRICE_LIST_HEADERS PLH
         WHERE PLH.PRICE_NAME = VAR_PRI_LIST.PRICE_LIST_NAME;
      EXCEPTION
        WHEN OTHERS THEN
          VAR_FLAG := 'N';
          VAR_MSG  := '获取价目表头表信息失败：未找到名为【' || VAR_PRI_LIST.PRICE_LIST_NAME ||
                      '】的价目表';
      END;
    
      IF VAR_FLAG = 'Y' THEN
        --判断物料编码、物料名称是否存在于该价目表下 且名称正确
        BEGIN
          SELECT PLL.ID
            INTO VAR_PRI_LINE_ID
            FROM PRICE_LIST_LINES PLL, PRODUCT PRD
           WHERE PLL.HEADER_ID = VAR_PRI_HEADER_ID
             AND PLL.PRODUCT_ID = PRD.ID
             AND PRD.SN = VAR_PRI_LIST.ITEM_SN;
          -- AND PRD.NAME = VAR_PRI_LIST.ITEM_NAME;
        EXCEPTION
          WHEN OTHERS THEN
            VAR_FLAG := 'N';
            VAR_MSG  := '获取价目表行表物料信息失败：未找到名称为【' || VAR_PRI_LIST.ITEM_NAME ||
                        '】、编码为【' || VAR_PRI_LIST.Item_Sn || '】的物料';
        END;
      END IF;
    
      IF VAR_FLAG = 'Y' THEN
        UPDATE PRICE_LIST_LINES PLL
           SET PLL.DEALERS_SHIPPING_FEE      = VAR_PRI_LIST.DEALERS_SHIPPING_FEE,
               PLL.MILK_STATION_SHIPPING_FEE = VAR_PRI_LIST.MILKSTATION_SHIPPING_FEE,
               PLL.MS_COURIER_SHIPPING_FEE   = VAR_PRI_LIST.MSCOURIER_SHIPPING_FEE,
               PLL.LOGISTICS_COST            = VAR_PRI_LIST.LOGISTICS_FEE
         WHERE PLL.ID = VAR_PRI_LINE_ID;
      
        UPDATE PRICE_LIST_TEST T
           SET T.FLAG = 'Y'
         WHERE T.PRICE_LIST_NAME = VAR_PRI_LIST.PRICE_LIST_NAME
           AND T.ITEM_SN = VAR_PRI_LIST.ITEM_SN
           AND T.ITEM_NAME = VAR_PRI_LIST.ITEM_NAME;
        COMMIT;
      ELSE
        UPDATE PRICE_LIST_TEST T
           SET T.FLAG = VAR_FLAG, T.MSG = VAR_MSG
         WHERE T.PRICE_LIST_NAME = VAR_PRI_LIST.PRICE_LIST_NAME
           AND T.ITEM_SN = VAR_PRI_LIST.ITEM_SN
           AND T.ITEM_NAME = VAR_PRI_LIST.ITEM_NAME;
      END IF;
    END LOOP;
  END;
end syjd_data_initialize_pkg;

/

