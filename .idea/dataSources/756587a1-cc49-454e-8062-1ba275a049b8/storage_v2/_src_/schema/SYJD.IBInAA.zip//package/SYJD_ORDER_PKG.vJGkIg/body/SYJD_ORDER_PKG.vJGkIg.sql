create PACKAGE BODY syjd_order_pkg IS

  --根据订单地址匹配地址库信息，对订单分配奶站及送奶工
  PROCEDURE allot_orders(p_order_id IN NUMBER,
                         x_code     OUT VARCHAR2,
                         x_msg      OUT VARCHAR2) IS
    l_area_id         NUMBER;
    l_addr            VARCHAR2(200);
    l_ms_courier_id   NUMBER;
    l_milk_station_id NUMBER;
    l_cnt             NUMBER;
  
    CURSOR c_addr_base(cp_area_id NUMBER, cp_addr VARCHAR2) IS
      SELECT ab.MS_COURIER_ID, ab.MILK_STATION_ID
        FROM ADDRESSBASE ab
        LEFT JOIN MILK_STATION ms
          ON ab.MILK_STATION_ID = ms.ID
        LEFT JOIN MS_COURIER mc
          ON ab.MS_COURIER_ID = mc.ID
       WHERE ab.AREA_ID = nvl(cp_area_id, ab.AREA_ID)
         AND instr(cp_addr, ab.DETAILED_ADDRESS) <> 0
       ORDER BY ms.CREDIT_SCORE DESC, mc.SCORE DESC;
  
  BEGIN
    IF p_order_id IS NULL THEN
      x_code := 'E';
      x_msg  := '分单失败:入参p_order_id不能为空';
      RETURN;
    END IF;
  
    --获取订单区域id和详细地址
    SELECT od.AREA_ID, od.ADDRESS
      INTO l_area_id, l_addr
      FROM ORDERS od
     WHERE od.ID = p_order_id;
  
    SELECT count(*)
      INTO l_cnt
      FROM ADDRESSBASE ab
      LEFT JOIN MILK_STATION ms
        ON ab.MILK_STATION_ID = ms.ID
      LEFT JOIN MS_COURIER mc
        ON ab.MS_COURIER_ID = mc.ID
     WHERE ab.AREA_ID = nvl(l_area_id, ab.AREA_ID)
       AND instr(l_addr, ab.DETAILED_ADDRESS) <> 0;
  
    IF l_cnt = 0 THEN
      x_code := 'E';
      x_msg  := '分单失败:不能识别订单地址，请进行手工分单！';
      RETURN;
    END IF;
  
    --通过游标获取奶站和配送员
    OPEN c_addr_base(l_area_id, l_addr);
    FETCH c_addr_base
      INTO l_ms_courier_id, l_milk_station_id;
    CLOSE c_addr_base;
  
    --更新订单
    UPDATE ORDERS
       SET MILK_STATION_ID = l_milk_station_id,
           --MS_COURIER_ID    = l_ms_courier_id,
           LASTMODIFIEDDATE = sysdate
     WHERE ID = p_order_id;
  
    x_code := 'S';
    x_msg  := '分单成功';
  EXCEPTION
    WHEN OTHERS THEN
      x_code := 'E';
      x_msg  := '分单失败:' || sqlcode || sqlerrm;
    
  END allot_orders;

  --根据订单生成配送单
  PROCEDURE gen_shippingorder(p_order_id       IN NUMBER,
                              p_date           IN VARCHAR2,
                              p_user_id        IN INT,
                              p_type           IN VARCHAR2,
                              p_area_city_name IN VARCHAR2,
                              p_dealers_id     IN VARCHAR2,
                              p_shipping_group IN VARCHAR2,
                              p_status         out VARCHAR2) IS
    CURSOR c_order IS
      SELECT DISTINCT oh.ADDRESS,
                      oh.AREANAME,
                      oh.CONSIGNEE,
                      oh.PHONE,
                      oh.SHIPPINGMETHODNAME,
                      oh.ZIPCODE,
                      oh.ID,
                      oh.MILK_STATION_ID,
                      oh.MS_COURIER_ID
        FROM ORDERS oh
        JOIN milk_station ms
          ON ms.id = oh.milk_station_id
            --and nvl(ms.shipping_group,'ALL') = nvl(p_shipping_group,'ALL') 
         and nvl(ms.shipping_group, 'ALL') =
             nvl(p_shipping_group, nvl(ms.shipping_group, 'ALL'))
       WHERE 1 = 1
         AND oh.ID = nvl(p_order_id, oh.ID)
         AND oh.status not in (0, 9) ---未支付与后台关闭
         and oh.status in ('2', '10')
         AND (oh.valid_milkstation_flag = 'Y' OR
             oh.valid_milkstation_flag is null)
         and (FND_UTIL.validate_order_status(oh.ORDER_FROM, p_type, 'CRM')) = 'Y'
         and nvl(oh.areaname, 'ALL') like
             nvl(nvl('%' || p_area_city_name || '%', oh.areaname), 'ALL')
         and oh.milk_station_id in
             (select msl.header_id
                from milk_station_line msl
               where msl.dealers_id = nvl(p_dealers_id, msl.dealers_id))
         AND oh.Milk_Station_Id is not null;
    /* and ms.SENDERPFLAG = 'Y';*/
    --控制该订单不在批量暂停区间内
    --AND judge_pause_flag(NVL(oh.ms_courier_id,0), p_order_id) = 'Y';
  
    CURSOR c_orderitem(cp_order_id NUMBER, cp_date DATE) IS
      SELECT oi.ID,
             oi.NAME,
             oi.QUANTITY,
             oi.DAILY_DELIVERY_QUANTITY,
             oi.PRODUCT_SN,
             oi.SPECIFICATIONS,
             oi.SKU_ID,
             oi.WEIGHT,
             oi.DAY_SHIPPING_TIME,
             oi.SHIPPING_TYPE,
             oi.PRICE,
             oi.wdtorderitemid,
             oi.order_date_to
        FROM ORDERITEM oi
       WHERE oi.ORDERS = cp_order_id
         and nvl(oi.refund_status, -1) <> 5
         AND trunc(nvl(cp_date, sysdate)) >= trunc(oi.ORDER_DATE_FROM)
            /*AND (oi.productcomboboflag = 'N' or oi.productcomboboflag is null)*/
         AND (oi.ORDER_DATE_TO IS NULL OR
             trunc(nvl(cp_date, sysdate)) <= trunc(oi.ORDER_DATE_TO));
    /* union all
    SELECT oi.ID,
           oi.NAME,
           oi.QUANTITY,
           oi.DAILY_DELIVERY_QUANTITY,
           oi.PRODUCT_SN,
           oi.SPECIFICATIONS,
           oi.SKU_ID,
           oi.WEIGHT,
           oi.DAY_SHIPPING_TIME,
           oi.SHIPPING_TYPE,
           pll.price_zd PRICE,
           oi.wdtorderitemid,
           oi.order_date_to
      FROM ORDERITEM          oi,
           productcombo       p,
           productcombo_line  pl,
           product            pt,
           PRICE_LIST_HEADERS plh,
           PRICE_LIST_LINES   pll
     WHERE oi.ORDERS = cp_order_id
       AND trunc(nvl(cp_date, sysdate)) >= trunc(oi.ORDER_DATE_FROM)
       AND (oi.ORDER_DATE_TO IS NULL OR
           trunc(nvl(cp_date, sysdate)) <= trunc(oi.ORDER_DATE_TO))
       AND oi.productcomboboflag = 'Y' --表示是商品套餐
       AND oi.sn = p.id --是商品套餐则商品套餐的编码是套餐I
       and p.id = pl.combo_header_id
       and pt.id = pl.product_id
       AND plh.ATTRIBUTE1 = 'ONLINE' --锁定唯一线上商品价目表
       AND (plh.STATUS = 'VALID' OR plh.STATUS is NULL)
       AND sysdate >= plh.START_DATE
       AND (sysdate <= plh.END_DATE OR plh.END_DATE is NULL)
       AND plh.id = pll.HEADER_ID
       AND sysdate >= pll.START_DATE
       AND (sysdate <= pll.END_DATE OR pll.END_DATE is NULL)
       AND PLL.PRODUCT_ID = PT.ID;*/
  
    l_date                        DATE;
    l_cnt                         NUMBER;
    l_ordershipping_id            NUMBER;
    l_pause_quantity              NUMBER;
    l_quantity                    NUMBER;
    l_left_quantity               NUMBER;
    l_shipped_quantity            NUMBER;
    l_line_cnt                    NUMBER;
    l_end_flag                    varchar2(10) default 'N';
    l_countholiday                number;
    l_linemaxdate                 DATE; --用来判断是否是最后一天
    l_countfinaldate              number; --用来计算终止日期是否是待定
    v_detail                      varchar2(500);
    var_dealers_shipping_fee      number;
    var_milk_station_shipping_fee number;
    var_ms_courier_shipping_fee   number;
  BEGIN
    --根据订单商品行的配送起始/终止日期、配送方式、配送天数、配送数量自动生成T+1日的配送信息
    FOR v_orders IN c_order LOOP
      FOR day IN 0 .. 0 LOOP
        l_ordershipping_id := null;
      
        l_date := nvl(to_date(p_date, 'yyyy-mm-dd'), sysdate) + day;
        /*IF trunc(l_date) <= trunc(v_orders.ORDER_DATE_TO) or
        v_orders.ORDER_DATE_TO is null THEN*/
      
        --判断l_date是否已生成过配送单
        SELECT count(*)
          INTO l_cnt
          FROM ORDERSHIPPING t
         WHERE t.ORDERS = v_orders.ID
           AND trunc(t.SHIPPING_DATE) = trunc(l_date)
           AND NVL(T.STATUS, 'VALID') = 'VALID'; ----added by yuchao on 2018.5.18
      
        --未生成配送单则自动生成
        IF l_cnt = 0 THEN
          l_line_cnt := 0;
          DBMS_OUTPUT.put_line(v_orders.ID);
          DBMS_OUTPUT.put_line(l_date);
        
          FOR v_orderitem IN c_orderitem(v_orders.ID, l_date) LOOP
            select count(1)
              into l_countholiday
              from holiday
             where l_date = holiday_date;
            --根据配送方式SHIPPING_TYPE判断是否需要生成配送单
            IF v_orderitem.SHIPPING_TYPE = 0 OR
               (v_orderitem.SHIPPING_TYPE = 1 AND
               to_char(l_date, 'd') NOT IN (1, 7) and l_countholiday = 0) THEN
            
              --判断当天l_date是否存在生效的暂停配送记录,如果暂停来源是CRM的话，则暂停数量为配送数量
              --先判断有没有来源于CRM的暂停
              l_pause_quantity := 0;
              /* SELECT count(*)
                INTO l_cnt
                FROM ORDER_PAUSE_INTERVAL opi
               WHERE opi.ORDERITEM_ID = v_orderitem.ID
                 AND nvl(opi.PAUSE_STATUS, 'N') = 'Y'
                 AND trunc(opi.pause_date_from) <= trunc(l_date)
                 AND (opi.recovery_date is null OR
                     trunc(opi.recovery_date) > trunc(l_date))
                 AND opi.PAUSE_FROM = 'CRM';
              
              IF l_cnt !=0 THEN
                l_pause_quantity := v_orderitem.DAILY_DELIVERY_QUANTITY;*/
              --如果没有来源于CRM的暂停，则判断有没有其他暂停
              /* ELSE*/
              SELECT count(*)
                INTO l_cnt
                FROM ORDER_PAUSE_INTERVAL opi
               WHERE opi.ORDERITEM_ID = v_orderitem.ID
                 AND nvl(opi.PAUSE_STATUS, 'N') = 'Y'
                 AND trunc(opi.pause_date_from) <= trunc(l_date)
                 AND (opi.recovery_date is null OR
                     trunc(opi.recovery_date) > trunc(l_date));
              IF l_cnt != 0 THEN
                SELECT nvl(opi.QUANTITY, 0)
                  INTO l_pause_quantity
                  FROM ORDER_PAUSE_INTERVAL opi
                 WHERE opi.ORDERITEM_ID = v_orderitem.ID
                   AND trunc(opi.pause_date_from) <= trunc(l_date)
                   AND (opi.recovery_date is null OR
                       trunc(opi.recovery_date) > trunc(l_date))
                   AND nvl(opi.PAUSE_STATUS, 'N') = 'Y'
                   AND ROWNUM = 1;
              END IF;
              /* END IF;*/
              --扣减暂停数量
              if sign(v_orderitem.DAILY_DELIVERY_QUANTITY -
                      l_pause_quantity) = 0 then
                l_quantity := 0;
              else
                l_quantity := v_orderitem.DAILY_DELIVERY_QUANTITY -
                              l_pause_quantity;
              end if;
            
              --计算剩余已配送量
              /*  SELECT nvl(sum(osi.QUANTITY), 0) QUANTITY
                INTO l_shipped_quantity
                FROM ORDERSHIPPING os, ORDERSHIPPINGITEM osi
               WHERE os.ID = osi.ORDERSHIPPING_ID
                 AND os.ORDERS = v_orders.ID
                 AND osi.orderitemid = v_orderitem.id
                 AND osi.SN = v_orderitem.PRODUCT_SN;
              --计算可配送量
              l_left_quantity := v_orderitem.QUANTITY -
                                 l_shipped_quantity;
              
              --计算实际配送量
              if sign(l_left_quantity - l_quantity) = -1 then
                l_quantity := 0;
              else
                l_quantity := l_quantity;
              end if;*/
            
              if l_quantity != 0 then
                if l_ordershipping_id is null then
                  --生成配送单id
                  l_ordershipping_id := GET_PRIMARY_ID('ORDERSHIPPING');
                  --插入配送单头信息
                  INSERT INTO ORDERSHIPPING
                    (ID,
                     CREATEDDATE,
                     LASTMODIFIEDDATE,
                     VERSION,
                     ADDRESS,
                     AREA,
                     CONSIGNEE,
                     DELIVERYCORP,
                     DELIVERYCORPCODE,
                     DELIVERYCORPURL,
                     FREIGHT,
                     MEMO,
                     PHONE,
                     SHIPPINGMETHOD,
                     SN,
                     TRACKINGNO,
                     ZIPCODE,
                     ORDERS,
                     CREATED_BY,
                     LAST_UPDATED_BY,
                     SHIPPING_DATE,
                     MILK_STATION_ID,
                     MS_COURIER_ID,
                     STATUS)
                  VALUES
                    (l_ordershipping_id,
                     sysdate,
                     sysdate,
                     0,
                     v_orders.ADDRESS,
                     v_orders.AREANAME,
                     v_orders.CONSIGNEE,
                     NULL,
                     NULL,
                     NULL,
                     NULL,
                     NULL,
                     v_orders.PHONE,
                     v_orders.SHIPPINGMETHODNAME,
                     to_char(sysdate, 'yyyymmdd') ||
                     to_char(l_ordershipping_id) || to_char(day),
                     NULL,
                     v_orders.ZIPCODE,
                     v_orders.ID,
                     p_user_id,
                     p_user_id,
                     l_date,
                     v_orders.MILK_STATION_ID,
                     v_orders.MS_COURIER_ID,
                     'VALID');
                end if;
                ----生成配送单信息插入日志
                v_detail := '奶站ID:' || v_orders.MILK_STATION_ID || '配送员ID:' ||
                            v_orders.MS_COURIER_ID || '生成配送单' || ',订单ID:' ||
                            v_orders.ID || '配送单ID:' || l_ordershipping_id ||
                            '配送日期' || l_date;
                INSERT INTO ORDERLOG
                  (ID,
                   CREATEDDATE,
                   LASTMODIFIEDDATE,
                   VERSION,
                   DETAIL,
                   TYPE,
                   ORDERS,
                   CREATED_BY,
                   LAST_UPDATED_BY,
                   MILK_STATION_ID,
                   MS_COURIER_ID)
                VALUES
                  (GET_PRIMARY_ID('ORDERLOG'),
                   sysdate,
                   sysdate,
                   1,
                   v_detail,
                   1,
                   v_orders.ID,
                   p_user_id,
                   p_user_id,
                   v_orders.MILK_STATION_ID,
                   v_orders.MS_COURIER_ID);
                --获取经销商、奶站和配送员配送费 added by wangye 2018年5月29日
                begin
                  select nvl(pll.dealers_shipping_fee, 0),
                         nvl(pll.milk_station_shipping_fee, 0),
                         nvl(pll.ms_courier_shipping_fee, 0)
                    into var_dealers_shipping_fee,
                         var_milk_station_shipping_fee,
                         var_ms_courier_shipping_fee
                    from milk_station       ms,
                         milk_station_line  msl,
                         dealers            de,
                         price_list_headers plh,
                         price_list_lines   pll,
                         product            prd
                   where 1 = 1
                     and ms.id = msl.header_id
                     and msl.dealers_id = de.id
                     and de.source = upper(p_type)
                     and msl.price_list_id = plh.id
                     and plh.id = pll.header_id
                     and pll.product_id = prd.id
                     and prd.sn = v_orderitem.PRODUCT_SN
                     and ms.id = v_orders.MILK_STATION_ID;
                exception
                  when others then
                    var_dealers_shipping_fee      := -1;
                    var_milk_station_shipping_fee := -1;
                    var_ms_courier_shipping_fee   := -1;
                end;
              
                INSERT INTO ORDERSHIPPINGITEM
                  (ID,
                   CREATEDDATE,
                   LASTMODIFIEDDATE,
                   VERSION,
                   ISDELIVERY,
                   NAME,
                   QUANTITY,
                   SN,
                   SPECIFICATIONS,
                   ORDERSHIPPING_ID,
                   SKU_ID,
                   CREATED_BY,
                   LAST_UPDATED_BY,
                   WEIGHT,
                   FREIGHT,
                   DAY_SHIPPING_TIME,
                   ORDERITEMID,
                   PRESENT_FLAG,
                   WDTORDERITEMID,
                   DEALERS_SHIPPING_FEE,
                   MILKSTATION_SHIPPING_FEE,
                   MSCOURIER_SHIPPING_FEE)
                VALUES
                  (GET_PRIMARY_ID('ORDERSHIPPINGITEM'),
                   sysdate,
                   sysdate,
                   0,
                   0,
                   v_orderitem.NAME,
                   l_quantity,
                   v_orderitem.PRODUCT_SN,
                   v_orderitem.SPECIFICATIONS,
                   l_ordershipping_id,
                   v_orderitem.SKU_ID,
                   p_user_id,
                   p_user_id,
                   v_orderitem.WEIGHT,
                   0,
                   v_orderitem.DAY_SHIPPING_TIME,
                   v_orderitem.id,
                   (CASE WHEN v_orderitem.PRICE = 0 THEN 'Y' ELSE 'N' END),
                   v_orderitem.wdtorderitemid,
                   var_dealers_shipping_fee,
                   var_milk_station_shipping_fee,
                   var_ms_courier_shipping_fee);
                update orderitem
                   set remain_days = remain_days - 1
                 where id = v_orderitem.id;
                l_line_cnt := l_line_cnt + 1;
              end if;
            END IF;
            IF trunc(l_date) = trunc(v_orderitem.order_date_to) THEN
              l_end_flag := 'Y';
            else
              l_end_flag := 'N';
            end if;
          END LOOP;
        END IF;
        --判断生成配送单的日期是否是订单配送的最后一天
        /* IF l_end_flag = 'Y' THEN
          --更新订单状态为已完成 已完成状态为5
          UPDATE ORDERS OS SET os.status = '5' where os.id = v_orders.id;
        END IF;*/
        SELECT MAX(ORDER_DATE_TO)
          INTO l_linemaxdate
          FROM ORDERITEM
         WHERE ORDERS = v_orders.id
           and order_date_to is not null
           and (refund_status <> '5' or refund_status is null);
        SELECT count(id)
          INTO l_countfinaldate
          FROM ORDERITEM
         WHERE ORDERS = v_orders.id
           and order_date_to is null
           and (refund_status <> '5' or refund_status is null);
        IF TRUNC(l_linemaxdate) <= l_date THEN
          --更新订单状态为已完成 已完成状态为5
          if l_countfinaldate = 0 then
            UPDATE ORDERS os
               SET os.status = '5', os.lastmodifieddate = sysdate
             where os.id = v_orders.id;
          end if;
        END IF;
        /* END IF;*/
      END LOOP;
      commit;
    END LOOP;
    p_status := 'Y';
  END gen_shippingorder;

  --生成生产计划
  PROCEDURE gen_production_plan(p_date    IN VARCHAR2,
                                p_user_id IN NUMBER,
                                x_code    OUT VARCHAR2,
                                x_msg     OUT VARCHAR2) IS
    CURSOR c_product IS
      SELECT ID, SN, NAME, 3 ADVANCE_DAY, 35 UNIT_PER_BOX FROM PRODUCT;
  
    CURSOR c_order_shipping(cp_date DATE, cp_product_sn VARCHAR2) IS
      SELECT nvl(sum(osi.QUANTITY), 0) QUANTITY
        FROM ORDERSHIPPING os, ORDERSHIPPINGITEM osi
       WHERE os.ID = osi.ORDERSHIPPING_ID
         AND trunc(os.SHIPPING_DATE) = trunc(cp_date)
         AND osi.SN = cp_product_sn;
  
    l_plan_id  NUMBER;
    l_quantity NUMBER;
    l_date     DATE;
    l_item_cnt NUMBER := 0;
  
  BEGIN
    l_plan_id := GET_PRIMARY_ID('PRODUCTION_PLAN');
  
    FOR v_product IN c_product LOOP
      l_date := to_date(p_date, 'yyyy-mm-dd') + v_product.ADVANCE_DAY; --生产日期+生产提前期
    
      --如已经生成，则先删除
      DELETE FROM PRODUCTION_PLAN_ITEM t
       WHERE t.PRODUCTION_PLAN_ID IN
             (SELECT ID FROM PRODUCTION_PLAN h WHERE h.PRODUCT_DATE = l_date);
      DELETE FROM PRODUCTION_PLAN h WHERE h.PRODUCT_DATE = l_date;
    
      OPEN c_order_shipping(l_date, v_product.SN);
      FETCH c_order_shipping
        INTO l_quantity;
      CLOSE c_order_shipping;
    
      if nvl(l_quantity, 0) != 0 THEN
        INSERT INTO PRODUCTION_PLAN_ITEM
          (ID,
           CREATEDDATE,
           LASTMODIFIEDDATE,
           VERSION,
           PRODUCTION_PLAN_ID,
           PRODUCT_ID,
           PRODUCT_SN,
           PRODUCT_NAME,
           DEMAND_DATE,
           QUANTITY,
           BOX_QUANTITY,
           CREATED_BY,
           LAST_UPDATED_BY)
        VALUES
          (GET_PRIMARY_ID('PRODUCTION_PLAN_ITEM'),
           sysdate,
           sysdate,
           0,
           l_plan_id,
           v_product.ID,
           v_product.SN,
           v_product.NAME,
           l_date,
           l_quantity,
           ceil(l_quantity / v_product.UNIT_PER_BOX),
           p_user_id,
           p_user_id);
        l_item_cnt := l_item_cnt + 1;
      END IF;
    
    END LOOP;
  
    if l_item_cnt != 0 THEN
      INSERT INTO PRODUCTION_PLAN
        (ID,
         CREATEDDATE,
         LASTMODIFIEDDATE,
         VERSION,
         PRODUCT_DATE,
         SN,
         CREATED_BY,
         LAST_UPDATED_BY)
      VALUES
        (l_plan_id,
         sysdate,
         sysdate,
         0,
         to_date(p_date, 'yyyy-mm-dd'),
         to_char(sysdate, 'yyyymmddhh24miss'),
         p_user_id,
         p_user_id);
    END IF;
  
    x_code := 'S';
    x_msg  := '生成成功';
  
  EXCEPTION
    WHEN OTHERS THEN
      x_code := 'E';
      x_msg  := '生成生产计划失败:' || sqlcode || sqlerrm;
    
  END gen_production_plan;

  --生成ebs销售订单
  procedure gen_erp_order(p_date    IN VARCHAR2,
                          p_user_id IN NUMBER,
                          x_code    OUT VARCHAR2,
                          x_msg     OUT VARCHAR2) IS
    cursor c_order is
      SELECT DISTINCT flv.attribute1 ORDER_FROM,
                      d.id dealer_id,
                      msl.id MILK_STATION_ID,
                      ms.salesman_id salesman_id,
                      trunc(os.SHIPPING_DATE) ORDER_DATE
        FROM ORDERSHIPPING     os,
             ORDERS            od,
             ORDERSHIPPINGITEM osi,
             PRODUCT           pd,
             FND_LOOKUP_VALUES flv,
             MILK_STATION      ms,
             MILK_STATION_LINE msl,
             DEALERS           d
       WHERE 1 = 1
         and (os.gen_erp_order_flag <> 'Y' or os.gen_erp_order_flag is null)
         and od.id = os.orders
         and os.id = osi.ordershipping_id
         and ms.id = od.milk_station_id
         and ms.id = msl.header_id
         and od.order_from <> 'OFFLINE'
         and d.id = msl.dealers_id
         AND trunc(os.SHIPPING_DATE) = TRUNC(to_date(p_date, 'yyyy-mm-dd'))
         AND nvl(osi.QUANTITY, 0) != 0
         AND od.MILK_STATION_ID IS NOT NULL
         AND pd.ERP_ITEM_ID is not null
         AND flv.LOOKUP_CODE = od.ORDER_FROM
         AND msl.status = 'VALID'
         and od.type <> '3'
         And d.source = flv.attribute1
         and flv.LOOKUP_TYPE = 'ORDER_FROM'
         and (ms.SENDERPFLAG = 'Y'
             /*or
             (FND_UTIL.validate_order_status(od.ORDER_FROM,'ONLINE','CRM')) = 'Y'*/
             );
  
    cursor c_order_item(cp_milk_station_id number, cp_order_from varchar2) is
    
      SELECT t.PRODUCT_ID,
             t.ERP_INVENTORY_ITEM_ID,
             sum(t.QUANTITY) QUANTITY,
             /*round(avg(odi.price), 7) price,*/
             round(t.price, 7) price,
             t.PROMITION_TYPE,
             t.PRESENT_FLAG
        FROM (SELECT pd.ID PRODUCT_ID,
                     pd.ERP_ITEM_ID ERP_INVENTORY_ITEM_ID,
                     sum(osi.QUANTITY) QUANTITY,
                     /*round(avg(odi.price), 7) price,*/
                     round(odi.price, 7) price,
                     'mr' PROMITION_TYPE,
                     DECODE(odi.present_flag, '1', 'TX', 'MP') PRESENT_FLAG
                FROM ORDERSHIPPING     os,
                     ORDERS            od,
                     ORDERSHIPPINGITEM osi,
                     ORDERITEM         odi,
                     PRODUCT           pd,
                     FND_LOOKUP_VALUES flv
               WHERE 1 = 1
                 AND os.ORDERS = od.id
                 and (os.gen_erp_order_flag <> 'Y' or
                     os.gen_erp_order_flag is null)
                 AND os.ID = osi.ORDERSHIPPING_ID
                 AND flv.lookup_code = od.order_from
                 AND flv.lookup_type = 'ORDER_FROM'
                 AND osi.SN = pd.SN
                 and od.type <> '3'
                 AND osi.orderitemid = odi.id
                 AND od.order_from <> 'OFFLINE'
                 AND od.ID = odi.ORDERS
                 AND trunc(os.SHIPPING_DATE) =
                     trunc(to_date(p_date, 'yyyy-mm-dd'))
                 AND flv.attribute1 = cp_order_from
                 AND od.milk_station_id =
                     (select header_id
                        from MILK_STATION_LINE
                       where id = cp_milk_station_id)
                 AND pd.ERP_ITEM_ID is not null
                 and odi.price is not null
                 and odi.sn not like 'TC%'
                 and (pd.type <> '3' or pd.type is null)
               GROUP BY pd.ID, pd.ERP_ITEM_ID, odi.present_flag, odi.price
              
              union all
              
              SELECT p.ID PRODUCT_ID,
                     p.ERP_ITEM_ID ERP_INVENTORY_ITEM_ID,
                     sum(pcl.quantity * osi.quantity) QUANTITY, --取套餐里的商品数量
                     /*round(avg(odi.price), 7) price,*/
                     round(pll.price_zd, 7) price,
                     'mr' PROMITION_TYPE,
                     DECODE(odi.present_flag, '1', 'TX', 'MP') PRESENT_FLAG
                FROM ORDERSHIPPING     os,
                     ORDERS            od,
                     ORDERSHIPPINGITEM osi,
                     ORDERITEM         odi,
                     PRODUCT           pd, --商品套餐
                     product           p, --商品套餐行
                     productcombo_line pcl,
                     FND_LOOKUP_VALUES flv,
                     -- productcombo_line  pcl,
                     PRICE_LIST_HEADERS plh,
                     PRICE_LIST_LINES   pll
               WHERE 1 = 1
                 AND os.ORDERS = od.id
                 and (os.gen_erp_order_flag <> 'Y' or
                     os.gen_erp_order_flag is null)
                 AND os.ID = osi.ORDERSHIPPING_ID
                 AND flv.lookup_code = od.order_from
                 and od.type <> '3'
                 AND flv.lookup_type = 'ORDER_FROM'
                    --  AND osi.SN = pd.SN
                 AND osi.orderitemid = odi.id
                 AND od.order_from <> 'OFFLINE'
                 AND od.ID = odi.ORDERS
                 AND trunc(os.SHIPPING_DATE) =
                     trunc(to_date(p_date, 'yyyy-mm-dd'))
                 AND flv.attribute1 = cp_order_from
                 AND od.milk_station_id =
                     (select header_id
                        from MILK_STATION_LINE
                       where id = cp_milk_station_id)
                 AND p.ERP_ITEM_ID is not null --套餐行ERPid不能为空
                 and odi.price is not null
                    -- and (odi.sn  like 'TC%')
                 and (pd.type = '3')
                 and odi.sn = pd.sn
                 and pd.id = pcl.combo_header_id
                 and p.id = pcl.product_id
                 AND plh.ATTRIBUTE1 = 'ONLINE' --锁定唯一线上商品价目表
                 AND (plh.STATUS = 'VALID' OR plh.STATUS is NULL)
                 AND sysdate >= plh.START_DATE
                 AND (sysdate <= plh.END_DATE OR plh.END_DATE is NULL)
                 AND plh.id = pll.HEADER_ID
                 AND sysdate >= pll.START_DATE
                 AND (sysdate <= pll.END_DATE OR pll.END_DATE is NULL)
                 AND PLL.PRODUCT_ID = p.ID
               GROUP BY p.ID, p.ERP_ITEM_ID, odi.present_flag, pll.price_zd) T
       GROUP BY T.PRODUCT_ID,
                T.ERP_INVENTORY_ITEM_ID,
                T.price,
                T.PRESENT_FLAG,
                T.PROMITION_TYPE;
    /*HAVING sum(osi.QUANTITY) != 0;*/
  
    l_id              number;
    l_count           number;
    l_line_count      number;
    syjd_erp_order_id number;
  begin
    for v_order in c_order loop
      begin
        /* select count(1)
         into l_count
         from syjd_erp_order
        where dealer_id = v_order.dealer_id
          and milke_station_id = v_order.milk_station_id
          and TRUNC(order_date) = TRUNC(v_order.order_date)
          and salesman_id = v_order.salesman_id;*/
      
        l_id := get_primary_id('syjd_erp_order');
        /* if l_count = 0 then*/ --现在采取对配送单打标识的方法进行操作
        /*表示新增*/ --每次传ERP不需要更新订单了
        insert into syjd_erp_order
          (ID,
           CREATED_BY,
           CREATION_DATE,
           LAST_UPDATED_BY,
           LAST_UPDATE_DATE,
           DEALER_ID,
           MILKE_STATION_ID,
           ORDER_DATE,
           CODE,
           MESSAGE,
           SALESMAN_ID,
           order_type)
        values
          (l_id,
           p_user_id,
           sysdate,
           p_user_id,
           sysdate,
           v_order.dealer_id,
           v_order.milk_station_id,
           v_order.order_date,
           'WSC',
           '未上传',
           v_order.salesman_id,
           v_order.order_from);
      
        for v_order_item in c_order_item(v_order.milk_station_id,
                                         v_order.ORDER_FROM) loop
          insert into syjd_erp_order_item
            (ID,
             ORDER_ID,
             CREATED_BY,
             CREATION_DATE,
             LAST_UPDATED_BY,
             LAST_UPDATE_DATE,
             PRODUCT_ID,
             ERP_INVENTORY_ITEM_ID,
             QUANTITY,
             PRICE,
             PROMOTION_TYPE,
             PRESENT_FLAG)
          values
            (get_primary_id('syjd_erp_order_item'),
             l_id,
             p_user_id,
             sysdate,
             p_user_id,
             sysdate,
             v_order_item.product_id,
             v_order_item.erp_inventory_item_id,
             v_order_item.quantity,
             v_order_item.price,
             v_order_item.PROMITION_TYPE,
             v_order_item.PRESENT_FLAG);
        end loop;
        /* else
          \*如果是更新的情况则将头ID查出来，*\
          select id
            into syjd_erp_order_id
            from syjd_erp_order
           where dealer_id = v_order.dealer_id
             and milke_station_id = v_order.milk_station_id
             and TRUNC(order_date) = TRUNC(v_order.order_date)
             and salesman_id = v_order.salesman_id;
          update syjd_erp_order
             set code = 'WSC'
           where id = syjd_erp_order_id;
          for v_order_item in c_order_item(v_order.milk_station_id,
                                           v_order.ORDER_FROM) loop
            select count(1)
              into l_line_count
              from syjd_erp_order_item
             where order_id = syjd_erp_order_id
               and ERP_INVENTORY_ITEM_ID = v_order_item.erp_inventory_item_id
               and price = v_order_item.price;
            if l_line_count = 0 then
              insert into syjd_erp_order_item
                (ID,
                 ORDER_ID,
                 CREATED_BY,
                 CREATION_DATE,
                 LAST_UPDATED_BY,
                 LAST_UPDATE_DATE,
                 PRODUCT_ID,
                 ERP_INVENTORY_ITEM_ID,
                 QUANTITY,
                 PRICE,
                 PROMOTION_TYPE,
                 PRESENT_FLAG)
              values
                (get_primary_id('syjd_erp_order_item'),
                 syjd_erp_order_id,
                 p_user_id,
                 sysdate,
                 p_user_id,
                 sysdate,
                 v_order_item.product_id,
                 v_order_item.erp_inventory_item_id,
                 v_order_item.quantity,
                 v_order_item.price,
                 v_order_item.PROMITION_TYPE,
                 v_order_item.PRESENT_FLAG);
            else
              update syjd_erp_order_item
                 set LAST_UPDATE_DATE      = sysdate,
                     PRODUCT_ID            = v_order_item.product_id,
                     ERP_INVENTORY_ITEM_ID = v_order_item.erp_inventory_item_id,
                     QUANTITY              = v_order_item.quantity,
                     PRICE                 = v_order_item.price,
                     PROMOTION_TYPE        = v_order_item.PROMITION_TYPE,
                     PRESENT_FLAG          = v_order_item.PRESENT_FLAG
               where order_id = syjd_erp_order_id
                 and ERP_INVENTORY_ITEM_ID =
                     v_order_item.erp_inventory_item_id
                 and price = v_order_item.price;
            end if;
           end loop;
        end if;*/
      
        update ordershipping
           set gen_erp_order_flag = 'Y', lastmodifieddate = sysdate
         where milk_station_id =
               (select header_id
                  from milk_station_line
                 where id = v_order.milk_station_id)
           and trunc(v_order.order_date) = trunc(shipping_date);
      EXCEPTION
        WHEN OTHERS THEN
          x_code := 'E';
          x_msg  := '生成失败:' || sqlcode || sqlerrm;
          update ordershipping
             set gen_erp_order_flag = x_msg, lastmodifieddate = sysdate
           where milk_station_id =
                 (select header_id
                    from milk_station_line
                   where id = v_order.milk_station_id)
             and trunc(v_order.order_date) = trunc(shipping_date);
      end;
      commit;
    end loop;
  
    x_code := 'S';
    x_msg  := '生成成功';
  
  EXCEPTION
    WHEN OTHERS THEN
      x_code := 'E';
      x_msg  := '生成失败:' || sqlcode || sqlerrm;
  end gen_erp_order;

  /*获得传送到ERP的价格，如果配送日期是最后一天的话，价格就是
  总价格减去已经配送的价格除以最后一天配送数量，如果不是最后一天，
  价格就取订单行上的价格,不做了*/
  function getErpPrice(p_date             varchar2,
                       cp_milk_station_id number,
                       cp_order_from      varchar2,
                       product_id         number) return number is
    l_price number(10, 7) := 0; --返回的价格
  begin
    SELECT round(avg(rec.price), 7)
      INTO l_price
      FROM (SELECT (CASE
                     WHEN judge_final_date(p_date,
                                           cp_milk_station_id,
                                           cp_order_from,
                                           product_id,
                                           odi.id) = 'Y' THEN
                      get_final_price(p_date,
                                      cp_milk_station_id,
                                      cp_order_from,
                                      product_id,
                                      odi.id)
                     ELSE
                      odi.price
                   END) price
              FROM ORDERSHIPPING     os,
                   ORDERS            od,
                   ORDERSHIPPINGITEM osi,
                   ORDERITEM         odi,
                   PRODUCT           pd,
                   FND_LOOKUP_VALUES flv
             WHERE 1 = 1
               AND os.ORDERS = od.id
               AND os.ID = osi.ORDERSHIPPING_ID
               AND flv.lookup_code = od.order_from
               AND flv.lookup_type = 'ORDER_FROM'
               AND osi.SN = pd.SN
               AND osi.orderitemid = odi.id
               AND od.ID = odi.ORDERS
               AND pd.id = product_id
               AND trunc(os.SHIPPING_DATE) =
                   trunc(to_date(p_date, 'yyyy-mm-dd'))
               AND flv.attribute1 = cp_order_from
               AND od.milk_station_id =
                   (select header_id
                      from MILK_STATION_LINE
                     where id = cp_milk_station_id)
               AND pd.ERP_ITEM_ID is not null
               and odi.price is not null) rec;
    return l_price;
  end;
  --判断订单行是否是最后一天
  function judge_final_date(p_date             varchar2,
                            cp_milk_station_id number,
                            cp_order_from      varchar2,
                            product_id         number,
                            orderitem          number) return varchar2 is
    l_isfinal_date varchar2(10); --是否是最后一天的标记
  begin
    SELECT (case
             when trunc(odi.order_date_to) =
                  trunc(to_date(p_date, 'yyyy-mm-dd')) then
              'Y'
             else
              'N'
           end) l_isfinal_date_flag
      into l_isfinal_date
      FROM ORDERSHIPPING     os,
           ORDERS            od,
           ORDERSHIPPINGITEM osi,
           ORDERITEM         odi,
           PRODUCT           pd,
           FND_LOOKUP_VALUES flv
     WHERE 1 = 1
       AND os.ORDERS = od.id
       AND os.ID = osi.ORDERSHIPPING_ID
       AND flv.lookup_code = od.order_from
       AND flv.lookup_type = 'ORDER_FROM'
       AND osi.SN = pd.SN
       AND osi.orderitemid = odi.id
       AND od.ID = odi.ORDERS
       AND pd.id = product_id
       AND odi.id = orderitem
       AND trunc(os.SHIPPING_DATE) = trunc(to_date(p_date, 'yyyy-mm-dd'))
       AND flv.attribute1 = cp_order_from
       AND od.milk_station_id =
           (select header_id
              from MILK_STATION_LINE
             where id = cp_milk_station_id)
       AND pd.ERP_ITEM_ID is not null
       and odi.price is not null;
    return l_isfinal_date;
  end;

  --获得订单行最后一天的价格
  function get_final_price(p_date             varchar2,
                           cp_milk_station_id number,
                           cp_order_from      varchar2,
                           product_id         number,
                           orderitem          number) return number is
    l_final_price     number(10, 7); --最后一天的价格
    l_before_quantity number(10, 7); --除去最后一天的数量
  begin
    l_before_quantity := get_befroe_quantity(p_date,
                                             cp_milk_station_id,
                                             cp_order_from,
                                             product_id,
                                             orderitem);
    SELECT round((odi.totalprice - l_before_quantity * odi.price) /
                 sum(osi.quantity),
                 7)
      into l_final_price
      FROM ORDERSHIPPING     os,
           ORDERS            od,
           ORDERSHIPPINGITEM osi,
           ORDERITEM         odi,
           PRODUCT           pd,
           FND_LOOKUP_VALUES flv
     WHERE 1 = 1
       AND os.ORDERS = od.id
       AND trunc(odi.order_date_to) = trunc(to_date(p_date, 'yyyy-mm-dd'))
       AND os.ID = osi.ORDERSHIPPING_ID
       AND flv.lookup_code = od.order_from
       AND flv.lookup_type = 'ORDER_FROM'
       AND osi.SN = pd.SN
       AND osi.orderitemid = odi.id
       AND od.ID = odi.ORDERS
       AND pd.id = product_id
       AND odi.id = orderitem
       AND trunc(os.SHIPPING_DATE) = trunc(to_date(p_date, 'yyyy-mm-dd'))
       AND flv.attribute1 = cp_order_from
       AND od.milk_station_id =
           (select header_id
              from MILK_STATION_LINE
             where id = cp_milk_station_id)
       AND pd.ERP_ITEM_ID is not null
       and odi.price is not null;
    return l_final_price;
  end;

  --获得订单行不是最后一天的数量
  function get_befroe_quantity(p_date             varchar2,
                               cp_milk_station_id number,
                               cp_order_from      varchar2,
                               product_id         number,
                               orderitem          number) return number is
    l_befroe_quantity number; --不是最后一天的总数量
  begin
    SELECT sum(osi.quantity)
      into l_befroe_quantity
      FROM ORDERSHIPPING     os,
           ORDERS            od,
           ORDERSHIPPINGITEM osi,
           ORDERITEM         odi,
           PRODUCT           pd,
           FND_LOOKUP_VALUES flv
     WHERE 1 = 1
       AND os.ORDERS = od.id
       AND trunc(odi.order_date_to) <> trunc(to_date(p_date, 'yyyy-mm-dd'))
       AND os.ID = osi.ORDERSHIPPING_ID
       AND flv.lookup_code = od.order_from
       AND flv.lookup_type = 'ORDER_FROM'
       AND osi.SN = pd.SN
       AND osi.orderitemid = odi.id
       AND od.ID = odi.ORDERS
       AND pd.id = product_id
       AND odi.id = orderitem
       AND trunc(os.SHIPPING_DATE) = trunc(to_date(p_date, 'yyyy-mm-dd'))
       AND flv.attribute1 = cp_order_from
       AND od.milk_station_id =
           (select header_id
              from MILK_STATION_LINE
             where id = cp_milk_station_id)
       AND pd.ERP_ITEM_ID is not null
       and odi.price is not null;
    return l_befroe_quantity;
  end;

  --判断配送员批量暂停区间标识
  function judge_pause_flag(p_ms_courier_id number, p_order_id number)
    return varchar2 is
    PRAGMA AUTONOMOUS_TRANSACTION;
    v_flag            varchar2(10); -- varchar2(10) default 'N';
    v_cnt             number;
    l_order_date_from date;
    l_order_date_to   date;
    l_orderitem_id    number;
    x_code            varchar2(10);
    x_msg             varchar2(120);
    cursor cur_mc_pause is
      select *
        from mscourier_batch_pause mbp
       where mbp.ms_courier_id = p_ms_courier_id;
  begin
    select count(*)
      into v_cnt
      from mscourier_batch_pause mbp
     where mbp.ms_courier_id = p_ms_courier_id
       and mbp.delete_status is null;
    if v_cnt = 0 then
      v_flag := 'Y';
    else
      for v_mc_pause in cur_mc_pause loop
        --获取配送员批量暂停区间
        /*select mbp.pause_date_from, mbp.recovery_date
         into l_mc_pause_from, l_mc_recover_date
         from mscourier_batch_pause mbp
        where mbp.ms_courier_id = p_ms_courier_id;*/
        --获取订单行暂停区间
        select oi.order_date_from, oi.order_date_to, oi.id
          into l_order_date_from, l_order_date_to, l_orderitem_id
          from orders o, orderitem oi
         where o.id = oi.orders
           and o.id = p_order_id;
      
        /* if (v_mc_pause.pause_date_from >= l_order_date_from and
        v_mc_pause.pause_date_from <= l_order_date_to) or
        (v_mc_pause.recovery_date >= l_order_date_from and
        v_mc_pause.recovery_date <= l_order_date_to) then*/
        if v_mc_pause.pause_date_from >= l_order_date_from and
           v_mc_pause.recovery_date < l_order_date_to then
          insert into order_pause_interval
            (id,
             createddate,
             lastmodifieddate,
             version,
             created_by,
             last_updated_by,
             orderitem_id,
             pause_status,
             quantity,
             pause_date_from,
             recovery_date,
             pause_reason,
             pause_from)
          values
            (get_primary_id('order_pause_interval'),
             sysdate,
             sysdate,
             1,
             -1,
             -1,
             l_orderitem_id,
             'Y',
             0,
             v_mc_pause.pause_date_from,
             v_mc_pause.recovery_date,
             v_mc_pause.pause_reason,
             'CRM');
          COMMIT;
          v_flag := 'N';
          --return v_flag;
        elsif v_mc_pause.pause_date_from >= l_order_date_from and
              v_mc_pause.recovery_date <= l_order_date_to and
              v_mc_pause.recovery_date > l_order_date_to then
          insert into order_pause_interval
            (id,
             createddate,
             lastmodifieddate,
             version,
             created_by,
             last_updated_by,
             orderitem_id,
             pause_status,
             quantity,
             pause_date_from,
             recovery_date,
             pause_reason,
             pause_from)
          values
            (get_primary_id('order_pause_interval'),
             sysdate,
             sysdate,
             1,
             -1,
             -1,
             l_orderitem_id,
             'Y',
             0,
             v_mc_pause.pause_date_from,
             l_order_date_to,
             v_mc_pause.pause_reason,
             'CRM');
          COMMIT;
          v_flag := 'N';
        elsif v_mc_pause.pause_date_from < l_order_date_from and
              v_mc_pause.recovery_date >= l_order_date_from and
              v_mc_pause.recovery_date <= l_order_date_to then
          insert into order_pause_interval
            (id,
             createddate,
             lastmodifieddate,
             version,
             created_by,
             last_updated_by,
             orderitem_id,
             pause_status,
             quantity,
             pause_date_from,
             recovery_date,
             pause_reason,
             pause_from)
          values
            (get_primary_id('order_pause_interval'),
             sysdate,
             sysdate,
             1,
             -1,
             -1,
             l_orderitem_id,
             'Y',
             0,
             l_order_date_from,
             v_mc_pause.recovery_date,
             v_mc_pause.pause_reason,
             'CRM');
          COMMIT;
          v_flag := 'N';
        end if;
        v_flag := nvl(v_flag, 'Y');
      end loop;
    end if;
    return v_flag;
  exception
    when others then
      x_code := 'E';
      x_msg  := '错误信息:' || sqlcode || sqlerrm;
      dbms_output.put_line(x_code);
      dbms_output.put_line(x_msg);
  end;

  PROCEDURE IMPORT_BATCH_PAUSE(P_MSCOURIER_ID    IN VARCHAR2,
                               p_milk_station_id IN VARCHAR2,
                               P_PAUSE_REASON    IN VARCHAR2,
                               P_PAUSE_FROM      IN VARCHAR2,
                               P_RECOVERY_DATE   IN VARCHAR2,
                               P_CREATED_BY      IN VARCHAR2,
                               P_BATCHPAUSE_ID   OUT NUMBER,
                               P_FLAG            OUT VARCHAR2,
                               P_MSG             OUT VARCHAR2) IS
    CURSOR CUR_ORDER_PAUSE IS
    --2019年1月7日 将批量暂停修改为 CRM只负责CRM订单的延期，微商城订单通过接口推送
      SELECT OI.ID,
             OI.SHIPPING_TYPE,
             OI.ORDER_DATE_FROM,
             OI.ORDER_DATE_TO,
             OS.MS_COURIER_ID,
             OI.DAILY_DELIVERY_QUANTITY,
             OI.ORDER_DAYS
        FROM ORDERS OS, ORDERITEM OI
       WHERE OS.ID = OI.ORDERS
            --  将微商城订单排除
         and os.order_from <> 'WECHAT'
         AND decode(P_MSCOURIER_ID, -1, -1, OS.MS_COURIER_ID) =
             P_MSCOURIER_ID
         AND nvl2(p_milk_station_id, os.milk_station_id, 1) =
             nvl2(p_milk_station_id, p_milk_station_id, 1)
         AND ((OI.ORDER_DATE_FROM BETWEEN
             TO_DATE(P_PAUSE_FROM, 'yyyy-MM-dd') AND
             TO_DATE(P_RECOVERY_DATE, 'yyyy-MM-dd')) OR
             (OI.ORDER_DATE_TO BETWEEN TO_DATE(P_PAUSE_FROM, 'yyyy-MM-dd') AND
             TO_DATE(P_RECOVERY_DATE, 'yyyy-MM-dd')) OR
             (OI.ORDER_DATE_FROM <= TO_DATE(P_PAUSE_FROM, 'yyyy-MM-dd') AND
             OI.ORDER_DATE_TO > TO_DATE(P_RECOVERY_DATE, 'yyyy-MM-dd')));
    VAR_ORDER_PAUSE       CUR_ORDER_PAUSE%ROWTYPE;
    VAR_PAUSE_CNT         NUMBER;
    VAR_PAUSE_FROM        DATE := TO_DATE(P_PAUSE_FROM, 'yyyy-MM-dd');
    VAR_RECOVERY_DATE     DATE := TO_DATE(P_RECOVERY_DATE, 'yyyy-MM-dd');
    VAR_NEW_ORDER_DATE_TO DATE;
    VAR_BATCH_PAUSE_ID    NUMBER; --本次操作的批量暂停ID
    VAR_MILKSTATION_ID    NUMBER; --配送员所属奶站ID
    VAR_NUM               NUMBER := 0;
    VAR_ACT_PAUSE_CNT     NUMBER; --计算改日期是否存在于暂停区间内 大于0则标识有暂停（包括普通、批量、奶站APP等等）
    VAR_HOLIDAY_CNT       NUMBER; --是否是节假日
    VAR_SPRING_CNT        NUMBER;
    VAR_WEEK              VARCHAR2(20);
    VAR_ACT_PAUSE_FROM    DATE; --订单展示实际暂停起始日期
    VAR_CRM_PAUSE_RE_DATE VARCHAR2(20);
  BEGIN
    --判断本次插入的批量暂停是否和该配送员已有批量暂停重叠
    IF P_MSCOURIER_ID = -1 THEN
      VAR_PAUSE_CNT      := 0;
      VAR_MILKSTATION_ID := p_milk_station_id;
    ELSE
      SELECT COUNT(1)
        INTO VAR_PAUSE_CNT
        FROM MSCOURIER_BATCH_PAUSE MBP
       WHERE MBP.MS_COURIER_ID = P_MSCOURIER_ID
         AND ((MBP.PAUSE_DATE_FROM BETWEEN VAR_PAUSE_FROM AND
             VAR_RECOVERY_DATE) OR (MBP.RECOVERY_DATE BETWEEN
             VAR_PAUSE_FROM AND VAR_RECOVERY_DATE));
    
      SELECT MC.MILK_STATION_ID
        INTO VAR_MILKSTATION_ID
        FROM MS_COURIER MC
       WHERE MC.ID = P_MSCOURIER_ID;
    END IF;
  
    IF VAR_PAUSE_CNT = 0 THEN
      --插入批量暂停表
      VAR_BATCH_PAUSE_ID := get_primary_id('MSCOURIER_BATCH_PAUSE');
    
      INSERT INTO MSCOURIER_BATCH_PAUSE
        (ID,
         MS_COURIER_ID,
         PAUSE_DATE_FROM,
         RECOVERY_DATE,
         PAUSE_REASON,
         PAUSE_STATUS,
         CREATEDDATE,
         LASTMODIFIEDDATE,
         CREATED_BY,
         LAST_UPDATED_BY,
         VERSION,
         DELETE_STATUS,
         MILK_STATION_ID)
      VALUES
        (VAR_BATCH_PAUSE_ID,
         P_MSCOURIER_ID,
         VAR_PAUSE_FROM,
         VAR_RECOVERY_DATE,
         P_PAUSE_REASON,
         'Y',
         SYSDATE,
         SYSDATE,
         P_CREATED_BY,
         P_CREATED_BY,
         1,
         '',
         VAR_MILKSTATION_ID);
      P_BATCHPAUSE_ID := VAR_BATCH_PAUSE_ID;
      --DBMS_OUTPUT.put_line('=====插入配送员暂停成功=======' || VAR_NUM);
      COMMIT;
      FOR VAR_ORDER_PAUSE IN CUR_ORDER_PAUSE LOOP
        BEGIN
          --插入ORDER_PAUSE_INTERVAL表
          IF VAR_PAUSE_FROM <= VAR_ORDER_PAUSE.ORDER_DATE_FROM THEN
            VAR_ACT_PAUSE_FROM := VAR_ORDER_PAUSE.ORDER_DATE_FROM;
          ELSE
            VAR_ACT_PAUSE_FROM := VAR_PAUSE_FROM;
          END IF;
          INSERT INTO ORDER_PAUSE_INTERVAL
            (ID,
             CREATEDDATE,
             LASTMODIFIEDDATE,
             VERSION,
             CREATED_BY,
             LAST_UPDATED_BY,
             ORDERITEM_ID,
             PAUSE_STATUS,
             QUANTITY,
             PAUSE_INDEX,
             PAUSE_DATE_FROM,
             RECOVERY_DATE,
             IS_EXPIRY_DATE_FLAG,
             PAUSE_REASON,
             PAUSE_FROM,
             BATCH_PAUSE_ID)
          VALUES
            (get_primary_id('ORDER_PAUSE_INTERVAL'),
             SYSDATE,
             SYSDATE,
             1,
             P_CREATED_BY,
             P_CREATED_BY,
             VAR_ORDER_PAUSE.ID,
             'Y',
             VAR_ORDER_PAUSE.DAILY_DELIVERY_QUANTITY,
             1,
             VAR_ACT_PAUSE_FROM,
             VAR_RECOVERY_DATE,
             '',
             P_PAUSE_REASON,
             'CRM_BATCH_PAUSE',
             VAR_BATCH_PAUSE_ID);
          --  DBMS_OUTPUT.put_line('=====插入暂停成功=======' || VAR_NUM);
          --日期顺延计算
          IF VAR_ORDER_PAUSE.ORDER_DAYS IS NOT NULL THEN
            -- DBMS_OUTPUT.put_line('=====开始计算日期顺延=======' || VAR_NUM);
            IF VAR_ORDER_PAUSE.SHIPPING_TYPE = 0 THEN
              --VAR_NUM := 0;
              --  DBMS_OUTPUT.put_line('=====每日配送=======' ||
              --                 VAR_ORDER_PAUSE.ID);
              VAR_NEW_ORDER_DATE_TO := VAR_ORDER_PAUSE.ORDER_DATE_FROM;
              WHILE VAR_NUM <= VAR_ORDER_PAUSE.ORDER_DAYS LOOP
                -- DBMS_OUTPUT.put_line('=====每日配送=======' || VAR_NUM|| VAR_NEW_ORDER_DATE_TO);
                --从起始配送日期开始判断每一天是否是暂停内 不是则实际配送加一天
                SELECT COUNT(1)
                  INTO VAR_ACT_PAUSE_CNT
                  FROM ORDER_PAUSE_INTERVAL OPI
                 WHERE OPI.ORDERITEM_ID = VAR_ORDER_PAUSE.ID
                   AND VAR_NEW_ORDER_DATE_TO >= OPI.PAUSE_DATE_FROM
                   AND VAR_NEW_ORDER_DATE_TO < OPI.RECOVERY_DATE;
                --判断是否是过年期间
                SELECT COUNT(1)
                  INTO VAR_SPRING_CNT
                  FROM HOLIDAY HO
                 WHERE HO.HOLIDAY_DATE = VAR_NEW_ORDER_DATE_TO
                   AND HO.SPRING_FESTIVAL_FLAG = 'Y';
                IF VAR_ACT_PAUSE_CNT = 0 AND VAR_SPRING_CNT = 0 THEN
                  VAR_NUM := VAR_NUM + 1;
                ELSE
                  --判断普通暂停是否有终止日期 防止死循环
                  SELECT OPI.RECOVERY_DATE
                    INTO VAR_CRM_PAUSE_RE_DATE
                    FROM ORDER_PAUSE_INTERVAL OPI
                   WHERE OPI.ORDERITEM_ID = VAR_ORDER_PAUSE.ID
                     AND VAR_NEW_ORDER_DATE_TO >= OPI.PAUSE_DATE_FROM
                     AND VAR_NEW_ORDER_DATE_TO < OPI.RECOVERY_DATE;
                  IF VAR_CRM_PAUSE_RE_DATE = '' OR
                     VAR_CRM_PAUSE_RE_DATE IS NULL THEN
                    VAR_NEW_ORDER_DATE_TO := '';
                    EXIT;
                  END IF;
                END IF;
                IF VAR_NUM < VAR_ORDER_PAUSE.ORDER_DAYS THEN
                  VAR_NEW_ORDER_DATE_TO := VAR_NEW_ORDER_DATE_TO + 1;
                END IF;
              END LOOP;
              VAR_NUM := 0;
              UPDATE ORDERITEM OI
                 SET OI.ORDER_DATE_TO    = VAR_NEW_ORDER_DATE_TO,
                     OI.LAST_UPDATED_BY  = P_CREATED_BY,
                     OI.LASTMODIFIEDDATE = SYSDATE
               WHERE OI.ID = VAR_ORDER_PAUSE.ID;
              P_FLAG := 'Y';
            ELSIF VAR_ORDER_PAUSE.SHIPPING_TYPE = 1 THEN
              --计算每一天是否为工作日 或者 是否存在于暂停区间
              --VAR_NUM := 0;
              --DBMS_OUTPUT.put_line('=====工作日配送=======' || VAR_ORDER_PAUSE.ID);
              VAR_NEW_ORDER_DATE_TO := VAR_ORDER_PAUSE.ORDER_DATE_FROM;
              WHILE VAR_NUM < VAR_ORDER_PAUSE.ORDER_DAYS LOOP
                --DBMS_OUTPUT.put_line('=====工作日配送=======' || VAR_NUM || VAR_NEW_ORDER_DATE_TO);
                SELECT COUNT(1)
                  INTO VAR_ACT_PAUSE_CNT
                  FROM ORDER_PAUSE_INTERVAL OPI
                 WHERE OPI.ORDERITEM_ID = VAR_ORDER_PAUSE.ID
                   AND VAR_NEW_ORDER_DATE_TO >= OPI.PAUSE_DATE_FROM
                   AND VAR_NEW_ORDER_DATE_TO < OPI.RECOVERY_DATE;
                IF VAR_ACT_PAUSE_CNT = 0 THEN
                  --判断是否是周末或者节假日
                  SELECT COUNT(1)
                    INTO VAR_HOLIDAY_CNT
                    FROM HOLIDAY H
                   WHERE H.HOLIDAY_DATE = VAR_NEW_ORDER_DATE_TO;
                
                  SELECT TO_CHAR(VAR_NEW_ORDER_DATE_TO, 'DAY')
                    INTO VAR_WEEK
                    FROM DUAL;
                  --DBMS_OUTPUT.put_line('=====工作日配送=======' || VAR_HOLIDAY_CNT || VAR_WEEK);
                  IF VAR_HOLIDAY_CNT = 0 AND VAR_WEEK <> '星期六' AND
                     VAR_WEEK <> '星期日' THEN
                    VAR_NUM := VAR_NUM + 1;
                  END IF;
                  --  DBMS_OUTPUT.put_line(VAR_NUM || VAR_HOLIDAY_CNT ||
                  -- VAR_WEEK || VAR_NEW_ORDER_DATE_TO);
                ELSE
                  --判断普通暂停是否有终止日期 防止死循环
                  SELECT OPI.RECOVERY_DATE
                    INTO VAR_CRM_PAUSE_RE_DATE
                    FROM ORDER_PAUSE_INTERVAL OPI
                   WHERE OPI.ORDERITEM_ID = VAR_ORDER_PAUSE.ID
                     AND VAR_NEW_ORDER_DATE_TO >= OPI.PAUSE_DATE_FROM
                     AND VAR_NEW_ORDER_DATE_TO < OPI.RECOVERY_DATE;
                  IF VAR_CRM_PAUSE_RE_DATE = '' OR
                     VAR_CRM_PAUSE_RE_DATE IS NULL THEN
                    VAR_NEW_ORDER_DATE_TO := '';
                    EXIT;
                  END IF;
                END IF;
                IF VAR_NUM < VAR_ORDER_PAUSE.ORDER_DAYS THEN
                  VAR_NEW_ORDER_DATE_TO := VAR_NEW_ORDER_DATE_TO + 1;
                END IF;
              END LOOP;
              VAR_NUM := 0;
              UPDATE ORDERITEM OI
                 SET OI.ORDER_DATE_TO    = VAR_NEW_ORDER_DATE_TO,
                     OI.LAST_UPDATED_BY  = P_CREATED_BY,
                     OI.LASTMODIFIEDDATE = SYSDATE
               WHERE OI.ID = VAR_ORDER_PAUSE.ID;
              P_FLAG := 'Y';
            END IF;
          END IF;
        EXCEPTION
          WHEN OTHERS THEN
            P_FLAG := 'N';
            P_MSG  := '错误信息：' || SQLERRM;
        END;
        COMMIT;
      END LOOP;
      P_FLAG := 'Y';
    ELSE
      P_FLAG := 'E';
      P_MSG  := '该配送员已有重叠的暂停区间！';
    END IF;
  EXCEPTION
    WHEN OTHERS THEN
      P_FLAG := 'N';
      P_MSG  := '错误信息：' || SQLERRM;
  END;

  PROCEDURE DELETE_BATCH_PAUSE(P_BATCH_PAUSE_ID IN VARCHAR2,
                               P_FLAG           OUT VARCHAR2,
                               P_MSG            OUT VARCHAR2) IS
    CURSOR CUR_BATCH_PAUSE IS
      SELECT *
        FROM ORDER_PAUSE_INTERVAL OPI
       WHERE OPI.BATCH_PAUSE_ID = P_BATCH_PAUSE_ID;
    VAR_BATCH_PAUSE       CUR_BATCH_PAUSE%ROWTYPE;
    VAR_ORDER_FROM        DATE;
    VAR_ORDER_DAYS        NUMBER;
    VAR_SHIPPING_TYPE     NUMBER;
    VAR_NEW_ORDER_DATE_TO DATE;
    VAR_NUM               NUMBER := 0;
    VAR_ACT_PAUSE_CNT     NUMBER;
    VAR_HOLIDAY_CNT       NUMBER;
    VAR_WEEK              VARCHAR2(20);
    VAR_SPRING_CNT        NUMBER;
  BEGIN
    --恢复订单终止日期
    FOR VAR_BATCH_PAUSE IN CUR_BATCH_PAUSE LOOP
      BEGIN
        SELECT OI.ORDER_DATE_FROM, OI.ORDER_DAYS, OI.SHIPPING_TYPE
          INTO VAR_ORDER_FROM, VAR_ORDER_DAYS, VAR_SHIPPING_TYPE
          FROM ORDERITEM OI
         WHERE OI.ID = VAR_BATCH_PAUSE.ORDERITEM_ID;
      EXCEPTION
        WHEN OTHERS THEN
          P_FLAG := 'E';
          P_MSG  := '错误信息：' || SQLERRM;
      END;
      IF VAR_SHIPPING_TYPE = 0 THEN
        VAR_NEW_ORDER_DATE_TO := VAR_ORDER_FROM;
        WHILE VAR_NUM <= VAR_ORDER_DAYS LOOP
          --从起始配送日期开始判断每一天是否是暂停内 不是则实际配送加一天
          --DBMS_OUTPUT.put_line(0||'=='||VAR_NEW_ORDER_DATE_TO||'=='|| VAR_NUM);
          SELECT COUNT(1)
            INTO VAR_ACT_PAUSE_CNT
            FROM ORDER_PAUSE_INTERVAL OPI
           WHERE OPI.ORDERITEM_ID = VAR_BATCH_PAUSE.ORDERITEM_ID
             AND VAR_NEW_ORDER_DATE_TO >= OPI.PAUSE_DATE_FROM
             AND VAR_NEW_ORDER_DATE_TO < OPI.RECOVERY_DATE
             AND (OPI.BATCH_PAUSE_ID <> P_BATCH_PAUSE_ID OR
                 OPI.BATCH_PAUSE_ID IS NULL); --将要删除的批量暂停排除
          --判断是否是过年期间
          SELECT COUNT(1)
            INTO VAR_SPRING_CNT
            FROM HOLIDAY HO
           WHERE HO.HOLIDAY_DATE = VAR_NEW_ORDER_DATE_TO
             AND HO.SPRING_FESTIVAL_FLAG = 'Y';
          IF VAR_ACT_PAUSE_CNT = 0 AND VAR_SPRING_CNT = 0 THEN
            VAR_NUM := VAR_NUM + 1;
          END IF;
          --  DBMS_OUTPUT.put_line(0||'=='||VAR_NEW_ORDER_DATE_TO||'=='|| VAR_NUM);
          IF VAR_NUM < VAR_ORDER_DAYS THEN
            VAR_NEW_ORDER_DATE_TO := VAR_NEW_ORDER_DATE_TO + 1;
          END IF;
        END LOOP;
        VAR_NUM := 0;
      ELSIF VAR_SHIPPING_TYPE = 1 THEN
        VAR_NEW_ORDER_DATE_TO := VAR_ORDER_FROM;
        WHILE VAR_NUM <= VAR_ORDER_DAYS LOOP
          SELECT COUNT(1)
            INTO VAR_ACT_PAUSE_CNT
            FROM ORDER_PAUSE_INTERVAL OPI
           WHERE OPI.ORDERITEM_ID = VAR_BATCH_PAUSE.ORDERITEM_ID
             AND VAR_NEW_ORDER_DATE_TO >= OPI.PAUSE_DATE_FROM
             AND VAR_NEW_ORDER_DATE_TO < OPI.RECOVERY_DATE
             AND (OPI.BATCH_PAUSE_ID <> P_BATCH_PAUSE_ID OR
                 OPI.BATCH_PAUSE_ID IS NULL); --将要删除的批量暂停排除
          IF VAR_ACT_PAUSE_CNT = 0 THEN
            --判断是否是周末或者节假日
            SELECT COUNT(1)
              INTO VAR_HOLIDAY_CNT
              FROM HOLIDAY H
             WHERE H.HOLIDAY_DATE = VAR_NEW_ORDER_DATE_TO;
          
            SELECT TO_CHAR(VAR_NEW_ORDER_DATE_TO, 'DAY')
              INTO VAR_WEEK
              FROM DUAL;
            IF VAR_HOLIDAY_CNT = 0 AND VAR_WEEK <> '星期六' AND
               VAR_WEEK <> '星期日' THEN
              VAR_NUM := VAR_NUM + 1;
            END IF;
          END IF;
          --DBMS_OUTPUT.put_line(1||'=='||VAR_NEW_ORDER_DATE_TO||'=='|| VAR_NUM);
          IF VAR_NUM < VAR_ORDER_DAYS THEN
            VAR_NEW_ORDER_DATE_TO := VAR_NEW_ORDER_DATE_TO + 1;
          END IF;
        END LOOP;
        VAR_NUM := 0;
      END IF;
    
      UPDATE ORDERITEM OI
         SET OI.ORDER_DATE_TO    = VAR_NEW_ORDER_DATE_TO,
             OI.LASTMODIFIEDDATE = SYSDATE
       WHERE OI.ID = VAR_BATCH_PAUSE.ORDERITEM_ID;
      COMMIT;
    END LOOP;
    --删除暂停
    DELETE FROM ORDER_PAUSE_INTERVAL OPI
     WHERE OPI.BATCH_PAUSE_ID = P_BATCH_PAUSE_ID;
    DELETE FROM MSCOURIER_BATCH_PAUSE MBP WHERE MBP.ID = P_BATCH_PAUSE_ID;
    COMMIT;
    P_FLAG := 'Y';
  EXCEPTION
    WHEN OTHERS THEN
      P_FLAG := 'N';
      P_MSG  := '错误信息：' || SQLERRM;
  END;

  PROCEDURE UPDATE_BATCH_PAUSE(P_BATCH_PAUSE_ID  IN VARCHAR2,
                               P_MSCOURIER_ID    IN VARCHAR2,
                               p_milk_station_id IN VARCHAR2,
                               P_PAUSE_REASON    IN VARCHAR2,
                               P_PAUSE_FROM      IN VARCHAR2,
                               P_RECOVERY_DATE   IN VARCHAR2,
                               P_CREATED_BY      IN VARCHAR2,
                               P_FLAG            OUT VARCHAR2,
                               P_MSG             OUT VARCHAR2) IS
    var_batch number;
  BEGIN
    DELETE_BATCH_PAUSE(P_BATCH_PAUSE_ID, P_FLAG, P_MSG);
    IF P_FLAG = 'Y' THEN
      IMPORT_BATCH_PAUSE(P_MSCOURIER_ID,
                         p_milk_station_id,
                         P_PAUSE_REASON,
                         P_PAUSE_FROM,
                         P_RECOVERY_DATE,
                         P_CREATED_BY,
                         var_batch,
                         P_FLAG,
                         P_MSG);
    ELSE
      P_FLAG := 'N';
      P_MSG  := '错误信息：删除出错' || P_MSG;
    END IF;
  EXCEPTION
    WHEN OTHERS THEN
      P_FLAG := 'N';
      P_MSG  := '错误信息：' || SQLERRM;
  END;

  --更换订单行配送类型
  PROCEDURE CHANGE_SHIPPING_TYPE(P_ORDERITEM_ID  IN VARCHAR2,
                                 P_CHANGE_DATE   IN VARCHAR2,
                                 P_SHIPPING_TYPE IN NUMBER,
                                 P_ORI_SHIP_TYPE IN NUMBER,
                                 P_CREATED_BY    IN NUMBER,
                                 P_FLAG          OUT VARCHAR2,
                                 P_MSG           OUT VARCHAR2) IS
    CURSOR CUR_ORDERITEM IS
      SELECT * FROM ORDERITEM OI WHERE OI.ID = P_ORDERITEM_ID;
    CURSOR CUR_PAUSE IS
      SELECT *
        FROM ORDER_PAUSE_INTERVAL OPI
       WHERE OPI.ORDERITEM_ID = P_ORDERITEM_ID
         AND OPI.PAUSE_DATE_FROM >= TO_DATE(P_CHANGE_DATE, 'yyyy-MM-dd')
       ORDER BY OPI.PAUSE_DATE_FROM ASC;
    VAR_ORDERITEM        CUR_ORDERITEM%ROWTYPE;
    VAR_PAUSE            CUR_PAUSE%ROWTYPE;
    VAR_CHANGE_DATE      DATE := TO_DATE(P_CHANGE_DATE, 'yyyy-MM-dd');
    VAR_ORDER_FROM       DATE;
    VAR_ORDER_TO         DATE;
    VAR_DAYS             NUMBER;
    VAR_ALREADY_DAYS     NUMBER := 0;
    VAR_PAUSE_CNT        NUMBER;
    VAR_HOLIDAY_CNT      NUMBER;
    VAR_WEEK             VARCHAR2(20);
    VAR_CONTINUE_DAYS    NUMBER;
    VAR_NUM              NUMBER := 0;
    VAR_NEW_PAUSE_CNT    NUMBER;
    VAR_NEW_DATE_TO      DATE;
    VAR_NEW_ORDERITEM_ID NUMBER;
    VAR_MAX_LINE_COUNT   NUMBER;
  BEGIN
    SELECT OI.ORDER_DATE_FROM, OI.ORDER_DATE_TO, OI.ORDER_DAYS
      INTO VAR_ORDER_FROM, VAR_ORDER_TO, VAR_DAYS
      FROM ORDERITEM OI
     WHERE OI.ID = P_ORDERITEM_ID;
    --计算从起始 到更换日期前一天 按照原配送类型共配送几天
    IF P_ORI_SHIP_TYPE = 0 THEN
      --VAR_ALREADY_DAYS := VAR_CHANGE_DATE - VAR_ORDER_FROM;
      --判断每一天是否在暂停区间内
      WHILE VAR_ORDER_FROM < VAR_CHANGE_DATE LOOP
        SELECT COUNT(1)
          INTO VAR_PAUSE_CNT
          FROM ORDER_PAUSE_INTERVAL OPI
         WHERE OPI.ORDERITEM_ID = P_ORDERITEM_ID
           AND VAR_ORDER_FROM >= OPI.PAUSE_DATE_FROM
           AND VAR_ORDER_FROM < OPI.RECOVERY_DATE;
        IF VAR_PAUSE_CNT = 0 THEN
          VAR_ALREADY_DAYS := VAR_ALREADY_DAYS + 1;
        END IF;
        VAR_ORDER_FROM := VAR_ORDER_FROM + 1;
      END LOOP;
    ELSIF P_ORI_SHIP_TYPE = 1 THEN
      WHILE VAR_ORDER_FROM < VAR_CHANGE_DATE LOOP
        --判断每一天是否在暂停区间内 是否是周末、节假日
        SELECT COUNT(1)
          INTO VAR_PAUSE_CNT
          FROM ORDER_PAUSE_INTERVAL OPI
         WHERE OPI.ORDERITEM_ID = P_ORDERITEM_ID
           AND VAR_ORDER_FROM >= OPI.PAUSE_DATE_FROM
           AND VAR_ORDER_FROM < OPI.RECOVERY_DATE;
        IF VAR_PAUSE_CNT = 0 THEN
          SELECT COUNT(1)
            INTO VAR_HOLIDAY_CNT
            FROM HOLIDAY HO
           WHERE HO.HOLIDAY_DATE = VAR_ORDER_FROM;
          SELECT TO_CHAR(VAR_ORDER_FROM, 'DAY') INTO VAR_WEEK FROM DUAL;
          IF VAR_HOLIDAY_CNT = 0 AND VAR_WEEK <> '星期六' AND
             VAR_WEEK <> '星期日' THEN
            VAR_ALREADY_DAYS := VAR_ALREADY_DAYS + 1;
          END IF;
          VAR_ORDER_FROM := VAR_ORDER_FROM + 1;
        END IF;
      END LOOP;
    END IF;
  
    DBMS_OUTPUT.put_line('ALREADY_DAYS' || VAR_ALREADY_DAYS);
    VAR_CONTINUE_DAYS := VAR_DAYS - VAR_ALREADY_DAYS;
    DBMS_OUTPUT.put_line('VAR_CONTINUE_DAYS' || VAR_CONTINUE_DAYS);
    --计算新订单行的终止日期 起始日期为VAR_CHANGE_DATE
    VAR_NEW_DATE_TO := VAR_CHANGE_DATE;
    WHILE VAR_NUM < VAR_CONTINUE_DAYS LOOP
      IF P_SHIPPING_TYPE = 0 THEN
        DBMS_OUTPUT.put_line('每日配送' || VAR_NEW_DATE_TO || '实际配送天数' ||
                             VAR_NUM);
        --判断每一天是否在原始暂停区间内
        SELECT COUNT(1)
          INTO VAR_NEW_PAUSE_CNT
          FROM ORDER_PAUSE_INTERVAL OPI
         WHERE OPI.ORDERITEM_ID = P_ORDERITEM_ID
           AND VAR_NEW_DATE_TO >= OPI.PAUSE_DATE_FROM
           AND VAR_NEW_DATE_TO < OPI.RECOVERY_DATE;
        IF VAR_NEW_PAUSE_CNT = 0 THEN
          VAR_NUM := VAR_NUM + 1;
        END IF;
        IF VAR_NUM < VAR_CONTINUE_DAYS THEN
          VAR_NEW_DATE_TO := VAR_NEW_DATE_TO + 1;
        END IF;
      
      ELSIF P_SHIPPING_TYPE = 1 THEN
        DBMS_OUTPUT.put_line('工作日配送' || VAR_NEW_DATE_TO || '实际配送天数' ||
                             VAR_NUM);
        SELECT COUNT(1)
          INTO VAR_NEW_PAUSE_CNT
          FROM ORDER_PAUSE_INTERVAL OPI
         WHERE OPI.ORDERITEM_ID = P_ORDERITEM_ID
           AND VAR_NEW_DATE_TO >= OPI.PAUSE_DATE_FROM
           AND VAR_NEW_DATE_TO < OPI.RECOVERY_DATE;
        IF VAR_NEW_PAUSE_CNT = 0 THEN
          --判断是否是节假日 是否是周末
          SELECT COUNT(1)
            INTO VAR_HOLIDAY_CNT
            FROM HOLIDAY HO
           WHERE HO.HOLIDAY_DATE = VAR_NEW_DATE_TO;
        
          SELECT TO_CHAR(VAR_NEW_DATE_TO, 'DAY') INTO VAR_WEEK FROM DUAL;
          IF VAR_HOLIDAY_CNT = 0 AND VAR_WEEK <> '星期六' AND
             VAR_WEEK <> '星期日' THEN
            VAR_NUM := VAR_NUM + 1;
          END IF;
        END IF;
        IF VAR_NUM < VAR_CONTINUE_DAYS THEN
          VAR_NEW_DATE_TO := VAR_NEW_DATE_TO + 1;
        END IF;
      END IF;
    END LOOP;
  
    --判断是否是从第一天开始更换配送类型
    IF VAR_ALREADY_DAYS = 0 THEN
      UPDATE ORDERITEM OI
         SET OI.ORDER_DATE_TO = VAR_NEW_DATE_TO,
             --    OI.ORDER_DAYS       = VAR_ALREADY_DAYS,
             OI.LASTMODIFIEDDATE = SYSDATE,
             OI.LAST_UPDATED_BY  = P_CREATED_BY,
             OI.SHIPPING_TYPE    = P_SHIPPING_TYPE
       WHERE OI.ID = P_ORDERITEM_ID;
      FOR VAR_PAUSE IN CUR_PAUSE LOOP
        IF VAR_NEW_DATE_TO < VAR_PAUSE.PAUSE_DATE_FROM THEN
          --删除暂停区间
          DELETE FROM ORDER_PAUSE_INTERVAL OPI WHERE OPI.ID = VAR_PAUSE.ID;
        END IF;
      END LOOP;
      COMMIT;
      P_FLAG := 'Y';
    ELSE
      --更新原订单行配送终止日期为更换日期前一天 配送天数为VAR_ALREADY_DAYS 金额等于VAR_ALREADY_DAYS*ACT_PRICE
      UPDATE ORDERITEM OI
         SET OI.ORDER_DATE_TO    = VAR_CHANGE_DATE - 1,
             OI.ORDER_DAYS       = VAR_ALREADY_DAYS,
             OI.LASTMODIFIEDDATE = SYSDATE,
             OI.QUANTITY         = VAR_ALREADY_DAYS *
                                   OI.DAILY_DELIVERY_QUANTITY
       WHERE OI.ID = P_ORDERITEM_ID;
      --COMMIT;
      --插入新订单行
      VAR_NEW_ORDERITEM_ID := get_primary_id('ORDERITEM');
    
      FOR VAR_ORDERITEM IN CUR_ORDERITEM LOOP
        SELECT MAX(LINE_COUNT)
          INTO VAR_MAX_LINE_COUNT
          FROM ORDERITEM
         WHERE ORDERS = VAR_ORDERITEM.ORDERS;
        INSERT INTO ORDERITEM
          (id,
           createddate,
           lastmodifieddate,
           version,
           commissiontotals,
           isdelivery,
           name,
           price,
           quantity,
           returnedquantity,
           shippedquantity,
           sn,
           specifications,
           thumbnail,
           type,
           weight,
           orders,
           sku_id,
           created_by,
           last_updated_by,
           order_date_from,
           order_date_to,
           order_days,
           daily_delivery_quantity,
           delivery_days,
           remain_days,
           REFUND_STATUS,
           day_shipping_time,
           shipping_type,
           original_order_date_to,
           product_sn,
           PAY_PRICE,
           present_flag,
           TOTALPRICE,
           LINE_COUNT)
        VALUES
          (VAR_NEW_ORDERITEM_ID,
           SYSDATE,
           SYSDATE,
           1,
           0,
           1,
           VAR_ORDERITEM.NAME,
           VAR_ORDERITEM.PRICE,
           VAR_ORDERITEM.DAILY_DELIVERY_QUANTITY * VAR_CONTINUE_DAYS,
           VAR_ORDERITEM.RETURNEDQUANTITY,
           0,
           VAR_ORDERITEM.SN,
           VAR_ORDERITEM.SPECIFICATIONS,
           VAR_ORDERITEM.THUMBNAIL,
           VAR_ORDERITEM.TYPE,
           0,
           VAR_ORDERITEM.ORDERS,
           VAR_ORDERITEM.SKU_ID,
           P_CREATED_BY,
           P_CREATED_BY,
           VAR_CHANGE_DATE,
           VAR_NEW_DATE_TO,
           VAR_CONTINUE_DAYS,
           VAR_ORDERITEM.Daily_Delivery_Quantity,
           0,
           VAR_CONTINUE_DAYS,
           VAR_ORDERITEM.REFUND_STATUS,
           VAR_ORDERITEM.DAY_SHIPPING_TIME,
           P_SHIPPING_TYPE,
           VAR_NEW_DATE_TO,
           VAR_ORDERITEM.PRODUCT_SN,
           VAR_ORDERITEM.PAY_PRICE,
           VAR_ORDERITEM.PRESENT_FLAG,
           VAR_ORDERITEM.TOTALPRICE,
           VAR_MAX_LINE_COUNT + 1);
        COMMIT;
      END LOOP;
      --循环将暂停update到新订单行
      FOR VAR_PAUSE IN CUR_PAUSE LOOP
        IF VAR_CHANGE_DATE <= VAR_PAUSE.PAUSE_DATE_FROM AND
           VAR_NEW_DATE_TO > VAR_PAUSE.PAUSE_DATE_FROM THEN
          UPDATE ORDER_PAUSE_INTERVAL OPI
             SET OPI.ORDERITEM_ID     = VAR_NEW_ORDERITEM_ID,
                 OPI.LAST_UPDATED_BY  = P_CREATED_BY,
                 OPI.LASTMODIFIEDDATE = SYSDATE
           WHERE OPI.ID = VAR_PAUSE.ID;
          COMMIT;
        END IF;
      END LOOP;
      P_FLAG := 'Y';
    END IF;
  
  EXCEPTION
    WHEN OTHERS THEN
      P_FLAG := 'Y';
      P_MSG  := '错误信息：' || SQLERRM;
  END;

  PROCEDURE GET_REFUND_INFO(P_ORDER_ID      IN VARCHAR2,
                            P_ORDERITEM_ID  IN VARCHAR2,
                            P_REFUND_DATE   IN VARCHAR2,
                            P_REFUND_NUM    OUT NUMBER,
                            P_REFUND_AMOUNT OUT NUMBER,
                            P_ACT_PRICE     OUT NUMBER,
                            P_PRICE         OUT NUMBER,
                            P_FLAG          OUT VARCHAR2,
                            P_MSG           OUT VARCHAR2) IS
    CURSOR CUR_ORDERITEM IS
      SELECT * FROM ORDERITEM OI WHERE OI.ID = P_ORDERITEM_ID;
    VAR_ORDERITEM   CUR_ORDERITEM%ROWTYPE;
    VAR_REFUND_DATE DATE := TO_DATE(P_REFUND_DATE, 'yyyy-MM-dd');
    VAR_NUM         NUMBER := 0;
    VAR_HOLIDAY     NUMBER;
    VAR_WEEK        VARCHAR2(20);
    VAR_PAUSE_CNT   NUMBER;
  BEGIN
    FOR VAR_ORDERITEM IN CUR_ORDERITEM LOOP
      BEGIN
        IF VAR_REFUND_DATE < VAR_ORDERITEM.ORDER_DATE_FROM THEN
          VAR_REFUND_DATE := VAR_ORDERITEM.ORDER_DATE_FROM;
        END IF;
        WHILE VAR_REFUND_DATE <= VAR_ORDERITEM.ORDER_DATE_TO LOOP
          IF VAR_ORDERITEM.SHIPPING_TYPE = 0 THEN
            --判断是否在暂停区间内
            SELECT COUNT(1)
              INTO VAR_PAUSE_CNT
              FROM ORDER_PAUSE_INTERVAL OPI
             WHERE OPI.ORDERITEM_ID = P_ORDERITEM_ID
               AND VAR_REFUND_DATE >= OPI.PAUSE_DATE_FROM
               AND VAR_REFUND_DATE < OPI.RECOVERY_DATE;
            IF VAR_PAUSE_CNT = 0 THEN
              VAR_NUM := VAR_NUM + 1;
            END IF;
          ELSIF VAR_ORDERITEM.SHIPPING_TYPE = 1 THEN
            --判断是否在暂停区间内
            SELECT COUNT(1)
              INTO VAR_PAUSE_CNT
              FROM ORDER_PAUSE_INTERVAL OPI
             WHERE OPI.ORDERITEM_ID = P_ORDERITEM_ID
               AND VAR_REFUND_DATE >= OPI.PAUSE_DATE_FROM
               AND VAR_REFUND_DATE < OPI.RECOVERY_DATE;
            IF VAR_PAUSE_CNT = 0 THEN
              --判断是否是周末、是否是节假日
              SELECT COUNT(1)
                INTO VAR_HOLIDAY
                FROM HOLIDAY HO
               WHERE HO.HOLIDAY_DATE = VAR_REFUND_DATE;
            
              SELECT TO_CHAR(VAR_REFUND_DATE, 'DAY')
                INTO VAR_WEEK
                FROM DUAL;
              IF VAR_HOLIDAY = 0 AND VAR_WEEK <> '星期六' AND
                 VAR_WEEK <> '星期日' THEN
                VAR_NUM := VAR_NUM + 1;
              END IF;
            END IF;
          END IF;
          VAR_REFUND_DATE := VAR_REFUND_DATE + 1;
        END LOOP;
        P_REFUND_NUM := VAR_NUM * VAR_ORDERITEM.DAILY_DELIVERY_QUANTITY;
        IF VAR_ORDERITEM.PAY_PRICE IS NOT NULL THEN
          P_REFUND_AMOUNT := P_REFUND_NUM * VAR_ORDERITEM.PAY_PRICE;
          P_ACT_PRICE     := VAR_ORDERITEM.PAY_PRICE;
          P_PRICE         := VAR_ORDERITEM.PRICE;
        ELSE
          P_REFUND_AMOUNT := P_REFUND_NUM * VAR_ORDERITEM.PRICE;
          P_ACT_PRICE     := VAR_ORDERITEM.PRICE;
          P_PRICE         := VAR_ORDERITEM.PRICE;
        END IF;
      
        P_FLAG := 'Y';
      EXCEPTION
        WHEN OTHERS THEN
          P_FLAG := 'N';
          P_MSG  := '错误信息：' || SQLERRM;
      END;
    END LOOP;
  EXCEPTION
    WHEN OTHERS THEN
      P_FLAG := 'N';
      P_MSG  := '错误信息：' || SQLERRM;
  END;
END syjd_order_pkg;
/

