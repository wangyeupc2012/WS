create package syjd_data_initialize_pkg is

  -- Author  : YUCHAO
  -- Created : 2018/4/3 PM 4:56:33
  -- Purpose : 上线初始化数据公共包

  ----ADDED  BY DongYH begin

  ------清除CRM基础数据程序
  procedure crm_data_initialize;
  procedure saveErrorMessage(tablename    in varchar2,
                             errormessage in varchar2);
  --导入奶站
  PROCEDURE syjd_import_milkstation;
  --插入用户 分配权限
  procedure insert_fnd_users(p_mobilephone    in varchar2,
                             p_name           in varchar2,
                             p_milkstation_id in number);
  --导入经销商
  --奶站关联线上经销商
  PROCEDURE dealers_for_milkstation;
  --从中间表导入POI
  procedure import_poi;
  ----ADDED  BY DongYH end

  ------ADDED   BY  WANGY  BEGIN

  ------导入线上线下订单
  PROCEDURE ORDER_UPLOAD_FROM_EXCEL(P_BATCH_ID IN VARCHAR2,
                                    P_CODE     OUT VARCHAR2);

  --生成奶站用户、权限、职责
  PROCEDURE GEN_MILKSTATION_USERS;
  --EXCEL导入暂停 中间表pause_test
  PROCEDURE IMPORT_PAUSE;
  --EXCEL导入经销商、奶站、配送员配送费
  PROCEDURE IMPORT_PRICE_LIST_FEE;

------ADDED   BY WANGYE  END

end syjd_data_initialize_pkg;
/

