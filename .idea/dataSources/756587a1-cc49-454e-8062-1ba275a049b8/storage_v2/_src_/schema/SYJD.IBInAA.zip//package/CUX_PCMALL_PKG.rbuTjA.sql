create package CUX_PCMALL_PKG is

  -- Author  : WANGYE
  -- Created : 2018/9/3 13:52:32
  -- Purpose : CUX_PCMALL_PKG

  --THIS PROCUDERE IS FOCUS TO CONFIRM SHOPPINGCART ,AND GENERATE A NEW ORDER WHICH NOT PAID
  PROCEDURE GET_SHOPPING_CART_CONFIRM(P_SHOPPINGCART_ID IN NUMBER,
                                      P_USER_ID         IN NUMBER,
                                      P_ORDER_ID        OUT NUMBER,
                                      P_FLAG            OUT VARCHAR2,
                                      P_MSG             OUT VARCHAR2);

  PROCEDURE GET_ORDER_COPY(P_USER_ID  IN NUMBER,
                           P_ORDER_ID IN NUMBER,
                           P_CODE     OUT VARCHAR2,
                           P_MESSAGE  OUT VARCHAR2);

  PROCEDURE GET_SHOPPING_CART_CONFIRM_NEW(P_BATCH_ID      IN NUMBER,
                                          P_USER_ID       IN NUMBER,
                                          P_SHOPPING_DATE IN VARCHAR2,
                                          P_ORDER_ID      OUT NUMBER,
                                          P_FLAG          OUT VARCHAR2,
                                          P_MSG           OUT VARCHAR2);

end CUX_PCMALL_PKG;
/

