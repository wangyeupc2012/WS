create view FND_USER_RESP_MENU_V as
  select fur.user_id, fr.responsibility_id, fr.responsibility_name, frm.menu_id
      from fnd_user_resps fur, fnd_responsibility fr, fnd_resp_menus frm
     where fur.responsibility_id = fr.responsibility_id
       and fr.responsibility_id = frm.responsibility_id
       and trunc(fr.start_date) <= trunc(sysdate)
       and (fr.end_date is null or trunc(fr.end_date) > trunc(sysdate))
       and trunc(fur.start_date) <= trunc(sysdate)
       and (fur.end_date is null or trunc(fur.end_date) > trunc(sysdate))
/

