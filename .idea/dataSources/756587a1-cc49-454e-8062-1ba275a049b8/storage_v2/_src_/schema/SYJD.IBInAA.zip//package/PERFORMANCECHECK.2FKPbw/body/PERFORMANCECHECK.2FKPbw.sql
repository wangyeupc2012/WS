create package body PerformanceCheck is
  procedure load_performance(yearnum number) is
    cursor cur_item is
      select * from milk_station;
  begin
    for var_item in cur_item loop
      insert into cux_performance_check_t
        (performance_check_id,
         dealer_id,
         milk_station_id,
         year,
         month1_performance,
         month1_task,
         month2_performance,
         month2_task,
         month3_performance,
         month3_task,
         month4_performance,
         month4_task,
         month5_performance,
         month5_task,
         month6_performance,
         month6_task,
         month7_performance,
         month7_task,
         month8_performance,
         month8_task,
         month9_performance,
         month9_task,
         month10_performance,
         month10_task,
         month11_performance,
         month11_task,
         month12_performance,
         month12_task,
         created_by,
         creation_date,
         last_update_login,
         last_updated_by,
         last_update_date)
      values
        (performance_check_s.nextval,
         getdealerid(var_item.id),
         var_item.id,
         yearnum,
         getperformance(var_item.id, yearnum, 1),
         (select month1_task from cux_saletask_t where year = yearnum),
         getperformance(var_item.id, yearnum, 2),
         (select month2_task from cux_saletask_t where year = yearnum),
         getperformance(var_item.id, yearnum, 3),
         (select month3_task from cux_saletask_t where year = yearnum),
         getperformance(var_item.id, yearnum, 4),
         (select month4_task from cux_saletask_t where year = yearnum),
         getperformance(var_item.id, yearnum, 5),
         (select month5_task from cux_saletask_t where year = yearnum),
         getperformance(var_item.id, yearnum, 6),
         (select month6_task from cux_saletask_t where year = yearnum),
         getperformance(var_item.id, yearnum, 7),
         (select month7_task from cux_saletask_t where year = yearnum),
         getperformance(var_item.id, yearnum, 8),
         (select month8_task from cux_saletask_t where year = yearnum),
         getperformance(var_item.id, yearnum, 9),
         (select month9_task from cux_saletask_t where year = yearnum),
         getperformance(var_item.id, yearnum, 10),
         (select month10_task from cux_saletask_t where year = yearnum),
         getperformance(var_item.id, yearnum, 11),
         (select month11_task from cux_saletask_t where year = yearnum),
         getperformance(var_item.id, yearnum, 12),
         (select month12_task from cux_saletask_t where year = yearnum),
         -1,
         sysdate,
         -1,
         -1,
         sysdate);
    end loop;
  end;

  FUNCTION getperformance(var_milk_station_id number,
                          yearnum             number,
                          monthnum            number) return number is
    v_performance number;
  BEGIN
    select sum(oi.QUANTITY * p.coefficient)
      into v_performance
      from Orders o, ORDERITEM oi, product p
     where o.id = oi.orders
       and oi.PRODUCT_SN = p.SN
       and o.milk_station_id = var_milk_station_id
       and TO_CHAR(oi.CREATEDDATE, 'yyyy- mm') =
           to_char(yearnum) || '-' || to_char(monthnum, '09');
    return v_performance;
  END;

  function getdealerid(p_id number) return number is
    v_dealers_id number;
  begin
    select dealers_id
      into v_dealers_id
      from milk_station_line
     where id = p_id;
    return v_dealers_id;
  end getdealerid;
end PerformanceCheck;
/

