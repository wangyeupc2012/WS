create package CRM_PRODUCT_CHECK_PKG is

  -- Author  : WANGYE
  -- Created : 2017/11/1 9:33:47
  -- Purpose : CRM_PRODUCT_CHECK_PKG

  procedure check_product;

end CRM_PRODUCT_CHECK_PKG;
/

