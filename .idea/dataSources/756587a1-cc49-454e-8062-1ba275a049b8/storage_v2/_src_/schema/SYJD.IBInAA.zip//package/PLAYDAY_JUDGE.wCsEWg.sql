create package playday_judge is

  -- Author  : best_dyh
  -- Created : 2017/9/16 10:32:36
  -- Purpose : playdayjudge
          function f_playdayjudate(date1 varchar2,
                                 date2 varchar2) return number;

end playday_judge;
/

