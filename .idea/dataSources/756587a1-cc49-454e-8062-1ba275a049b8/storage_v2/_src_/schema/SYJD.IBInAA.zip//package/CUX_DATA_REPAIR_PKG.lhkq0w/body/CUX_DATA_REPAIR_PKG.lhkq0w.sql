create package body cux_data_repair_pkg is

  procedure cux_add_hot_item is
    cursor cur_prd is
      select prd.SN, pll.PRICE_ZD
        from PRODUCT prd, PRICE_LIST_HEADERS plh, PRICE_LIST_LINES pll
       where 1 = 1
         and plh.ID = pll.HEADER_ID
         and pll.PRODUCT_ID = prd.ID
         and plh.ID = 1628460;
    var_prd        cur_prd%rowtype;
    var_radomprice number;
  begin
    for var_prd in cur_prd loop
      var_radomprice := round(DBMS_RANDOM.VALUE(1, var_prd.price_zd), 1);
      insert into CUX_APP_HOT_ITEM_T
        (id, Item_Sn, New_Price, Old_Price)
      values
        (get_primary_id('CUX_APP_HOT_ITEM_T'),
         var_prd.sn,
         var_radomprice,
         var_prd.price_zd);
      commit;
    end loop;
  end;

  procedure cux_add_item_attibute is
    cursor cur_prd is
      select prd.SN, pll.PRICE_ZD, prd.id, prd.name
        from PRODUCT prd, PRICE_LIST_HEADERS plh, PRICE_LIST_LINES pll
       where 1 = 1
         and plh.ID = pll.HEADER_ID
         and pll.PRODUCT_ID = prd.ID
         and plh.ID = 1628460;
    var_prd        cur_prd%rowtype;
    var_cnt        number;
    var_radomprice number;
  begin
    for var_prd in cur_prd loop
      select count(1)
        into var_cnt
        from CUX_APP_ITEM_ATTRIBUTE_T t
       where t.item_sn = var_prd.sn;
    
      if var_cnt = 0 then
        var_radomprice := round(DBMS_RANDOM.VALUE(1, var_prd.price_zd), 1);
        insert into CUX_APP_ITEM_ATTRIBUTE_T
          (id,
           CREATEDDATE,
           Lastmodifieddate,
           Createdby,
           LASTMODIFIEDBY,
           ITEM_SN,
           ITEM_ID,
           ITEM_NAME,
           ITEM_THUMBNAIL,
           ITEM_PICTURE,
           PRICE_NOW,
           PRICE_ORI,
           STORAGE_CONDITION,
           SHELF_LIFE)
        values
          (get_primary_id('CUX_APP_ITEM_ATTRIBUTE_T'),
           sysdate,
           sysdate,
           -1,
           -1,
           var_prd.sn,
           var_prd.id,
           var_prd.name,
           'http://122.115.53.97/SYJDWS/app/picture.do?imagename=WX20180919-102420@2x.png',
           '',
           var_radomprice,
           var_prd.price_zd,
           '',
           '');
        commit;
      end if;
    end loop;
  end;

  procedure cux_add_item_promotion is
    cursor cur_prd is
      select * from CUX_APP_ITEM_ATTRIBUTE_T;
    var_prd cur_prd%rowtype;
    var_cnt number;
  begin
    for var_prd in cur_prd loop
      select count(1)
        into var_cnt
        from CUX_APP_PROMOTION_ITEM_T t
       where t.item_sn = var_prd.item_sn;
    
      if var_cnt = 0 then
        insert into CUX_APP_PROMOTION_ITEM_T
          (id, ITEM_SN, New_Price, Old_Price)
        values
          (get_primary_id('CUX_APP_PROMOTION_ITEM_T'),
           var_prd.item_sn,
           var_prd.price_now,
           var_prd.price_ori);
        commit;
      end if;
    end loop;
  end;

  procedure cux_add_item_special is
    cursor cur_prd is
      select * from CUX_APP_ITEM_ATTRIBUTE_T;
    var_prd cur_prd%rowtype;
    var_cnt number;
  begin
    for var_prd in cur_prd loop
      select count(1)
        into var_cnt
        from CUX_APP_SPECIAL_ITEM_T t
       where t.item_sn = var_prd.item_sn;
    
      if var_cnt = 0 then
        insert into CUX_APP_SPECIAL_ITEM_T
          (id, ITEM_SN, New_Price, Old_Price)
        values
          (get_primary_id('CUX_APP_SPECIAL_ITEM_T'),
           var_prd.item_sn,
           var_prd.price_now,
           var_prd.price_ori);
        commit;
      end if;
    end loop;
  end;

  procedure cux_radom_valid_item is
  
  begin
    null;
  end;

  procedure cux_add_special_ads is
    cursor cur_prd is
      select * from CUX_APP_ITEM_ATTRIBUTE_T;
    var_prd cur_prd%rowtype;
  begin
    for var_prd in cur_prd loop
      insert into CUX_APP_SPECIAL_AD_T
        (id,
         CREATEDDATE,
         LASTMODIFIEDDATE,
         Createdby,
         Lastmodifiedby,
         THUMBNAIL,
         PICTURE,
         Item_Id,
         ITEM_SN,
         STATUS)
      values
        (get_primary_id('CUX_APP_SPECIAL_AD_T'),
         sysdate,
         sysdate,
         -1,
         -1,
         var_prd.item_thumbnail,
         var_prd.item_thumbnail,
         '',
         var_prd.item_sn,
         'N');
      commit;
    end loop;
  end;

  procedure cux_delete_members is
    cursor cur_mem is
      select * from cux_member_t;
    var_mem  cur_mem%rowtype;
    var_id   number;
    var_flag varchar2(10);
  begin
    for var_mem in cur_mem loop
      var_flag := 'Y';
      begin
      
        select id into var_id from member where openid = var_mem.openid;
      
      exception
        when others then
          var_flag := 'N';
      end;
      if var_flag = 'Y' then
        update orders os set os.member_id = '' where os.member_id = var_id;
      
        delete from pointlog pl where pl.member_id = var_id;
      
        delete from receiver re where re.member_id = var_id;
      
        delete from member mem where mem.id = var_id;
      
        commit;
      end if;
    
    end loop;
  end;

  procedure cux_add_item_attibute_others is
    cursor cur_prd is
      select prd.SN, 0 PRICE_ZD, prd.id, prd.name
        from PRODUCT prd
       where not exists (select 1
                from CUX_APP_ITEM_ATTRIBUTE_T cai
               where cai.ITEM_ID = prd.ID);
    var_prd cur_prd%rowtype;
    var_cnt        number;
    var_radomprice number;
  begin
    for var_prd in cur_prd loop
      select count(1)
        into var_cnt
        from CUX_APP_ITEM_ATTRIBUTE_T t
       where t.item_sn = var_prd.sn;
    
      if var_cnt = 0 then
        var_radomprice := round(DBMS_RANDOM.VALUE(1, var_prd.price_zd), 1);
        insert into CUX_APP_ITEM_ATTRIBUTE_T
          (id,
           CREATEDDATE,
           Lastmodifieddate,
           Createdby,
           LASTMODIFIEDBY,
           ITEM_SN,
           ITEM_ID,
           ITEM_NAME,
           ITEM_THUMBNAIL,
           ITEM_PICTURE,
           PRICE_NOW,
           PRICE_ORI,
           STORAGE_CONDITION,
           SHELF_LIFE)
        values
          (get_primary_id('CUX_APP_ITEM_ATTRIBUTE_T'),
           sysdate,
           sysdate,
           -1,
           -1,
           var_prd.sn,
           var_prd.id,
           var_prd.name,
           'http://122.115.53.97/SYJDWS/app/picture.do?imagename=WX20180919-102420@2x.png',
           '',
           var_radomprice,
           var_prd.price_zd,
           '',
           '');
        commit;
      end if;
    end loop;
  end;
  
  --验证订单来源是线上还是线下
  function validate_order_status(p_order_source  varchar2,
                                 p_order_status  varchar2,
                                 p_show_platform varchar2) return varchar2 is
    v_count number := 0;
    v_flag  varchar2(10);
  begin
    if p_show_platform = '' or p_show_platform is null or
       p_show_platform = 'CRM' then
      select count(1)
        into v_count
        from fnd_lookup_values flv
       where flv.lookup_type = 'ORDER_FROM'
         and flv.lookup_code = p_order_source
         and flv.attribute1 = nvl(p_order_status, flv.attribute1)
         and flv.attribute2 in ('ALL', 'CRM');
    else
      select count(1)
        into v_count
        from fnd_lookup_values flv
       where flv.lookup_type = 'ORDER_FROM'
         and flv.lookup_code = p_order_source
         and flv.attribute1 = nvl(p_order_status, flv.attribute1)
         and flv.attribute2 in ('ALL');
    end if;
    if v_count <> 0 then
      v_flag := 'Y';
    else
      v_flag := 'N';
    end if;
    return v_flag;
  end;
end cux_data_repair_pkg;
/

