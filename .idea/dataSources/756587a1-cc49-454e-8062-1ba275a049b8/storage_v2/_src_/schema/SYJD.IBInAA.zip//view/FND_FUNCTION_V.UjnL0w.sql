create view FND_FUNCTION_V as
  select ff.function_id, ff.function_name, ff.function_path
  from fnd_function ff
 where trunc(ff.start_date) <= trunc(sysdate)
   and (ff.end_date is null or trunc(ff.end_date) > trunc(sysdate))
/

