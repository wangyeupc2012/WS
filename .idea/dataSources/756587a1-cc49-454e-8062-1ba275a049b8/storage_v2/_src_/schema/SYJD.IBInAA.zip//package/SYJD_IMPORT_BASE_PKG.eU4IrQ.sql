create package syjd_import_base_pkg is

  -- Author  : YUCHAO
  -- Created : 2017/8/15 AM 10:38:09
  -- Purpose : 

  procedure import_base_data(p_base_type varchar2);

  procedure import_item;
--  procedure import_erp_item(p_item_id number default null ,p_organization_id number default null);
  procedure import_price;
  procedure import_price_header(p_header_id number);
  procedure import_price_line(p_line_id number);

end syjd_import_base_pkg;
/

