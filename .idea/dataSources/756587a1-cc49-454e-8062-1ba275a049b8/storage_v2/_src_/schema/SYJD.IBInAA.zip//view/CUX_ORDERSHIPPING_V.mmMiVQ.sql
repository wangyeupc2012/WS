create view CUX_ORDERSHIPPING_V as
  select min(os.shipping_date) shipping_date,
       os.phone || os.address custmer,
       ost.name,
       sum(ost.quantity)quantity

  from ordershipping     os, ----配送单头表
       ordershippingitem ost ---配送单行表
 where os.id = ost.ordershipping_id
 group by os.phone || os.address, os.shipping_date, ost.name, ost.quantity
/

