create package CUX_GET_PAUSE_MINUS_DAYS is

  -- Author  : WANGYE
  -- Created : 2018/4/9 14:24:55
  -- Purpose : CUX_GET_PAUSE_MINUS_DAYS
  function getPauseMinusDays(p_id           varchar2,
                             p_pause_from   varchar2,
                             p_revoery_date varchar2) return number;

end CUX_GET_PAUSE_MINUS_DAYS;
/

