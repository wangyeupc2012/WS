create package cux_crm_util is

  -- Author  : YUCHAO
  -- Created : 2018/5/16 PM 3:40:15
  -- Purpose : 

  --------根据订单编号获取经销商名字
  function get_dealers_name(p_order_number varchar2) return varchar2;

  procedure validate_orders(p_order_number varchar2,
                            p_flag         out varchar2,
                            p_message      out varchar2);
  ----验证订单状态是否变成已完成                          
  function validate_order_lastdate(p_order_number varchar2) return number;

  ----根据起始日期，终止日期，配送类型计算配送天数

  -----生成配送单编号
  function get_tk_number return varchar2;

  --计算两个日期间有多少天
  procedure get_how_many_days(p_start_date   in varchar2,
                              p_end_date     in varchar2,
                              p_orderitem_id in varchar2,
                              p_type         in varchar2,
                              p_flag         out varchar2,
                              p_result       out varchar2);
  --查询奶站状态                 
  function check_milk_station_status(p_milk_station_id number,
                                     p_status          varchar2)
    return varchar2;

end cux_crm_util;
/

