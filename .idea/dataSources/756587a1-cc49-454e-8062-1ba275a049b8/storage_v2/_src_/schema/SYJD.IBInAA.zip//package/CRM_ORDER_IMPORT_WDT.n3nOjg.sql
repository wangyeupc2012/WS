create package crm_order_import_wdt is

  -- Author  : LONGWY
  -- Created : 2018/06/29
  -- Purpose : crm_order_import_wdt_test0626
  --导入正式表 禁止从正式环境覆盖测试环境 有效期至2018-9-20
  procedure import_into_orders(p_batch_id             in number,
                               p_insert_flag          out varchar2,
                               p_insert_error_message out varchar2);
  procedure import_into_pause_promotion(p_orderitemid in number, --中间表订单行ID
                                        p_batchId     in number,
                                        p_line_id     in number); --正式表行ID
  procedure import_other_province_orders(p_batch_id in number,
                                         p_result   out varchar2);

  function get_auto_order_sn(p_header varchar2) return varchar2;

end crm_order_import_wdt;
/

