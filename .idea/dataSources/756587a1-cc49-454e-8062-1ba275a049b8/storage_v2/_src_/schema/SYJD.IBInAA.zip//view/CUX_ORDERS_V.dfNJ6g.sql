create view CUX_ORDERS_V as
  select  os.sn orders_number,
        os.milk_station_id,
        flvs.attribute1  order_source,
        oi."ID",oi."CREATEDDATE",oi."LASTMODIFIEDDATE",oi."VERSION",oi."COMMISSIONTOTALS",oi."ISDELIVERY",oi."NAME",oi."PRICE",oi."QUANTITY",oi."RETURNEDQUANTITY",oi."SHIPPEDQUANTITY",oi."SN",oi."SPECIFICATIONS",oi."THUMBNAIL",oi."TYPE",oi."WEIGHT",oi."ORDERS",oi."SKU_ID",oi."CREATED_BY",oi."LAST_UPDATED_BY",oi."ORDER_DATE_FROM",oi."ORDER_DATE_TO",oi."ORDER_DAYS",oi."DAILY_DELIVERY_QUANTITY",oi."DELIVERY_DAYS",oi."REMAIN_DAYS",oi."LINE_STATUS",oi."DAY_SHIPPING_TIME",oi."SHIPPING_TYPE",oi."ORIGINAL_ORDER_DATE_TO",oi."PAY_PRICE",oi."MEMO",oi."PROMOTION_ID",oi."PRODUCT_SN",oi."WDTORDERITEMID",oi."TOTALPRICE",oi."PRESENT_FLAG",oi."COEFFICIENT",oi."UNDERTAKER",oi."REFUND_STATUS",oi."DATE_AFTER_PAUSE",oi."TWID",oi."REFUND_DATE",oi."LINE_COUNT",oi."PRODUCTCOMBOBOFLAG"
from orders os
    ,orderitem oi
    ,fnd_lookup_values flvs
where os.id=oi.orders
and os.order_from=flvs.lookup_code
and flvs.lookup_type='ORDER_FROM'
/

