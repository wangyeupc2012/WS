create package cux_o2o_basic_data_pkg is

  -- Author  : YUCHAO
  -- Created : 2018/2/8 AM 10:06:19
  -- Purpose : 
  g_org_id          number := 211;
  g_organization_id number := 852;
  procedure lood_item;
  procedure crete_ass;
  procedure load_cars;

end cux_o2o_basic_data_pkg;
/

