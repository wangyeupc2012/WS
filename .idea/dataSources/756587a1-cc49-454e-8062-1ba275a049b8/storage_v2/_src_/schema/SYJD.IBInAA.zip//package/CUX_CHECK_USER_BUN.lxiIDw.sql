create package cux_check_user_bun is

  function cux_check_user_bun(p_user_id     varchar2,
                              p_button_name varchar2,
                              p_type        varchar2) return varchar2;

  function cux_check_user_bun1(p_user_id     varchar2,
                               p_button_name varchar2,
                               p_type        varchar2) return varchar2;
end cux_check_user_bun;
/

