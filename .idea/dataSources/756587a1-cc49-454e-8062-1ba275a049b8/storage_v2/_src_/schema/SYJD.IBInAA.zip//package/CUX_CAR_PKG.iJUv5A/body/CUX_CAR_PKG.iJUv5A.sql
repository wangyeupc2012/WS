create package body CUX_CAR_PKG is

    function getCarWayANDCarTimeName(p_milk_station_id number)
      return varchar2 is
      v_car_name varchar2(50);
    begin
      select distinct cw.car_way_name || ct.car_time_name
        into v_car_name
        from car_way               cw,
             car_time              ct,
             car_time_milk_station ctm,
             MILK_STATION          ms
       where ct.car_way_id = cw.id
         and ct.id = ctm.car_time_id
         and ctm.milk_station_id = ms.id
         and ctm.milk_station_id = p_milk_station_id;
      return v_car_name;
    end;
  end CUX_CAR_PKG;
/

