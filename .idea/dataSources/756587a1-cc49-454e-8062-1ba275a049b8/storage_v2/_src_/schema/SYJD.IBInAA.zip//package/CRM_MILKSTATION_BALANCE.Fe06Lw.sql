create package CRM_MILKSTATION_BALANCE is

  -- Author  : C254462
  -- Created : 2018/9/27 11:05:43
  -- Purpose : CRM_MILKSTATION_BALANCE

  -- Public type declarations
  procedure update_creditamount(p_milk_station_id in varchar2,
                                p_creditamount    in varchar2,
                                p_code            out varchar2,
                                p_message         out varchar2);
  procedure update_prepayment(p_milk_station_id in varchar2,
                              p_prepayment      in varchar2,
                              p_code            out varchar2,
                              p_message         out varchar2);

end CRM_MILKSTATION_BALANCE;
/

