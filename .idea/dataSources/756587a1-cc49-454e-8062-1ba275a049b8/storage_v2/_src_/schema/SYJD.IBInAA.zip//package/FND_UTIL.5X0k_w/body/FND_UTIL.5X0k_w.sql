create package body FND_UTIL is

  -- Author  : AI
  -- Created : 2015-05-11 07:59:29
  -- Purpose : FND_UTIL
  --验证用户数据相关
  function validate_auth(p_user_id number,
                         --p_dealers_id      varchar2,
                         p_milk_station_id varchar2,
                         p_ms_courier_id   varchar2) return varchar2 is
    x_return_result varchar2(10) := 'Y';
    x_count         number := 0;
  begin
  
    --from
    select count(*)
      into x_count
      from fnd_user_assess_auth fuaa
     where fuaa.user_id = p_user_id
          /*and decode(fuaa.dealers_id, -1, p_dealers_id, fuaa.dealers_id) =
          p_dealers_id*/
       and decode(fuaa.milk_station_id,
                  -1,
                  NVL(p_milk_station_id, 1),
                  fuaa.milk_station_id) = NVL(p_milk_station_id, 1)
       and decode(fuaa.ms_courier_id,
                  -1,
                  NVL(p_ms_courier_id, 1),
                  fuaa.ms_courier_id) = NVL(p_ms_courier_id, 1)
       and fuaa.auth_type = 'INCLUDE'
       and fuaa.valid_flag = 'Y';
    if x_count > 0 then
      x_return_result := 'Y';
    else
      x_return_result := 'N';
    end if;
  
    return x_return_result;
  exception
    when others then
      return 'N';
  end;

  --验证用户经销商和奶站的关系
  function crm_validate_auth(p_user_id number, p_milk_station_id varchar2)
    return varchar2 is
    x_return_result varchar2(10) := 'Y';
    x_count         number := 0;
    cursor assesses is
      select * from fnd_user_assess_auth where user_id = p_user_id;
  begin
    for assess in assesses loop
      if assess.dealers_id = -1 then
        x_count := 999;
      elsif assess.milk_station_id = -1 then
        select count(fuaa.id)
          into x_count
          from fnd_user_assess_auth fuaa,
               milk_station         ms,
               milk_station_line    msl
         where fuaa.dealers_id = msl.dealers_id
           and ms.id = msl.header_id
           and fuaa.auth_type = 'INCLUDE'
           and fuaa.valid_flag = 'Y'
           and fuaa.user_id = p_user_id
           and ms.id = nvl(p_milk_station_id, fuaa.milk_station_id);
      else
        select count(fuaa.id)
          into x_count
          from fnd_user_assess_auth fuaa
         where fuaa.milk_station_id =
               nvl(p_milk_station_id, fuaa.milk_station_id)
           and fuaa.auth_type = 'INCLUDE'
           and fuaa.valid_flag = 'Y'
           and fuaa.user_id = p_user_id;
      end if;
      if x_count > 0 then
        exit;
      end if;
    end loop
    /*select count(fuaa.id)
                                              into x_count
                                              from fnd_user_assess_auth fuaa
                                                  ,milk_station ms
                                                  ,milk_station_line msl
                                             where decode(fuaa.milk_station_id,-1,ms.id,fuaa.milk_station_id)=ms.id
                                             and ms.id=msl.header_id
                                             and fuaa.auth_type = 'INCLUDE'
                                             and fuaa.valid_flag = 'Y'
                                             and fuaa.user_id = p_user_id
                                            -- and msl.dealers_id=187
                                             and ms.id=nvl(p_milk_station_id,'-2')*/
    ;
  
    if x_count > 0 then
      x_return_result := 'Y';
    else
      x_return_result := 'N';
    end if;
  
    return x_return_result;
  exception
    when others then
      return 'N';
  end;

  --根据lookup_type和lookup_code 获取 meaning
  function get_lookup_meaning(p_lookup_type in varchar2,
                              p_lookup_code varchar) return varchar2 is
    l_result varchar2(300);
  begin
    select flv.meaning
      into l_result
      from fnd_lookup_values flv
     where flv.lookup_type = p_lookup_type --'LOG_QUENE_TYPE'
       and flv.lookup_code = p_lookup_code;
  
    if l_result is null then
      l_result := p_lookup_code;
    end if;
    return l_result;
  exception
    when others then
      return p_lookup_code;
  end;

  procedure get_primary_id(p_seq_name in varchar2, x_id out number) is
    l_seq_name varchar2(100);
    l_cnt      number;
    l_next_val number;
    l_val_from number;
    l_val_to   number;
    l_id       number;
  begin
    --序列名为null，返回null
    if p_seq_name is null then
      return;
    end if;
  
    l_seq_name := UPPER(p_seq_name);
  
    --判断序列是否存在
    select count(1)
      into l_cnt
      from idgenerator ig
     where UPPER(ig.sequence_name) = l_seq_name;
    --序列不存在，返回null
    if l_cnt = 0 then
      return;
    end if;
  
    --判断临时表该序列是否存在
    select count(1)
      into l_cnt
      from idgenerator_tmp igt
     where UPPER(igt.sequence_name) = l_seq_name;
  
    if l_cnt != 0 then
      --如果存在,则获取next_val并锁表
      select igt.next_val, igt.val_from, igt.val_to
        into l_next_val, l_val_from, l_val_to
        from idgenerator_tmp igt
       where UPPER(igt.sequence_name) = l_seq_name
         for update;
    
      l_id := l_next_val;
      --判断igt.next_val是否等于igt.val_to,是则重新获取序列开始，结束值
      if l_next_val = l_val_to then
        select ig.next_val
          into l_next_val
          from idgenerator ig
         where UPPER(ig.sequence_name) = l_seq_name
           for update;
      
        update idgenerator ig
           set ig.next_val = ig.next_val + 100
         where UPPER(ig.sequence_name) = l_seq_name;
      
        update idgenerator_tmp igt
           set igt.next_val = l_next_val,
               igt.val_from = l_next_val,
               igt.val_to   = l_next_val + 99
         where UPPER(igt.sequence_name) = l_seq_name;
      else
        --否，则直接更新next_val+1
        update idgenerator_tmp igt
           set igt.next_val = l_next_val + 1
         where UPPER(igt.sequence_name) = l_seq_name;
      end if;
      commit;
    
    else
      --临时表不存在该序列，则从idgenerator获取序列
      select ig.next_val
        into l_next_val
        from idgenerator ig
       where UPPER(ig.sequence_name) = l_seq_name
         for update;
    
      l_id := l_next_val;
    
      update idgenerator ig
         set ig.next_val = ig.next_val + 100
       where UPPER(ig.sequence_name) = l_seq_name;
    
      insert into idgenerator_tmp
        (sequence_name, next_val, val_from, val_to)
      values
        (l_seq_name, l_next_val + 1, l_next_val, l_next_val + 99);
    
      commit;
    end if;
  
    x_id := l_id;
  end;

  function get_id(p_seq_name varchar2) return number is
    l_id number;
  begin
    get_primary_id(p_seq_name, l_id);
    return l_id;
  end;

  --输入两个日期判断两个日期之间有多少个节假日
  procedure f_playday_judge(p_start_date   in varchar2,
                            p_end_date     in varchar2,
                            p_extend_day   in varchar2,
                            holiday_amount out number,
                            all_amount     out number,
                            extend_date    out varchar) is
    amount_result number := 0;
    week_number   number := 0;
    judge_number  number := 0;
    start_date    date := to_date(p_start_date, 'yyyy-mm-dd');
    end_date      date := to_date(p_end_date, 'yyyy-mm-dd');
  begin
    if start_date > end_date or start_date is null or end_date is null then
      amount_result := 0;
    elsif start_date = end_date then
      loop
        select to_char(start_date, 'D') into week_number from dual;
        if week_number = 7 or week_number = 1 then
          amount_result := amount_result + 1;
        else
          select count(1)
            into judge_number
            from holiday
           where start_date = holiday_date;
          if judge_number > 0 then
            amount_result := amount_result + 1;
          end if;
        end if;
        start_date := start_date + 1;
        exit when week_number <> 7 and week_number <> 1 and judge_number = 0;
      end loop;
    else
      loop
        select to_char(start_date, 'D') into week_number from dual;
        if week_number = 7 or week_number = 1 then
          amount_result := amount_result + 1;
        else
          select count(1)
            into judge_number
            from holiday
           where start_date = holiday_date;
          if judge_number > 0 then
            amount_result := amount_result + 1;
          end if;
        end if;
        start_date := start_date + 1;
        exit when start_date > end_date;
      end loop;
    end if;
    holiday_amount := amount_result;
    all_amount     := nvl(to_date(p_end_date, 'yyyy-mm-dd') -
                          to_date(p_start_date, 'yyyy-mm-dd') + 1,
                          0);
    extend_date    := to_char(to_date(p_end_date, 'yyyy-mm-dd') +
                              nvl(p_extend_day, amount_result),
                              'yyyy-mm-dd');
  exception
    when others then
      holiday_amount := -1;
      all_amount     := -1;
      extend_date    := -1;
  end;
  --验证订单来源是线上还是线下
  function validate_order_status(p_order_source  varchar2,
                                 p_order_status  varchar2,
                                 p_show_platform varchar2) return varchar2 is
    v_count number := 0;
    v_flag  varchar2(10);
  begin
    if p_show_platform = '' or p_show_platform is null or
       p_show_platform = 'CRM' then
      select count(1)
        into v_count
        from fnd_lookup_values flv
       where flv.lookup_type = 'ORDER_FROM'
         and flv.lookup_code = p_order_source
         and flv.attribute1 = nvl(p_order_status, flv.attribute1)
         and flv.attribute2 in ('ALL', 'CRM');
    else
      select count(1)
        into v_count
        from fnd_lookup_values flv
       where flv.lookup_type = 'ORDER_FROM'
         and flv.lookup_code = p_order_source
         and flv.attribute1 = nvl(p_order_status, flv.attribute1)
         and flv.attribute2 in ('ALL');
    end if;
    if v_count <> 0 then
      v_flag := 'Y';
    else
      v_flag := 'N';
    end if;
    return v_flag;
  end;

  --获取当前配送员的服务态度星级                                 
  function get_mscourier_service_attitude(p_mscourier_id number)
    return number is
    v_avg_review number;
    v_sum_review number;
    v_count      number;
  begin
    --判断该配送员是否已有服务态度评价星级（从review表获取）
    select count(1)
      into v_count
      from review re
     where re.courier_id = p_mscourier_id;
    if v_count > 0 then
      --获取计算配送员的服务态度评价星级
      select sum(re.score)
        into v_sum_review
        from review re
       where re.courier_id = p_mscourier_id;
      v_avg_review := round(v_sum_review / v_count);
    else
      v_avg_review := 0;
    end if;
    return v_avg_review;
  end;

  --根据订单编号获取退款金额
  procedure get_orderrefund_amount(p_order_id           in number,
                                   p_orderrefund_amount out number) is
    cursor cur_ord_shipping is
      select * from ordershipping os where os.orders = p_order_id;
    cursor cur_ord_shippingitem(p_ordershipping_id in number) is
      select *
        from ordershippingitem osi
       where osi.ordershipping_id = p_ordershipping_id;
    v_count              number;
    v_count_line         number;
    v_amount             number;
    v_pirce              number;
    v_pay_price          number;
    var_ord_shipping     cur_ord_shipping%rowtype;
    var_ord_shippingitem cur_ord_shippingitem%rowtype;
    x_code               varchar2(10);
    x_message            varchar2(200);
  begin
    --判断该订单是否已生成配送单
    select count(1)
      into v_count
      from ordershipping os
     where os.orders = p_order_id;
  
    select o.amountpaid
      into v_pay_price
      from orders o
     where o.id = p_order_id;
    if v_count > 0 then
      v_amount := 0;
      for var_ord_shipping in cur_ord_shipping loop
        --判断配送单行是否有数据
        select count(1)
          into v_count_line
          from ordershippingitem osi
         where osi.ordershipping_id = var_ord_shipping.id;
        if v_count_line > 0 then
          for var_ord_shippingitem in cur_ord_shippingitem(var_ord_shipping.id) loop
            select nvl(oi.pay_price, oi.price)
              into v_pirce
              from orderitem oi
             where oi.id = var_ord_shippingitem.orderitemid;
            v_amount := v_amount + var_ord_shippingitem.quantity * v_pirce;
          end loop;
        else
          v_amount := v_amount + 0;
        end if;
      end loop;
      p_orderrefund_amount := v_pay_price - v_amount;
    else
      --未生成配送单，则整单退款
      select o.amountpaid
        into v_amount
        from orders o
       where o.id = p_order_id;
      p_orderrefund_amount := v_amount;
    end if;
  exception
    when others then
      x_message := '错误信息：' || sqlerrm;
      x_code    := 'N';
      --p_message := x_message;
    --p_code    := x_code;
    --dbms_output.put_line(x_message);
  end;
  --获得订单中间表的错误信息
  function getErrorMessageFromTempOrder(p_orderid varchar2) return varchar is
    v_message     varchar2(1000);
    v_err_message varchar2(1000);
  begin
    begin
      select check_error_message || insert_error_message ||
             merge_error_message
        into v_message
        from crm_order_header_temp
       where id = p_orderid;
    
    exception
      when others then
        v_message := null;
    end;
  
    if v_message = null then
      begin
        select check_error_message || insert_error_message ||
               merge_error_message
          into v_message
          from crm_order_line_temp
         where orders = p_orderid;
      exception
        when others then
          v_message := null;
      end;
      if v_message = null then
        v_message := '';
      else
        v_message := '订单行有错误信息，请查看';
      end if;
    else
      v_err_message := v_message;
    end if;
    return v_err_message;
  end;

  function getPauseMinusDays(p_id           varchar2,
                             p_pause_from   varchar2,
                             p_revoery_date varchar2) return number is
    v_days          number;
    v_orderitem_id  varchar2(10);
    v_shipping_type varchar2(10);
    v_pause_from    date;
    v_recovery_date date;
  begin
    --获取订单行ID
    select opi.orderitem_id, opi.pause_date_from, opi.recovery_date
      into v_orderitem_id, v_pause_from, v_recovery_date
      from order_pause_interval opi
     where opi.id = p_id;
  
    --获取订单行配送类型
    select oi.shipping_type
      into v_shipping_type
      from orderitem oi
     where oi.id = v_orderitem_id;
  
    if v_shipping_type = 0 then
      select case
               when to_date(p_revoery_date, 'yyyy-MM-dd') <=
                    opi.recovery_date then
                0
               when to_date(p_pause_from, 'yyyy-MM-dd') <=
                    opi.pause_date_from and
                    to_date(p_revoery_date, 'yyyy-MM-dd') >
                    opi.pause_date_from and
                    to_date(p_revoery_date, 'yyyy-MM-dd') <=
                    opi.recovery_date then
                to_date(p_revoery_date, 'yyyy-MM-dd') - opi.pause_date_from
               when to_date(p_pause_from, 'yyyy-MM-dd') <=
                    opi.pause_date_from and
                    to_date(p_revoery_date, 'yyyy-MM-dd') >
                    opi.recovery_date then
                opi.recovery_date - opi.pause_date_from
               when to_date(p_pause_from, 'yyyy-MM-dd') >
                    opi.pause_date_from and
                    to_date(p_pause_from, 'yyyy-MM-dd') <= opi.recovery_date and
                    to_date(p_revoery_date, 'yyyy-MM-dd') <=
                    opi.recovery_date then
                to_date(p_revoery_date, 'yyyy-MM-dd') -
                to_date(p_pause_from, 'yyyy-MM-dd')
               when to_date(p_pause_from, 'yyyy-MM-dd') >
                    opi.pause_date_from and
                    to_date(p_pause_from, 'yyyy-MM-dd') <= opi.recovery_date and
                    to_date(p_revoery_date, 'yyyy-MM-dd') >
                    opi.recovery_date then
                opi.recovery_date - to_date(p_pause_from, 'yyyy-MM-dd')
               when to_date(p_pause_from, 'yyyy-MM-dd') > opi.recovery_date then
                0
             end
        into v_days
        from order_pause_interval opi
       where 1 = 1
         and opi.id = p_id;
    elsif v_shipping_type = 1 then
      if to_date(p_revoery_date, 'yyyy-MM-dd') <= v_pause_from then
        v_days := 0;
      elsif to_date(p_pause_from, 'yyyy-MM-dd') <= v_pause_from then
        null;
      end if;
    end if;
  
    return v_days;
  exception
    when others then
      null;
  end;

  function getErpMilkStationCondition(p_flag varchar2) return varchar is
    v_result varchar2(100) := 'N';
    v_count  number := 0;
  begin
    /*if p_flg = 'Y'
    then*/
    null;
  end;

  function showZeroBeforePoint(p_num number) return varchar2 is
    v_num    varchar2(100);
    v_nvlnum number;
  begin
    v_nvlnum := nvl(p_num, 0);
    select decode(substr(v_nvlnum, 1, 1), '.', '0' || v_nvlnum, v_nvlnum)
      into v_num
      from dual;
    return v_num;
  end;

end FND_UTIL;
/

