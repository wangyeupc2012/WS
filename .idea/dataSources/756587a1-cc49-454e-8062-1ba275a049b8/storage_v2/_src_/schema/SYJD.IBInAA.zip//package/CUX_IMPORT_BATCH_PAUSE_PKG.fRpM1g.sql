create package CUX_IMPORT_BATCH_PAUSE_PKG is

  -- Author  : WANGYE
  -- Created : 2018/4/9 19:06:20
  -- Purpose : CUX_IMPORT_BATCH_PAUSE_PKG

--新增批量暂停
  PROCEDURE IMPORT_BATCH_PAUSE(P_MSCOURIER_ID  IN VARCHAR2,
                               P_PAUSE_REASON  IN VARCHAR2,
                               P_PAUSE_FROM    IN VARCHAR2,
                               P_RECOVERY_DATE IN VARCHAR2,
                               P_CREATED_BY    IN VARCHAR2,
                               P_FLAG          OUT VARCHAR2,
                               P_MSG           OUT VARCHAR2);
	--删除批量暂停
  PROCEDURE DELETE_BATCH_PAUSE(P_BATCH_PAUSE_ID IN VARCHAR2,
                               P_FLAG           OUT VARCHAR2,
                               P_MSG            OUT VARCHAR2);
  	--更新批量暂停
  PROCEDURE UPDATE_BATCH_PAUSE(P_BATCH_PAUSE_ID IN VARCHAR2,
                               P_MSCOURIER_ID   IN VARCHAR2,
                               P_PAUSE_REASON   IN VARCHAR2,
                               P_PAUSE_FROM     IN VARCHAR2,
                               P_RECOVERY_DATE  IN VARCHAR2,
                               P_CREATED_BY     IN VARCHAR2,
                               P_FLAG           OUT VARCHAR2,
                               P_MSG            OUT VARCHAR2);
end CUX_IMPORT_BATCH_PAUSE_PKG;
/

