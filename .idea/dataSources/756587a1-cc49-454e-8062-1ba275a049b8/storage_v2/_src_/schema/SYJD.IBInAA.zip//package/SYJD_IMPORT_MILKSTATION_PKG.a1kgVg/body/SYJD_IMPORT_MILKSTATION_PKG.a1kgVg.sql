create PACKAGE BODY syjd_import_milkstation_pkg IS
  PROCEDURE syjd_import_milkstation is
    cursor c_temp_milk_station is
      select * from temp_milk_station;

    cursor cur_jz_station is
      select ms.id milk_station_id, ms1.id jz_milk_station_id
        from temp_milk_station tms, milk_station ms, milk_station ms1
       where tms.milk_station_name = ms.milk_station_name
         and tms.jz_belong_to_name = ms1.milk_station_name;
    cursor cur_receiver_jz_station is
      select ms.id milk_station_id, ms1.id jz_milk_station_id
        from temp_milk_station tms, milk_station ms, milk_station ms1
       where tms.milk_station_name = ms.milk_station_name
         and tms.receive_jz_name = ms1.milk_station_name;
    var_jz_station   cur_jz_station%rowtype;
    v_milkstation_id number;
  begin
    --先删除原奶站的数据
    delete from milk_station;
    COMMIT;
    FOR v_temp_milk_station in c_temp_milk_station loop
      begin
        select get_primary_id('MILK_STATION')
          into v_milkstation_id
          from dual;
        insert into milk_station
          (ID,
           DEALERS_ID,
           MILK_STATION_CODE,
           MILK_STATION_NAME,
           MANAGER,
           TEL_NUMBER,
           AREA_ID,
           DETAILED_ADDRESS,
           LONGITUDE,
           LATITUDE,
           STATUS,
           JZ_FLAG,
           CREDIT_SCORE,
           LAST_UPDATE_DATE,
           LAST_UPDATED_BY,
           CREATION_DATE,
           CREATED_BY,
           PROVINCE_ID,
           CITY_ID,
           JZ_BELONG_TO,
           PRICE_ID,
           PRINT_ZONE,
           DELIVERY_LINE,
           POI_UID,
           POI_TITLE,
           SALESMAN_ID,
           ONE_OFF_DISTRIBUTION,
           SALESMAN_NAME,
           QR_MILKSTATION_CODE,
           NAME_FOR_SHORT,
           LOGISTICS,
           DRIVEWAY,
           DRIVE_TIMES,
           BILL,
           LogisticFeePayer,
           old_dealers_name,
           Permissions_on_the_tree)
        values
          (v_milkstation_id,
           v_temp_milk_station.DEALERS_ID,
           'NZ' || MILK_STATION_S.NEXTVAL,
           v_temp_milk_station.MILK_STATION_NAME,
           v_temp_milk_station.MANAGER,
           v_temp_milk_station.TEL_NUMBER,
           v_temp_milk_station.AREA_ID,
           v_temp_milk_station.DETAILED_ADDRESS,
           v_temp_milk_station.LONGITUDE,
           v_temp_milk_station.LATITUDE,
           'NEW',
           v_temp_milk_station.JZ_FLAG,
           '100',
           SYSDATE,
           -1,
           SYSDATE,
           -1,
           v_temp_milk_station.PROVINCE_ID,
           v_temp_milk_station.CITY_ID,
           v_temp_milk_station.JZ_BELONG_TO,
           v_temp_milk_station.PRICE_ID,
           v_temp_milk_station.PRINT_ZONE,
           v_temp_milk_station.DELIVERY_LINE,
           v_temp_milk_station.POI_UID,
           v_temp_milk_station.POI_TITLE,
           (select id
              from salesman
             where name = v_temp_milk_station.SALESMAN_NAME),
           '',
           v_temp_milk_station.SALESMAN_NAME,
           v_temp_milk_station.QR_MILKSTATION_CODE,
           v_temp_milk_station.NAME_FOR_SHORT,
           v_temp_milk_station.LOGISTICS,
           v_temp_milk_station.DRIVEWAY,
           v_temp_milk_station.DRIVE_TIMES,
           v_temp_milk_station.BILL,
           v_temp_milk_station.LogisticFeePayer,
           v_temp_milk_station.old_dealers_name,
           v_temp_milk_station.Permissions_on_the_tree);
        update temp_milk_station tms
           set tms.flag = 'Y'
         where tms.milk_station_name = tms.milk_station_name;
        --插入用户 分配权限
        /* if v_temp_milk_station.tel_number is not null then
          insert_fnd_users(v_temp_milk_station.tel_number,
                           v_temp_milk_station.manager,
                           v_milkstation_id);
        end if;*/
        /*exception
        when others then
          update temp_milk_station tms
             set tms.flag = 'E'
           where tms.milk_station_name = tms.milk_station_name;*/
      end;
      commit;
    end loop;
    --将基站信息更新
    for var_jz_station in cur_jz_station loop
      update milk_station ms
         set ms.jz_belong_to = var_jz_station.jz_milk_station_id,
             jz_flag         = 'Y'
       where ms.id = var_jz_station.milk_station_id;
      commit;
    end loop;
    update milk_station ms set jz_flag = 'N' where jz_belong_to is null;
    commit;
    for var_receiver_jz_station in cur_receiver_jz_station loop
      update milk_station ms
         set ms.receive_jz_id = var_receiver_jz_station.jz_milk_station_id
       where ms.id = var_receiver_jz_station.milk_station_id;
      commit;
    end loop;
  end;

  --插入用户 分配权限
  procedure insert_fnd_users(p_mobilephone    in varchar2,
                             p_name           in varchar2,
                             p_milkstation_id in number) is
    v_user_id   number;
    v_error_msg varchar2(120);
  begin
    select fnd_user_s.nextval into v_user_id from dual;
    --新增用户
    insert into fnd_users
      (user_id,
       user_code,
       user_type,
       login_username,
       login_password,
       start_date,
       mobilephone,
       last_update_date,
       last_updated_by,
       created_by,
       CREATION_DATE,
       status,
       name)
    values
      (v_user_id,
       LPAD(v_user_id, 7, 0),
       'MILK_STATION',
       p_mobilephone,
       '25F9E794323B453885F5181F1B624D0B', --默认密码为采用MD5加密后的 1-9数字
       sysdate,
       p_mobilephone,
       sysdate,
       -1,
       -1,
       sysdate,
       'VALID',
       p_name);
    --新增用户权限
    insert into fnd_user_assess_auth
      (id,
       version,
       user_id,
       milk_station_id,
       ms_courier_id,
       created_by,
       last_updated_by,
       auth_type,
       createddate,
       lastmodifieddate,
       VALID_FLAG)
    values
      (get_primary_id('fnd_user_assess_auth'),
       0,
       v_user_id,
       p_milkstation_id,
       -1,
       -1,
       -1,
       'INCLUDE',
       sysdate,
       sysdate,
       'Y');
    commit;
  exception
    when others then
      v_error_msg := '错误信息：' || sqlerrm;
      --dbms_output.put_line(v_error_msg);
  end;

  /*PROCEDURE syjd_import_DEALER IS
    cursor c_temp_DEALERS is
      select * from temp_DEALERS;
    v_errormessage varchar2(200);
  begin
    --先删除数据
    delete from DEALERS;
    COMMIT;
    FOR v_temp_DEALERS in c_temp_DEALERS loop
      BEGIN
        INSERT INTO DEALERS
          (ID,
           DEALERS_CODE,
           DEALERS_NAME,
           CHANNEL,
           SOURCE,
           STATUS,
           ABBREVIATION,
           attribute2,
           attribute1)
        VALUES
          (GET_PRIMARY_ID('DEALERS'),
           v_temp_DEALERS.Dealers_Code,
           v_temp_DEALERS.DEALERS_NAME,
           (SELECT LOOKUP_CODE
              FROM FND_LOOKUP_VALUES
             WHERE LOOKUP_TYPE = 'DEALERS_CHANNEL'
               AND MEANING = v_temp_DEALERS.ATTRIBUTE2),
           (CASE
             WHEN v_temp_DEALERS.DEALERS_NAME like '%线下%' THEN
              'OFFLINE'
             ELSE
              'ONLINE'
           END),
           'NEW',
           v_temp_DEALERS.ABERVIATION,
           v_temp_DEALERS.attribute2,
           v_temp_DEALERS.Contactor);
        UPDATE temp_DEALERS
           SET ATTRIBUTE1 = 'Y', ATTRIBUTE3 = ''
         WHERE Dealers_Code = v_temp_DEALERS.Dealers_Code;
      exception
        when others then
          v_errormessage := '错误信息:' || sqlerrm;
          UPDATE temp_DEALERS
             SET ATTRIBUTE1 = 'N', ATTRIBUTE3 = v_errormessage
           WHERE Dealers_Code = v_temp_DEALERS.Dealers_Code;
      end;
      commit;
    end loop;
  end;*/

  --将奶站关联上线上经销商
  PROCEDURE dealers_for_milkstation IS
    cursor t_milkstation is
      select * from milk_station;
    error_message varchar2(255);
  begin
    for v_milkstation in t_milkstation loop
      begin
        --线上
       insert into milk_station_line
          (id,
           header_id,
           dealers_id,
           price_list_id,
           status,
           createddate,
           lastmodifieddate,
           created_by,
           last_updated_by,
           milk_station_line_code,
           erp_error_message)
        values
          (GET_PRIMARY_ID('MILK_STATION_LINE'),
           v_milkstation.ID,
           (SELECT ID
              FROM DEALERS
             WHERE dealers_code =
                   (SELECT online_dealer_name
                      FROM TEMP_MILK_STATION t
                     WHERE t.MILK_STATION_NAME =
                           v_milkstation.milk_station_name)
               and source = 'ONLINE'),
           (SELECT ID
              FROM PRICE_LIST_HEADERS
             WHERE PRICE_NAME =
                   (SELECT ONLINE_PRICE
                      FROM TEMP_MILK_STATION
                     WHERE MILK_STATION_NAME =
                           v_milkstation.milk_station_name)),
           'NEW',
           SYSDATE,
           SYSDATE,
           '-1',
           '-1',
           'NZ' || substr(v_milkstation.milk_station_code, 3) || '001',
           null);
           insert into milk_station_line
          (id,
           header_id,
           dealers_id,
           price_list_id,
           status,
           createddate,
           lastmodifieddate,
           created_by,
           last_updated_by,
           milk_station_line_code,
           erp_error_message)
        values
          (GET_PRIMARY_ID('MILK_STATION_LINE'),
           v_milkstation.ID,
           (SELECT ID
              FROM DEALERS
             WHERE dealers_code =
                   (SELECT dealer_name
                      FROM TEMP_MILK_STATION t
                     WHERE t.MILK_STATION_NAME =
                           v_milkstation.milk_station_name)
               and source = 'OFFLINE'),
           (SELECT ID
              FROM PRICE_LIST_HEADERS
             WHERE PRICE_NAME =
                   (SELECT PRICE_ID
                      FROM TEMP_MILK_STATION
                     WHERE MILK_STATION_NAME =
                           v_milkstation.milk_station_name)),
           'NEW',
           SYSDATE,
           SYSDATE,
           '-1',
           '-1',
           'NZ' || substr(v_milkstation.milk_station_code, 3) || '002',
           null);
      UPDATE temp_milk_station
             SET error_message = 'Y'
           WHERE milk_station_name = v_milkstation.milk_station_name;
      exception
        when others then
          error_message := '错误信息:' || sqlerrm;
          UPDATE temp_milk_station
             SET error_message = error_message
           WHERE milk_station_name = v_milkstation.milk_station_name;
      end;
    end loop;
  end;
  
  --从中间表导入POI
  procedure import_poi is 
    cursor v_temp is
    select * from temp_poi;
    error_message varchar2(1000);
    v_count number;
    begin
      for t_temp in v_temp loop
        begin
          select count(1) into v_count
          from milk_station where milk_station_code = t_temp.milkstationcode;
          if v_count = 0 then
             insert into errmessage
                    (err_message)
                    values
                    ('奶站编码无对应奶站'||t_temp.milkstationcode);
                    else
        insert into poi_address_base(
                   id,
                  poi_uid,
                  poi_title,
                  poi_address,
                  poi_lat,
                  poi_lng,
                  province_name,
                  city_name,
                  district_name,
                  milkstation_id,
                  creation_date,
                  created_by,
                  last_update_date,
                  last_updated_by,
                  province_id,
                  city_id,
                  area_id)
                  values(
                  GET_PRIMARY_ID('poi_address_base'),
                  t_temp.poiuid,
                  t_temp.poititle,
                  t_temp.poiaddress,
                  t_temp.poilat,
                  t_temp.poilng,
                  '北京市',
                  '市辖区',
                  t_temp.area,
                  (select id from milk_station where milk_station_code = t_temp.milkstationcode),
                  sysdate,
                  '-1',
                  sysdate,
                  '-1',
                  '1',
                  '2',
                 ''
                  );
                   end if;  
                  exception when others then
                     error_message := '错误信息:' || sqlerrm;
                    insert into errmessage
                    (err_message)
                    values
                    (error_message);
                  
        end;
       commit;
        end loop;
      end;

end syjd_import_milkstation_pkg;
/

