create package cux_update_username is

  -- Author  : C254462
  -- Created : 2018/3/19 9:47:30
  -- Purpose : cux_update_username
  
procedure update_username;


end cux_update_username;
/

