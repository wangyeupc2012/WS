create function validate_auth_test(p_user_id in number, 
                                                                     p_milk_station_id in number) return varchar2 is
    x_return_result varchar2(10) := 'Y';
    x_count         number := 0;
		v_fnd_user_assess_auth fnd_user_assess_auth%rowtype;
begin
	select * 
	into v_fnd_user_assess_auth
	from fnd_user_assess_auth fuaa
	where fuaa.user_id = p_user_id;
	
	select count(*)
	into x_count
	from v_fnd_user_assess_auth vfuaa
	where vfuaa.milk_station_id = p_milk_station_id
	and vfuaa.auth_type = 'INCLUDE';
	if x_count >0 then
		x_return_result:='Y';
		else
	  x_return_result:='N';
	end if;
	
  return x_return_result;
	exception
		when others then
			return 'N';
end validate_auth_test;
/

