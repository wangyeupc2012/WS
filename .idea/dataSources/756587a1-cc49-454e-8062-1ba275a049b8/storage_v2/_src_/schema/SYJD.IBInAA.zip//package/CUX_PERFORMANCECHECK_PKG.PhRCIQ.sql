create package cux_performancecheck_pkg is
  procedure load_saletask;
  procedure load_performance(p_yearnum         number,
                             p_milk_station_id number,
                             p_dealer_name     varchar2);
  FUNCTION getperformance(p_milk_station_id number,
                          p_yearnum         number,
                          p_monthnum        number) RETURN number;
  function getdealerid(p_id number) return number;
end cux_performancecheck_pkg;
/

