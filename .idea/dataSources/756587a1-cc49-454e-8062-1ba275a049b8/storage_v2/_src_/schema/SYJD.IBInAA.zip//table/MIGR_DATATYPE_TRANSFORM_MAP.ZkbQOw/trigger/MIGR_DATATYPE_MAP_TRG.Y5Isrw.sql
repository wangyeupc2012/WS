create trigger MIGR_DATATYPE_MAP_TRG
  before insert or update
  on MIGR_DATATYPE_TRANSFORM_MAP
  for each row
  BEGIN
  if inserting and :new.id is null then
        :new.id := MD_META.get_next_id;
    end if;
END;
/

