create package body crm_data_initialize_pkg is
  PROCEDURE crm_data_initialize is
     v_errormessage varchar2(200);
     begin
        begin
     --删除订单，配送单
        DELETE FROM ORDERITEM;
        DELETE FROM ORDERSHIPPING;
        DELETE FROM ORDERSHIPPINGITEM;
        DELETE FROM ORDER_PAUSE_INTERVAL;
        DELETE FROM ORDER_PROMOTION;
        DELETE FROM API_RECORD;
        DELETE FROM ORDERLOG;
        DELETE FROM ORDERREFUNDS;
        DELETE FROM ORDERS;

   exception
    when others then
      v_errormessage := '错误信息:'||sqlerrm;
      saveErrorMessage('orders',v_errormessage);
   end;
   begin
     --删除物料中间表
      delete from mtl_system_items_temp;
   exception
    when others then
      v_errormessage := '错误信息:'||sqlerrm;
      saveErrorMessage('mtl_system_items_temp',v_errormessage);
   end;
   begin 
     --删除物料表 
      delete from PROMOTION_SKU;
      delete from PRODUCT_STOREPRODUCTTAG;
      delete from PRODUCT_PROMOTION;
      delete from PRODUCT_PRODUCTTAG;
      delete from CONSULTATION;
      delete from review;
      delete from PRODUCTFAVORITE;
      DELETE FROM STOCKLOG;
      delete from sku;
      delete from product; 
   exception
    when others then
       v_errormessage := '错误信息:'||sqlerrm;
      saveErrorMessage('product',v_errormessage);
  end;
    
  begin
    --删除价目行表中间表
      delete from qp_list_lines_temp;
  exception
    when others then
       v_errormessage := '错误信息:'||sqlerrm;
      saveErrorMessage('qp_list_lines_temp',v_errormessage);
  end;
     
  begin
    --删除价目头表中间表
      delete from p_secu_list_headers_temp;
  exception
    when others then
      v_errormessage := '错误信息:'||sqlerrm;
      saveErrorMessage('p_secu_list_headers_temp',v_errormessage);
  end;
  
  begin
    --删除价目头表
      delete from price_list_headers;
  exception
    when others then
       v_errormessage := '错误信息:'||sqlerrm;
      saveErrorMessage('price_list_headers',v_errormessage);
  end;
  
  begin
    --删除价目行表
      delete from price_list_lines;
  exception
    when others then
       v_errormessage := '错误信息:'||sqlerrm;
      saveErrorMessage('price_list_lines',v_errormessage);
  end;
  
  begin
    --删除经销商
      delete from dealers;
  exception
    when others then
      v_errormessage := '错误信息:'||sqlerrm;
      saveErrorMessage('price_list_lines',v_errormessage);
  end;
  
  begin
    --删除奶站
      delete from milk_station;
  exception 
    when others then
       v_errormessage := '错误信息:'||sqlerrm;
      saveErrorMessage('milk_station',v_errormessage);
  end;
  
  begin
    --删除配送员
      delete from ms_courier;
  exception
    when others then
      v_errormessage := '错误信息:'||sqlerrm;
      saveErrorMessage('ms_courier',v_errormessage);
  end;
  
  begin
    --删除会员
      delete from receiver;
      delete from CARTITEM;
      delete from CART;
      DELETE from POINTLOG;
      delete from message;
      delete from COUPONCODE;
      delete from member;
  exception
    when others then
      v_errormessage := '错误信息:'||sqlerrm;
      saveErrorMessage('member',v_errormessage);
  end;
  
  begin
    --删除会员等级
      delete from PROMOTION_MEMBERRANK;
      delete from appmember;
      delete from memberrank;
  exception
    when others then
      v_errormessage := '错误信息:'||sqlerrm;
      saveErrorMessage('memberrank',v_errormessage);
  end;
  
  begin
    --删除POI地址库
      delete from poi_address_base;
  exception
    when others then
      v_errormessage := '错误信息:'||sqlerrm;
      saveErrorMessage('poi_address_base',v_errormessage);
  end;
  
  begin
    --删除销售员
    delete from salesman;
  exception
    when others then
      v_errormessage := '错误信息:'||sqlerrm;
      saveErrorMessage('poi_address_base',v_errormessage);
  end;
  
  begin
    --删除用户
      delete from fnd_users WHERE USER_ID <>'1';
      DELETE FROM FND_USER_ASSESS_AUTH;
  exception
    when others then
       v_errormessage := '错误信息:'||sqlerrm;
      saveErrorMessage('fnd_users',v_errormessage);
  end ;
   commit;
	end;
	
  PROCEDURE saveErrorMessage(tablename in varchar2,errormessage in varchar2) is
      begin
       insert into initialize_data_message
        (tablename,
         created_by,
         createddate,
         lastupdated_by,
         lastupdatedate)
      values
        (tablename, '-1', sysdate, '-1', sysdate);
      commit;
      end;
     
end crm_data_initialize_pkg;
/

