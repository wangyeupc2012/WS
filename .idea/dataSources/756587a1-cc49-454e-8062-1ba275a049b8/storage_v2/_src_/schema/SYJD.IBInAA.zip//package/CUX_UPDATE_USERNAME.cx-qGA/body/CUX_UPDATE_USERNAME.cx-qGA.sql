create package body cux_update_username is

procedure update_username is
  cursor cur_user is select * from fnd_users;
  begin
    for var_user in cur_user loop
    if var_user.user_type='MILK_STATION' then
    update fnd_users set user_name=(select distinct manager from MILK_STATION where TEL_NUMBER=var_user.MOBILEPHONE)
    where MOBILEPHONE=var_user.MOBILEPHONE;
    elsif  var_user.user_type = 'SALESMAN' then
    update fnd_users set user_name=(select distinct NAME from SALESMAN where PHONE=var_user.MOBILEPHONE)
    where MOBILEPHONE=var_user.MOBILEPHONE;
    elsif var_user.user_type = 'MS_COURIER' then
    update fnd_users set user_name=(select distinct MS_COURIER_NAME from MS_COURIER where TEL_NUMBER=var_user.MOBILEPHONE)
    where MOBILEPHONE=var_user.MOBILEPHONE; 
    end if;
      end loop;
   end;
end cux_update_username;
/

