create package cux_erp_syjd_pkg is

  -- Author  : YUCHAO
  -- Created : 2017/7/29 AM 9:42:47
  -- Purpose : 
  
 function import_items(p_type varchar2,
                       p_items_id number)return varchar2;

end cux_erp_syjd_pkg;
/

