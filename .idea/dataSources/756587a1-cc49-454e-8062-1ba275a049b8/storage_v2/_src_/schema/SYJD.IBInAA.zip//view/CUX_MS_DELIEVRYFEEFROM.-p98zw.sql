create view CUX_MS_DELIEVRYFEEFROM as
  SELECT  d.DEALERS_NAME dealer_name,
                        ms.MILK_STATION_NAME,
                        o.sn,
                        flv.attribute1,
                        p.sn product_sn,
                        p.qrname qrname,
                        sum(distinct osi.QUANTITY) shipping_quantity,
                        os.SHIPPING_DATE,
                        sum(PL.QUANTITY *
                                            (nvl(pll.MILK_STATION_SHIPPING_FEE,
                                                 0) +
                                            nvl(pll.MS_COURIER_SHIPPING_FEE, 0))) delivery_price,
                        sum((SELECT ott.quantity
                              FROM ORDERS od, ORDERITEM ott
                             WHERE ott.ORDERS = od.id
                               AND od.TYPE = 2
                               AND ott.UNDERTAKER = 3
                               AND ott.id = ot.ID)) * ot.price charge_back
          FROM ORDERSHIPPINGITEM  osi,
               ORDERS             o,
               ORDERITEM          ot,
               ORDERSHIPPING      os,
               product            p,
               MILK_STATION       ms,
               MILK_STATION_LINE  msl,
               DEALERS            d,
               PRICE_LIST_HEADERS plh,
               PRICE_LIST_LINES   pll,
               FND_LOOKUP_VALUES  flv,
               PRODUCTCOMBO_LINE  PL
         WHERE os.ORDERS = o.ID
           AND ot.ORDERS = o.id
           AND os.ID = osi.ORDERSHIPPING_ID
           AND p.sn = osi.SN
           AND o.MILK_STATION_ID = ms.ID
           AND msl.HEADER_ID = ms.ID
           AND msl.DEALERS_ID = d.ID
           AND msl.PRICE_LIST_ID = plh.ID
           AND pll.HEADER_ID = plh.ID
           AND  PL.PRODUCT_ID = pll.PRODUCT_ID
           AND plh.TYPE = flv.ATTRIBUTE1
           AND osi.orderitemid = ot.id
           AND flv.LOOKUP_TYPE = 'ORDER_FROM'
           AND flv.LOOKUP_CODE = o.ORDER_FROM
           AND flv.ATTRIBUTE1 = d.SOURCE
           AND os.STATUS = 'VALID'
           AND FND_UTIL.CRM_VALIDATE_AUTH(1, ms.ID) = 'Y'
           and PL.COMBO_HEADER_ID = p.ID
           --and o.sn = 'JD20180526193757088500'
           --and ms.milk_station_name like '%秦浩北苑2分站%'
            --and d.dealers_name ='三区线上'
           --AND os.SHIPPING_DATE >= to_date('2018-05-29','yyyy-mm-dd hh24:mi:ss')
           --AND os.SHIPPING_DATE <= to_date('2018-05-29','yyyy-mm-dd hh24:mi:ss')
         GROUP BY p.sn,
                  o.sn,
                  p.QRNAME,
                  ot.PRICE,
                  os.SHIPPING_DATE,
                  ms.MILK_STATION_NAME,
                  d.DEALERS_NAME,
                  pll.MILK_STATION_SHIPPING_FEE,
                  pll.MS_COURIER_SHIPPING_FEE,
                   flv.attribute1

                  union all
            --普通商品
            SELECT  d.DEALERS_NAME dealer_name,
                        ms.MILK_STATION_NAME,
                        o.sn,
                         flv.attribute1,
                        p.sn product_sn,
                        p.qrname qrname,
                        sum(osi.QUANTITY) shipping_quantity,
                        os.SHIPPING_DATE,
                        (nvl(pll.MILK_STATION_SHIPPING_FEE, 0) +
                        nvl(pll.MS_COURIER_SHIPPING_FEE, 0)) delivery_price,
                        sum((SELECT ott.quantity
                              FROM ORDERS od, ORDERITEM ott
                             WHERE ott.ORDERS = od.id
                               AND od.TYPE = 2
                               AND ott.UNDERTAKER = 3
                               AND ott.id = ot.ID)) * ot.price charge_back
          FROM ORDERSHIPPINGITEM  osi,
               ORDERS             o,
               ORDERITEM          ot,
               ORDERSHIPPING      os,
               product            p,
               MILK_STATION       ms,
               MILK_STATION_LINE  msl,
               DEALERS            d,
               PRICE_LIST_HEADERS plh,
               PRICE_LIST_LINES   pll,
               FND_LOOKUP_VALUES  flv
         WHERE os.ORDERS = o.ID
           AND ot.ORDERS = o.id
           AND os.ID = osi.ORDERSHIPPING_ID
           AND p.sn = osi.SN
           AND o.MILK_STATION_ID = ms.ID
           AND msl.HEADER_ID = ms.ID
           AND msl.DEALERS_ID = d.ID
           AND msl.PRICE_LIST_ID = plh.ID
           AND pll.HEADER_ID = plh.ID
           AND p.id = pll.PRODUCT_ID
           AND plh.TYPE = flv.ATTRIBUTE1
           AND osi.orderitemid = ot.id
           AND flv.LOOKUP_TYPE = 'ORDER_FROM'
           AND flv.LOOKUP_CODE = o.ORDER_FROM
           AND flv.ATTRIBUTE1 = d.SOURCE
           AND os.STATUS = 'VALID'
           AND FND_UTIL.CRM_VALIDATE_AUTH(1, ms.ID) = 'Y'
           --and o.sn = 'JD20180526193757088500'
           --and ms.milk_station_name like '%秦浩北苑2分站%'
            --and d.dealers_name ='三区线上'
           --AND os.SHIPPING_DATE >= to_date('2018-05-29','yyyy-mm-dd hh24:mi:ss')
          -- AND os.SHIPPING_DATE <= to_date('2018-05-29','yyyy-mm-dd hh24:mi:ss')

         GROUP BY
                  o.sn,
                  p.sn,
                  p.QRNAME,
                  ot.PRICE,
                  os.SHIPPING_DATE,
                  ms.MILK_STATION_NAME,
                  d.DEALERS_NAME,
                  pll.MILK_STATION_SHIPPING_FEE,
                  pll.MS_COURIER_SHIPPING_FEE,
                   flv.attribute1
         ORDER BY MILK_STATION_NAME
/

