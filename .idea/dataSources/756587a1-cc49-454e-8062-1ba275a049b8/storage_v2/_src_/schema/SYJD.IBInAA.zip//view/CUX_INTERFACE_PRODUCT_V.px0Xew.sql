create view CUX_INTERFACE_PRODUCT_V as
  select
        p.id,
        p.sn,
        p.name ,
        p.type,
        p.lastmodifieddate,
        p.unit,
        decode(p.isdailydistribution,1,1000,0)            stock,
        decode(p.isdailydistribution,1,1,0)           isStock,
        p.type       typeText,
        p.weight,
        b.ID         brand,
        pt.ID
        productCategory,
        p.barcode,
        pri.price_zd marketprice
        FROM PRODUCT p,
        BRAND b,
        PRODUCTCATEGORY pt,
        (select pll.price_zd, pll.product_id
        from PRICE_LIST_HEADERS plh, PRICE_LIST_LINES pll
        where plh.id = pll.header_id
        and plh.attribute1(+) = 'ONLINE') pri
        where p.brand_id = b.id(+)
        and p.productcategory_id = pt.id(+)
        and p.id = pri.product_id(+)
        and p.sn not like '%TC%'
        union all
       select   p.id,
                p.sn,
                p.name ,
                p.type,
                p.lastmodifieddate,
                p.unit,
                decode(p.isdailydistribution,1,1000,0)            stock,
                decode(p.isdailydistribution,1,1,0)           isStock,
                p.type       typeText,
                p.weight,
                null         brand,
               null
               productCategory,
                p.barcode,
               p.tc_totalprice marketprice
                from product p
                where p.sn like '%TC%'
/

