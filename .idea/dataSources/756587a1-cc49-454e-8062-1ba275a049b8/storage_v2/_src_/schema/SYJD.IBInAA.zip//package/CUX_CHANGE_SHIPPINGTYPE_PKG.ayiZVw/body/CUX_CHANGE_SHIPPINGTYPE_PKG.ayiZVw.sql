create package body CUX_CHANGE_SHIPPINGTYPE_PKG is

  PROCEDURE CHANGE_SHIPPING_TYPE(P_ORDERITEM_ID  IN VARCHAR2,
                                 P_CHANGE_DATE   IN VARCHAR2,
                                 P_SHIPPING_TYPE IN NUMBER,
                                 P_ORI_SHIP_TYPE IN NUMBER,
                                 P_CREATED_BY    IN NUMBER,
                                 P_FLAG          OUT VARCHAR2,
                                 P_MSG           OUT VARCHAR2) IS
    CURSOR CUR_ORDERITEM IS
      SELECT * FROM ORDERITEM OI WHERE OI.ID = P_ORDERITEM_ID;
    CURSOR CUR_PAUSE IS
      SELECT *
        FROM ORDER_PAUSE_INTERVAL OPI
       WHERE OPI.ORDERITEM_ID = P_ORDERITEM_ID
         AND OPI.PAUSE_DATE_FROM >= TO_DATE(P_CHANGE_DATE, 'yyyy-MM-dd')
       ORDER BY OPI.PAUSE_DATE_FROM ASC;
    VAR_ORDERITEM        CUR_ORDERITEM%ROWTYPE;
    VAR_PAUSE            CUR_PAUSE%ROWTYPE;
    VAR_CHANGE_DATE      DATE := TO_DATE(P_CHANGE_DATE, 'yyyy-MM-dd');
    VAR_ORDER_FROM       DATE;
    VAR_ORDER_TO         DATE;
    VAR_DAYS             NUMBER;
    VAR_ALREADY_DAYS     NUMBER := 0;
    VAR_PAUSE_CNT        NUMBER;
    VAR_HOLIDAY_CNT      NUMBER;
    VAR_WEEK             VARCHAR2(20);
    VAR_CONTINUE_DAYS    NUMBER;
    VAR_NUM              NUMBER := 0;
    VAR_NEW_PAUSE_CNT    NUMBER;
    VAR_NEW_DATE_TO      DATE;
    VAR_NEW_ORDERITEM_ID NUMBER;
    VAR_MAX_LINE_COUNT   NUMBER;
  BEGIN
    SELECT OI.ORDER_DATE_FROM, OI.ORDER_DATE_TO, OI.ORDER_DAYS
      INTO VAR_ORDER_FROM, VAR_ORDER_TO, VAR_DAYS
      FROM ORDERITEM OI
     WHERE OI.ID = P_ORDERITEM_ID;
    --计算从起始 到更换日期前一天 按照原配送类型共配送几天
    IF P_ORI_SHIP_TYPE = 0 THEN
      --VAR_ALREADY_DAYS := VAR_CHANGE_DATE - VAR_ORDER_FROM;
      --判断每一天是否在暂停区间内
      WHILE VAR_ORDER_FROM < VAR_CHANGE_DATE LOOP
        SELECT COUNT(1)
          INTO VAR_PAUSE_CNT
          FROM ORDER_PAUSE_INTERVAL OPI
         WHERE OPI.ORDERITEM_ID = P_ORDERITEM_ID
           AND VAR_ORDER_FROM >= OPI.PAUSE_DATE_FROM
           AND VAR_ORDER_FROM < OPI.RECOVERY_DATE;
        IF VAR_PAUSE_CNT = 0 THEN
          VAR_ALREADY_DAYS := VAR_ALREADY_DAYS + 1;
        END IF;
        VAR_ORDER_FROM := VAR_ORDER_FROM + 1;
      END LOOP;
    ELSIF P_ORI_SHIP_TYPE = 1 THEN
      WHILE VAR_ORDER_FROM < VAR_CHANGE_DATE LOOP
        --判断每一天是否在暂停区间内 是否是周末、节假日
        SELECT COUNT(1)
          INTO VAR_PAUSE_CNT
          FROM ORDER_PAUSE_INTERVAL OPI
         WHERE OPI.ORDERITEM_ID = P_ORDERITEM_ID
           AND VAR_ORDER_FROM >= OPI.PAUSE_DATE_FROM
           AND VAR_ORDER_FROM < OPI.RECOVERY_DATE;
        IF VAR_PAUSE_CNT = 0 THEN
          SELECT COUNT(1)
            INTO VAR_HOLIDAY_CNT
            FROM HOLIDAY HO
           WHERE HO.HOLIDAY_DATE = VAR_ORDER_FROM;
          SELECT TO_CHAR(VAR_ORDER_FROM, 'DAY') INTO VAR_WEEK FROM DUAL;
          IF VAR_HOLIDAY_CNT = 0 AND VAR_WEEK <> '星期六' AND
             VAR_WEEK <> '星期日' THEN
            VAR_ALREADY_DAYS := VAR_ALREADY_DAYS + 1;
          END IF;
          VAR_ORDER_FROM := VAR_ORDER_FROM + 1;
        END IF;
      END LOOP;
    END IF;
  
    DBMS_OUTPUT.put_line('ALREADY_DAYS' || VAR_ALREADY_DAYS);
    VAR_CONTINUE_DAYS := VAR_DAYS - VAR_ALREADY_DAYS;
    DBMS_OUTPUT.put_line('VAR_CONTINUE_DAYS' || VAR_CONTINUE_DAYS);
    --计算新订单行的终止日期 起始日期为VAR_CHANGE_DATE
    VAR_NEW_DATE_TO := VAR_CHANGE_DATE;
    WHILE VAR_NUM < VAR_CONTINUE_DAYS LOOP
      IF P_SHIPPING_TYPE = 0 THEN
        DBMS_OUTPUT.put_line('每日配送' || VAR_NEW_DATE_TO || '实际配送天数' ||
                             VAR_NUM);
        --判断每一天是否在原始暂停区间内
        SELECT COUNT(1)
          INTO VAR_NEW_PAUSE_CNT
          FROM ORDER_PAUSE_INTERVAL OPI
         WHERE OPI.ORDERITEM_ID = P_ORDERITEM_ID
           AND VAR_NEW_DATE_TO >= OPI.PAUSE_DATE_FROM
           AND VAR_NEW_DATE_TO < OPI.RECOVERY_DATE;
        IF VAR_NEW_PAUSE_CNT = 0 THEN
          VAR_NUM := VAR_NUM + 1;
        END IF;
        IF VAR_NUM < VAR_CONTINUE_DAYS THEN
          VAR_NEW_DATE_TO := VAR_NEW_DATE_TO + 1;
        END IF;
      
      ELSIF P_SHIPPING_TYPE = 1 THEN
        DBMS_OUTPUT.put_line('工作日配送' || VAR_NEW_DATE_TO || '实际配送天数' ||
                             VAR_NUM);
        SELECT COUNT(1)
          INTO VAR_NEW_PAUSE_CNT
          FROM ORDER_PAUSE_INTERVAL OPI
         WHERE OPI.ORDERITEM_ID = P_ORDERITEM_ID
           AND VAR_NEW_DATE_TO >= OPI.PAUSE_DATE_FROM
           AND VAR_NEW_DATE_TO < OPI.RECOVERY_DATE;
        IF VAR_NEW_PAUSE_CNT = 0 THEN
          --判断是否是节假日 是否是周末
          SELECT COUNT(1)
            INTO VAR_HOLIDAY_CNT
            FROM HOLIDAY HO
           WHERE HO.HOLIDAY_DATE = VAR_NEW_DATE_TO;
        
          SELECT TO_CHAR(VAR_NEW_DATE_TO, 'DAY') INTO VAR_WEEK FROM DUAL;
          IF VAR_HOLIDAY_CNT = 0 AND VAR_WEEK <> '星期六' AND
             VAR_WEEK <> '星期日' THEN
            VAR_NUM := VAR_NUM + 1;
          END IF;
        END IF;
        IF VAR_NUM < VAR_CONTINUE_DAYS THEN
          VAR_NEW_DATE_TO := VAR_NEW_DATE_TO + 1;
        END IF;
      END IF;
    END LOOP;
  
    --判断是否是从第一天开始更换配送类型
    IF VAR_ALREADY_DAYS = 0 THEN
      UPDATE ORDERITEM OI
         SET OI.ORDER_DATE_TO = VAR_NEW_DATE_TO,
             --    OI.ORDER_DAYS       = VAR_ALREADY_DAYS,
             OI.LASTMODIFIEDDATE = SYSDATE,
             OI.LAST_UPDATED_BY  = P_CREATED_BY,
             OI.SHIPPING_TYPE    = P_SHIPPING_TYPE
       WHERE OI.ID = P_ORDERITEM_ID;
      FOR VAR_PAUSE IN CUR_PAUSE LOOP
        IF VAR_NEW_DATE_TO < VAR_PAUSE.PAUSE_DATE_FROM THEN
          --删除暂停区间
          DELETE FROM ORDER_PAUSE_INTERVAL OPI WHERE OPI.ID = VAR_PAUSE.ID;
        END IF;
      END LOOP;
      COMMIT;
      P_FLAG := 'Y';
    ELSE
      --更新原订单行配送终止日期为更换日期前一天 配送天数为VAR_ALREADY_DAYS 金额等于VAR_ALREADY_DAYS*ACT_PRICE
      UPDATE ORDERITEM OI
         SET OI.ORDER_DATE_TO    = VAR_CHANGE_DATE - 1,
             OI.ORDER_DAYS       = VAR_ALREADY_DAYS,
             OI.LASTMODIFIEDDATE = SYSDATE,
             OI.QUANTITY         = VAR_ALREADY_DAYS *
                                   OI.DAILY_DELIVERY_QUANTITY
       WHERE OI.ID = P_ORDERITEM_ID;
      --COMMIT;
      --插入新订单行
      VAR_NEW_ORDERITEM_ID := get_primary_id('ORDERITEM');
    
      FOR VAR_ORDERITEM IN CUR_ORDERITEM LOOP
        SELECT MAX(LINE_COUNT)
          INTO VAR_MAX_LINE_COUNT
          FROM ORDERITEM
         WHERE ORDERS = VAR_ORDERITEM.ORDERS;
        INSERT INTO ORDERITEM
          (id,
           createddate,
           lastmodifieddate,
           version,
           commissiontotals,
           isdelivery,
           name,
           price,
           quantity,
           returnedquantity,
           shippedquantity,
           sn,
           specifications,
           thumbnail,
           type,
           weight,
           orders,
           sku_id,
           created_by,
           last_updated_by,
           order_date_from,
           order_date_to,
           order_days,
           daily_delivery_quantity,
           delivery_days,
           remain_days,
           REFUND_STATUS,
           day_shipping_time,
           shipping_type,
           original_order_date_to,
           product_sn,
           PAY_PRICE,
           present_flag,
           TOTALPRICE,
           LINE_COUNT)
        VALUES
          (VAR_NEW_ORDERITEM_ID,
           SYSDATE,
           SYSDATE,
           1,
           0,
           1,
           VAR_ORDERITEM.NAME,
           VAR_ORDERITEM.PRICE,
           VAR_ORDERITEM.DAILY_DELIVERY_QUANTITY * VAR_CONTINUE_DAYS,
           VAR_ORDERITEM.RETURNEDQUANTITY,
           0,
           VAR_ORDERITEM.SN,
           VAR_ORDERITEM.SPECIFICATIONS,
           VAR_ORDERITEM.THUMBNAIL,
           VAR_ORDERITEM.TYPE,
           0,
           VAR_ORDERITEM.ORDERS,
           VAR_ORDERITEM.SKU_ID,
           P_CREATED_BY,
           P_CREATED_BY,
           VAR_CHANGE_DATE,
           VAR_NEW_DATE_TO,
           VAR_CONTINUE_DAYS,
           VAR_ORDERITEM.Daily_Delivery_Quantity,
           0,
           VAR_CONTINUE_DAYS,
           VAR_ORDERITEM.REFUND_STATUS,
           VAR_ORDERITEM.DAY_SHIPPING_TIME,
           P_SHIPPING_TYPE,
           VAR_NEW_DATE_TO,
           VAR_ORDERITEM.PRODUCT_SN,
           VAR_ORDERITEM.PAY_PRICE,
           VAR_ORDERITEM.PRESENT_FLAG,
           VAR_ORDERITEM.TOTALPRICE,
           VAR_MAX_LINE_COUNT + 1);
        COMMIT;
      END LOOP;
      --循环将暂停update到新订单行
      FOR VAR_PAUSE IN CUR_PAUSE LOOP
        IF VAR_CHANGE_DATE <= VAR_PAUSE.PAUSE_DATE_FROM AND
           VAR_NEW_DATE_TO > VAR_PAUSE.PAUSE_DATE_FROM THEN
          UPDATE ORDER_PAUSE_INTERVAL OPI
             SET OPI.ORDERITEM_ID     = VAR_NEW_ORDERITEM_ID,
                 OPI.LAST_UPDATED_BY  = P_CREATED_BY,
                 OPI.LASTMODIFIEDDATE = SYSDATE
           WHERE OPI.ID = VAR_PAUSE.ID;
          COMMIT;
        END IF;
      END LOOP;
      P_FLAG := 'Y';
    END IF;
  
  EXCEPTION
    WHEN OTHERS THEN
      P_FLAG := 'Y';
      P_MSG  := '错误信息：' || SQLERRM;
  END;

  PROCEDURE GET_REFUND_INFO(P_ORDER_ID      IN VARCHAR2,
                            P_ORDERITEM_ID  IN VARCHAR2,
                            P_REFUND_DATE   IN VARCHAR2,
                            P_REFUND_NUM    OUT NUMBER,
                            P_REFUND_AMOUNT OUT NUMBER,
														P_ACT_PRICE     OUT NUMBER,
														P_PRICE         OUT NUMBER,
                            P_FLAG          OUT VARCHAR2,
                            P_MSG           OUT VARCHAR2) IS
    CURSOR CUR_ORDERITEM IS
      SELECT * FROM ORDERITEM OI WHERE OI.ID = P_ORDERITEM_ID;
    VAR_ORDERITEM   CUR_ORDERITEM%ROWTYPE;
    VAR_REFUND_DATE DATE := TO_DATE(P_REFUND_DATE, 'yyyy-MM-dd');
    VAR_NUM         NUMBER := 0;
    VAR_HOLIDAY     NUMBER;
    VAR_WEEK        VARCHAR2(20);
    VAR_PAUSE_CNT   NUMBER;
  BEGIN
    FOR VAR_ORDERITEM IN CUR_ORDERITEM LOOP
      BEGIN
        WHILE VAR_REFUND_DATE <= VAR_ORDERITEM.ORDER_DATE_TO LOOP
          IF VAR_ORDERITEM.SHIPPING_TYPE = 0 THEN
            --判断是否在暂停区间内
            SELECT COUNT(1)
              INTO VAR_PAUSE_CNT
              FROM ORDER_PAUSE_INTERVAL OPI
             WHERE OPI.ORDERITEM_ID = P_ORDERITEM_ID
               AND VAR_REFUND_DATE >= OPI.PAUSE_DATE_FROM
               AND VAR_REFUND_DATE < OPI.RECOVERY_DATE;
            IF VAR_PAUSE_CNT = 0 THEN
              VAR_NUM := VAR_NUM + 1;
            END IF;
          ELSIF VAR_ORDERITEM.SHIPPING_TYPE = 1 THEN
            --判断是否在暂停区间内
            SELECT COUNT(1)
              INTO VAR_PAUSE_CNT
              FROM ORDER_PAUSE_INTERVAL OPI
             WHERE OPI.ORDERITEM_ID = P_ORDERITEM_ID
               AND VAR_REFUND_DATE >= OPI.PAUSE_DATE_FROM
               AND VAR_REFUND_DATE < OPI.RECOVERY_DATE;
            IF VAR_PAUSE_CNT = 0 THEN
              --判断是否是周末、是否是节假日
              SELECT COUNT(1)
                INTO VAR_HOLIDAY
                FROM HOLIDAY HO
               WHERE HO.HOLIDAY_DATE = VAR_REFUND_DATE;
            
              SELECT TO_CHAR(VAR_REFUND_DATE, 'DAY')
                INTO VAR_WEEK
                FROM DUAL;
              IF VAR_HOLIDAY = 0 AND VAR_WEEK <> '星期六' AND
                 VAR_WEEK <> '星期日' THEN
                VAR_NUM := VAR_NUM + 1;
              END IF;
            END IF;
          END IF;
          VAR_REFUND_DATE := VAR_REFUND_DATE + 1;
        END LOOP;
        P_REFUND_NUM := VAR_NUM * VAR_ORDERITEM.DAILY_DELIVERY_QUANTITY;
        IF VAR_ORDERITEM.PAY_PRICE IS NOT NULL THEN
          P_REFUND_AMOUNT := P_REFUND_NUM * VAR_ORDERITEM.PAY_PRICE;
					P_ACT_PRICE     := VAR_ORDERITEM.PAY_PRICE;
					P_PRICE         := VAR_ORDERITEM.PRICE;
        ELSE
          P_REFUND_AMOUNT := P_REFUND_NUM * VAR_ORDERITEM.PRICE;
					P_ACT_PRICE     := VAR_ORDERITEM.PRICE;
					P_PRICE         := VAR_ORDERITEM.PRICE;
        END IF;
      
        P_FLAG := 'Y';
      EXCEPTION
        WHEN OTHERS THEN
          P_FLAG := 'N';
          P_MSG  := '错误信息：' || SQLERRM;
      END;
    END LOOP;
  EXCEPTION
    WHEN OTHERS THEN
      P_FLAG := 'N';
      P_MSG  := '错误信息：' || SQLERRM;
  END;
end CUX_CHANGE_SHIPPINGTYPE_PKG;
/

