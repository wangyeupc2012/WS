create package body CUX_SYNC_TW_DATA is

  procedure import_tw_orders is
  
    v_lock_flag       varchar2(20);
    v_last_sync_date date;
  
  begin
  
    SELECT LOCK_FLAG
      into v_lock_flag
      FROM TW_SYJD_DS_CONFIG
     WHERE TABLE_NAME = 'XX_ORDER';
  
    SELECT SYNC_DATE
      into v_last_sync_date
      FROM TW_SYJD_DS_CONFIG
     WHERE TABLE_NAME = 'XX_ORDER';
         
     if v_lock_flag = 'N' then      
       UPDATE TW_SYJD_DS_CONFIG
        SET LOCK_FLAG ='Y'
        WHERE TABLE_NAME = 'XX_ORDER';

       end if;
  end;
end CUX_SYNC_TW_DATA;
--SYNC_DATE  into v_last_sync_date
--into v_log_flag ,
/

