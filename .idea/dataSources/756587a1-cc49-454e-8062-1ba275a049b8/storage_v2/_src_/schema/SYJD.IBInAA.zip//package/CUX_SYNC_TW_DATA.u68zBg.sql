create package CUX_SYNC_TW_DATA is

  -- Author  : longwy
  -- Created : 2018/6/5 11:00:04
  -- Purpose : import tw's data to crm

  procedure import_tw_orders;

end CUX_SYNC_TW_DATA;
/

