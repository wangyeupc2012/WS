create trigger TRIGGER_SYSTEM_ITEMS_B
  before insert or update or delete
  on MTL_SYSTEM_ITEMS_B
  for each row
  declare
  -- local variables here
begin
    if 1=1 then
    ---- if :new.sal<:old.sal then
    ----- null;
    ---- end  if;   
    case  
    when  INSERTING then 
      
      begin
         insert into product
                    (id,
                     erp_item_id,
                     name,
                     erp_number,
                     unit,
                     tax)
                  values
                    (product_s.nextval,
                     :new.inventory_item_id,
                     :new.description,
                     :new.segment1,
                     :new.primary_uom_code,
                     :new.tax_code);	
      exception when others then
       -- RAISE_APPLICATION_ERROR(-20001,'ERP-SYJD物料插入失败！') ; 
       insert into erp_syjd_log
                    (log_id,
                     id,
                     table_name,
                     error_message,
                     creation_date)
                  values
                    (erp_syjd_log_s.nextval,
                     :new.inventory_item_id,
                     'mtl_system_items_b',
                     'INSERT 异常：'||:new.inventory_item_id,
                     sysdate);
      end;
      
    when  updating then
      begin
        update product
        set name = :new.description,
            erp_number = :new.segment1,
            unit   = :new.primary_uom_code,
            tax = :new.tax_code
        where erp_item_id = :old.inventory_item_id;
      exception when others then
         insert into erp_syjd_log
                    (log_id,
                     id, 
                     table_name,
                     error_message,
                     creation_date)
                  values
                    (erp_syjd_log_s.nextval,
                     :old.inventory_item_id,
                     'mtl_system_items_b',
                     'UPDATE 异常：'||:old.inventory_item_id,
                     sysdate);
      end;
    when  deleting then 
      
    begin
      delete from product t where t.erp_item_id=:old.inventory_item_id;
    exception when others then
       insert into erp_syjd_log
                    (log_id,
                     id, 
                     table_name,
                     error_message,
                     creation_date)
                  values
                    (erp_syjd_log_s.nextval,
                     :old.inventory_item_id,
                     'mtl_system_items_b',
                     'UPDATE 异常：'||:old.inventory_item_id,
                     sysdate);
    end;
    
    end case;
    end if;  
end trigger_system_items_b;
/

