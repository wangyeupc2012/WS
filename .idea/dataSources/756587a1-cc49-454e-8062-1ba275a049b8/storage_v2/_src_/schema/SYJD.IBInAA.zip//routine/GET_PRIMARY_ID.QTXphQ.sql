create function get_primary_id(p_seq_name varchar2)
  return number as PRAGMA AUTONOMOUS_TRANSACTION;
  l_seq_name varchar2(100);
  l_cnt      number;
  l_next_val number;
  l_val_from number;
  l_val_to   number;
  l_id       number;
begin
  --序列名为null，返回null
  if p_seq_name is null then
    return null;
  end if;
  
  l_seq_name := UPPER(p_seq_name);

  --判断序列是否存在
  select count(1)
    into l_cnt
    from idgenerator ig
   where UPPER(ig.sequence_name) = l_seq_name;
  --序列不存在，返回null
  if l_cnt = 0 then
    insert into idgenerator(sequence_name,next_val)
    values (l_seq_name,0);
  end if;

  --判断临时表该序列是否存在
  select count(1)
    into l_cnt
    from idgenerator_tmp igt
   where UPPER(igt.sequence_name) = l_seq_name;

  if l_cnt != 0 then
    --如果存在,则获取next_val并锁表
    select igt.next_val, igt.val_from, igt.val_to
      into l_next_val, l_val_from, l_val_to
      from idgenerator_tmp igt
     where UPPER(igt.sequence_name) = l_seq_name
       for update;

    l_id := l_next_val;
    --判断igt.next_val是否等于igt.val_to,是则重新获取序列开始，结束值
    if l_next_val = l_val_to then
      select ig.next_val
        into l_next_val
        from idgenerator ig
       where UPPER(ig.sequence_name) = l_seq_name
         for update;

      update idgenerator ig
         set ig.next_val = ig.next_val + 100
       where UPPER(ig.sequence_name) = l_seq_name;

      update idgenerator_tmp igt
         set igt.next_val = l_next_val,
             igt.val_from = l_next_val,
             igt.val_to   = l_next_val + 99
       where UPPER(igt.sequence_name) = l_seq_name;
    else
      --否，则直接更新next_val+1
      update idgenerator_tmp igt
         set igt.next_val = l_next_val + 1
       where UPPER(igt.sequence_name) = l_seq_name;
    end if;
    commit;

  else
    --临时表不存在该序列，则从idgenerator获取序列
    select ig.next_val
      into l_next_val
      from idgenerator ig
     where UPPER(ig.sequence_name) = l_seq_name
       for update;
       
    if l_next_val = 0 then
      l_next_val := 1;
    end if;
    
    l_id := l_next_val;

    update idgenerator ig
       set ig.next_val = ig.next_val + 100
     where UPPER(ig.sequence_name) = l_seq_name;

    insert into idgenerator_tmp
      (sequence_name, next_val, val_from, val_to)
    values
      (l_seq_name, l_next_val + 1, l_next_val, l_next_val + 99);

    commit;
  end if;

  return l_id;
end;
/

