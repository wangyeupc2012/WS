create view CUX_ORDER_ALL_INFO_V as
  select os.sn  order_number ,----订单编码
       os.id order_id,
       os.createddate ,----订单日期
       os.order_from ,  ---订单来源
       os.type ,------ 订单类型
       os.status,---订单状态
       cms.dealers_id,----经销商ID
       cms.dealers_name,---经销商名字
       cms.milk_station_id, ---奶站ID
       ms.milk_station_name,
       cms.source,
       oi.id order_line_id,---订单行ID
       nvl(oi.sn,oi.product_sn) item_number,---物料编码
       pt.name item_name,----物料名称
       oi.refund_status ,---退款状态
       oi.quantity,----订单数量
       oi.price,----订单行原价
       oi.pay_price,----实际支付价格
       oi.totalprice,----销售价格
       oi.order_days,--订购天数
       oi.DAILY_DELIVERY_QUANTITY,--每日配送数量
       oi.wdtorderitemid--旺店通订单行id
from  orders os, ----订单头
      orderitem oi,----订单行
      product  pt,-----产品表
      milk_station ms,
      fnd_lookup_values flvs,
      cux_dealers_milk_station_v  cms-----经销商奶站
where os.id=oi.orders
and   nvl(oi.sn,oi.product_sn)=pt.sn
and   cms.milk_station_id=ms.id(+)
and   os.order_from=flvs.lookup_code
and   flvs.lookup_type='ORDER_FROM'
and   os.milk_station_id=cms.milk_station_id
and   flvs.attribute1 = cms.source
union all
select os.sn  order_number ,----订单编码
       os.id order_id,
       os.createddate ,----订单日期
       os.order_from ,  ---订单来源
       os.type ,------ 订单类型
       os.status,---订单状态
       null dealers_id,----经销商ID
       null dealers_name,---经销商名字
       os.milk_station_id, ---奶站ID
       null milk_station_name,
       null source,
       oi.id order_line_id,---订单行ID
       nvl(oi.sn,oi.product_sn) item_number,---物料编码
       pt.name item_name,----物料名称
       oi.refund_status ,---退款状态
       oi.quantity,----订单数量
       oi.price,----订单行原价
       oi.pay_price,----实际支付价格
       oi.totalprice,----销售价格
       oi.order_days,--订购天数
       oi.DAILY_DELIVERY_QUANTITY,--每日配送数量
        oi.wdtorderitemid--旺店通订单行id
from  orders os, ----订单头
      orderitem oi,----订单行
      product  pt-----产品表
where os.id=oi.orders
and   nvl(oi.sn,oi.product_sn)=pt.sn
and os.milk_station_id is null
/

