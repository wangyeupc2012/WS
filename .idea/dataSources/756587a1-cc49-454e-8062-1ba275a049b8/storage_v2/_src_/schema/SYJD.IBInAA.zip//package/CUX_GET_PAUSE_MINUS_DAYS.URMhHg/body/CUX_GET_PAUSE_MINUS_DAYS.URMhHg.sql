create package body CUX_GET_PAUSE_MINUS_DAYS is

  function getPauseMinusDays(p_id           varchar2,
                             p_pause_from   varchar2,
                             p_revoery_date varchar2) return number is
    v_days          number;
    v_orderitem_id  varchar2(10);
    v_shipping_type varchar2(10);
    v_pause_from    date;
    v_recovery_date date;
    v_week          varchar2(20);
    v_act_days      number := 0;
    v_act_from      date;
    v_act_to        date;
    v_holiday_cnt   number;
  begin
    --获取订单行ID
    select opi.orderitem_id, opi.pause_date_from, opi.recovery_date
      into v_orderitem_id, v_pause_from, v_recovery_date
      from order_pause_interval opi
     where opi.id = p_id;
  
    --获取订单行配送类型
    select oi.shipping_type
      into v_shipping_type
      from orderitem oi
     where oi.id = v_orderitem_id;
  
    if v_shipping_type = 0 then
      select case
               when to_date(p_revoery_date, 'yyyy-MM-dd') <=
                    opi.recovery_date then
                0
               when to_date(p_pause_from, 'yyyy-MM-dd') <=
                    opi.pause_date_from and
                    to_date(p_revoery_date, 'yyyy-MM-dd') >
                    opi.pause_date_from and
                    to_date(p_revoery_date, 'yyyy-MM-dd') <=
                    opi.recovery_date then
                to_date(p_revoery_date, 'yyyy-MM-dd') - opi.pause_date_from
               when to_date(p_pause_from, 'yyyy-MM-dd') <=
                    opi.pause_date_from and
                    to_date(p_revoery_date, 'yyyy-MM-dd') >
                    opi.recovery_date then
                opi.recovery_date - opi.pause_date_from
               when to_date(p_pause_from, 'yyyy-MM-dd') >
                    opi.pause_date_from and
                    to_date(p_pause_from, 'yyyy-MM-dd') <= opi.recovery_date and
                    to_date(p_revoery_date, 'yyyy-MM-dd') <=
                    opi.recovery_date then
                to_date(p_revoery_date, 'yyyy-MM-dd') -
                to_date(p_pause_from, 'yyyy-MM-dd')
               when to_date(p_pause_from, 'yyyy-MM-dd') >
                    opi.pause_date_from and
                    to_date(p_pause_from, 'yyyy-MM-dd') <= opi.recovery_date and
                    to_date(p_revoery_date, 'yyyy-MM-dd') >
                    opi.recovery_date then
                opi.recovery_date - to_date(p_pause_from, 'yyyy-MM-dd')
               when to_date(p_pause_from, 'yyyy-MM-dd') > opi.recovery_date then
                0
             end
        into v_days
        from order_pause_interval opi
       where 1 = 1
         and opi.id = p_id;
    elsif v_shipping_type = 1 then
      if to_date(p_revoery_date, 'yyyy-MM-dd') <= v_pause_from then
        v_days := 0;
      elsif to_date(p_pause_from, 'yyyy-MM-dd') <= v_pause_from and
            to_date(p_revoery_date, 'yyyy-MM-dd') > v_pause_from and
            to_date(p_revoery_date, 'yyyy-MM-dd') <= v_recovery_date then
        -- select to_char(v_pause_from, 'day') into v_week from dual;
        v_act_from := v_pause_from;
        v_act_to   := to_date(p_revoery_date, 'yyyy-MM-dd');
      elsif to_date(p_pause_from, 'yyyy-MM-dd') <= v_pause_from and
            to_date(p_revoery_date, 'yyyy-MM-dd') > v_recovery_date then
        v_act_from := v_pause_from;
        v_act_to   := v_recovery_date;
      elsif to_date(p_pause_from, 'yyyy-MM-dd') > v_pause_from and
            to_date(p_revoery_date, 'yyyy-MM-dd') <= v_recovery_date then
        v_act_from := to_date(p_pause_from, 'yyyy-MM-dd');
        v_act_to   := to_date(p_revoery_date, 'yyyy-MM-dd');
      elsif to_date(p_pause_from, 'yyyy-MM-dd') > v_pause_from and
            to_date(p_revoery_date, 'yyyy-MM-dd') > v_recovery_date then
        v_act_from := to_date(p_pause_from, 'yyyy-MM-dd');
        v_act_to   := v_recovery_date;
      elsif to_date(p_pause_from, 'yyyy-MM-dd') > v_recovery_date then
        v_days := 0;
      end if;
      if v_act_from is not null and v_act_to is not null and
         v_act_from <> v_act_to then
        while v_act_from <= v_act_to loop
          begin
            select to_char(v_act_from, 'day') into v_week from dual;
            select count(1)
              into v_holiday_cnt
              from holiday h
             where h.holiday_date = v_act_from;
            if v_holiday_cnt = 0 and v_week <> '星期六' and v_week <> '星期日' then
              v_act_days := v_act_days + 1;
            end if;
            v_act_from := v_act_from + 1;
          end;
        end loop;
				v_days := v_act_days;
      end if;
    end if;
  
    return v_days;
  exception
    when others then
      null;
  end;
end CUX_GET_PAUSE_MINUS_DAYS;
/

