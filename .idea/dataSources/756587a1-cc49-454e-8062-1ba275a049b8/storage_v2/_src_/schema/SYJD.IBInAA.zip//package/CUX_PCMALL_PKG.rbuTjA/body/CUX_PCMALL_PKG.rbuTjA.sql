create package body CUX_PCMALL_PKG is

  PROCEDURE GET_SHOPPING_CART_CONFIRM(P_SHOPPINGCART_ID IN NUMBER,
                                      P_USER_ID         IN NUMBER,
                                      P_ORDER_ID        OUT NUMBER,
                                      P_FLAG            OUT VARCHAR2,
                                      P_MSG             OUT VARCHAR2) IS
    CURSOR CUR_SHP_ITEM IS
      SELECT T.ITEM_ID,
             prd.sn ITEM_SN,
             T.ITEM_QUANTITY,
             PRD.NAME,
             T.ITEM_PRICE
        FROM CUX_APP_SHOPPING_CART_ITEM_T T, PRODUCT PRD
       WHERE T.Item_Id = PRD.ID
            -- AND T.ITEM_SN = PRD.SN
         AND T.SHOPPING_CART_ID = P_SHOPPINGCART_ID;
    VAR_SHP_ITEM        CUR_SHP_ITEM%ROWTYPE;
    VAR_STORE_ID        NUMBER;
    VAR_USER_ID         NUMBER;
    VAR_ADDRESS         VARCHAR2(120);
    VAR_CONSIGNEE       VARCHAR2(30);
    VAR_PHONE           VARCHAR2(20);
    VAR_AREA_ID         NUMBER;
    VAR_MILK_STATION_ID NUMBER;
    VAR_POI_UID         VARCHAR2(120);
    VAR_POI_TITLE       VARCHAR2(120);
    VAR_ORDER_ID        NUMBER;
    VAR_RECEIVER_ID     NUMBER;
    VAR_SHOPPING_DATE   DATE;
    VAR_AREA_NAME       VARCHAR2(100);
    VAR_FLAG            VARCHAR2(20);
    VAR_MSG             VARCHAR2(120);
  BEGIN
    VAR_FLAG := 'Y';
    BEGIN
      SELECT CASCT.STORE_ID, CASCT.SHOPPING_DATE
        INTO VAR_STORE_ID, VAR_SHOPPING_DATE
        FROM CUX_APP_SHOPPING_CART_T CASCT
       WHERE CASCT.ID = P_SHOPPINGCART_ID;
    EXCEPTION
      WHEN OTHERS THEN
        VAR_FLAG := 'N';
        VAR_MSG  := 'SELECT STORE ID ERROR!!';
    END;
  
    IF VAR_FLAG = 'Y' THEN
      BEGIN
        SELECT CAS.STORE_MANAGER_ID
          INTO VAR_USER_ID
          FROM CUX_APP_STORE_T CAS
         WHERE CAS.ID = VAR_STORE_ID;
      EXCEPTION
        WHEN OTHERS THEN
          VAR_FLAG := 'N';
          VAR_MSG  := 'SELECT USER ID ERROR!!';
      END;
    END IF;
  
    IF VAR_FLAG = 'Y' THEN
      BEGIN
        SELECT RE.ADDRESS,
               RE.CONSIGNEE,
               RE.PHONE,
               RE.AREA_ID,
               RE.MILK_STATION_ID,
               RE.POI_UID,
               RE.POITITLE,
               A.FULLNAME_VAR,
               RE.ID
          INTO VAR_ADDRESS,
               VAR_CONSIGNEE,
               VAR_PHONE,
               VAR_AREA_ID,
               VAR_MILK_STATION_ID,
               VAR_POI_UID,
               VAR_POI_TITLE,
               VAR_AREA_NAME,
               VAR_RECEIVER_ID
          FROM RECEIVER RE, AREA A
         WHERE RE.AREA_ID = A.ID
           AND RE.MEMBER_ID = VAR_USER_ID;
      EXCEPTION
        WHEN OTHERS THEN
          VAR_FLAG := 'N';
          VAR_MSG  := '该门店未维护收货信息！';
      END;
    END IF;
    IF VAR_FLAG = 'Y' THEN
      SELECT get_primary_id('ORDERS') INTO VAR_ORDER_ID FROM DUAL;
      insert into ORDERS
        (id,
         CREATEDDATE,
         LASTMODIFIEDDATE,
         VERSION,
         ADDRESS,
         AMOUNT,
         AMOUNTPAID,
         AREANAME,
         CONSIGNEE,
         COUPONDISCOUNT,
         EXCHANGEPOINT,
         EXPIRE,
         FEE,
         FREIGHT,
         INVOICETITLE,
         ISALLOCATEDSTOCK,
         ISEXCHANGEPOINT,
         ISUSECOUPONCODE,
         MEMO,
         OFFSETAMOUNT,
         PAYMENTMETHODNAME,
         PAYMENTMETHODTYPE,
         PHONE,
         PRICE, --全部写为0
         PROMOTIONDISCOUNT,
         PROMOTIONNAMES,
         QUANTITY, --0
         REFUNDAMOUNT, --0
         RETURNEDQUANTITY, --0
         REWARDPOINT,
         SHIPPEDQUANTITY, --0
         SHIPPINGMETHODNAME,
         SN,
         STATUS,
         TAX,
         TYPE,
         WEIGHT,
         ZIPCODE,
         AREA_ID,
         COUPONCODE_ID,
         MEMBER_ID,
         PAYMENTMETHOD_ID,
         SHIPPINGMETHOD_ID, --配送到户 51
         STORE_ID,
         CREATED_BY, -- 默认为-1
         LAST_UPDATED_BY, --默认为-1
         ORDER_FROM,
         MILK_STATION_ID,
         MS_COURIER_ID,
         DEALER_ID,
         POI_UID,
         POI_TITLE,
         RECEIVER_ID,
         valid_milkstation_flag,
         OLDCUSTOMER_FLAG,
         MODE_OF_DISTRIBUTION,
         COUPONAMOUNT,
         REDPACKETAMOUNT,
         ACTUALAMOUNT,
         ACTIVITYAMOUNT,
         BUYER_REMARK,
         OLD_FLAG,
         DEL_FLAG,
         ORDERREFUNDS_STATUS)
      values
        (VAR_ORDER_ID,
         sysdate,
         sysdate,
         1,
         VAR_ADDRESS,
         0,
         0,
         VAR_AREA_NAME,
         VAR_CONSIGNEE,
         0,
         0,
         '',
         0,
         0,
         0,
         0,
         0,
         0,
         '',
         0,
         '',
         '',
         VAR_PHONE,
         0,
         0,
         '',
         0,
         0,
         0,
         0,
         0,
         0,
         'SN' || VAR_ORDER_ID,
         2,
         0,
         0, --type
         0,
         '',
         VAR_AREA_ID,
         '',
         VAR_USER_ID,
         '',
         51,
         51,
         P_USER_ID,
         P_USER_ID,
         'PCMALL',
         VAR_MILK_STATION_ID,
         '',
         '',
         VAR_POI_UID,
         VAR_POI_TITLE,
         VAR_RECEIVER_ID,
         'Y',
         '',
         '', --MODE_OF_DISTRIBUTION
         0,
         0,
         0,
         0,
         '',
         0,
         0,
         '');
    END IF;
  
    IF VAR_FLAG = 'Y' THEN
      FOR VAR_SHP_ITEM IN CUR_SHP_ITEM LOOP
        insert into ORDERITEM
          (id,
           createddate,
           lastmodifieddate,
           version,
           commissiontotals,
           isdelivery,
           name,
           price,
           quantity,
           returnedquantity,
           shippedquantity,
           sn,
           specifications,
           thumbnail,
           type,
           weight,
           orders,
           sku_id,
           created_by,
           last_updated_by,
           order_date_from,
           order_date_to,
           order_days,
           daily_delivery_quantity,
           delivery_days,
           remain_days,
           REFUND_STATUS,
           day_shipping_time,
           shipping_type,
           original_order_date_to,
           product_sn,
           PAY_PRICE,
           present_flag,
           TOTALPRICE,
           LINE_COUNT)
        values
          (get_primary_id('ORDERITEM'),
           sysdate,
           sysdate,
           1,
           0,
           1,
           VAR_SHP_ITEM.NAME,
           nvl(VAR_SHP_ITEM.ITEM_PRICE, 0),
           VAR_SHP_ITEM.ITEM_QUANTITY, --每日配送数量* 订购天数
           0,
           0,
           VAR_SHP_ITEM.ITEM_SN,
           '',
           '',
           0,
           --var_ord_line.type,
           '',
           VAR_ORDER_ID,
           '',
           -1,
           -1,
           VAR_SHOPPING_DATE,
           VAR_SHOPPING_DATE,
           1,
           VAR_SHP_ITEM.ITEM_QUANTITY,
           '',
           '',
           0,
           0,
           0,
           VAR_SHOPPING_DATE,
           VAR_SHP_ITEM.ITEM_SN,
           VAR_SHP_ITEM.ITEM_PRICE,
           0,
           VAR_SHP_ITEM.ITEM_QUANTITY * VAR_SHP_ITEM.ITEM_PRICE,
           0);
      END LOOP;
      COMMIT;
    END IF;
    P_ORDER_ID := VAR_ORDER_ID;
    P_FLAG     := VAR_FLAG;
    P_MSG      := VAR_MSG;
  END;

  PROCEDURE GET_ORDER_COPY(P_USER_ID  IN NUMBER,
                           P_ORDER_ID IN NUMBER,
                           P_CODE     OUT VARCHAR2,
                           P_MESSAGE  OUT VARCHAR2) IS
    CURSOR CUR_ORI IS
      SELECT * FROM ORDERITEM OI WHERE OI.ORDERS = P_ORDER_ID;
    VAR_ORI      CUR_ORI%ROWTYPE;
    VAR_STORE_ID NUMBER;
    VAR_ITEM_CNT NUMBER;
    VAR_CODE     VARCHAR2(20);
    VAR_MESSAGE  VARCHAR2(225);
  
  BEGIN
    VAR_CODE := 'Y';
    BEGIN
      SELECT OS.APP_STORE_ID
        INTO VAR_STORE_ID
        FROM ORDERS OS
       WHERE OS.ID = P_ORDER_ID;
    EXCEPTION
      WHEN OTHERS THEN
        VAR_CODE    := 'Y';
        VAR_MESSAGE := SQLERRM;
    END;
  
    IF VAR_CODE = 'Y' THEN
      FOR VAR_ORI IN CUR_ORI LOOP
        SELECT COUNT(1)
          INTO VAR_ITEM_CNT
          FROM CUX_APP_SHOPPING_CART_NEW_T CAS
         WHERE CAS.STORE_ID = VAR_STORE_ID
           AND CAS.ITEM_ID = (SELECT ID FROM PRODUCT WHERE SN = VAR_ORI.SN);
      
        IF VAR_ITEM_CNT > 0 THEN
          UPDATE CUX_APP_SHOPPING_CART_NEW_T CAS
             SET CAS.ITEM_QUANTITY    = CAS.ITEM_QUANTITY + VAR_ORI.QUANTITY,
                 CAS.LASTMODIFIEDDATE = SYSDATE,
                 CAS.LASTMODIFIEDBY   = P_USER_ID
           WHERE CAS.STORE_ID = VAR_STORE_ID
             AND CAS.ITEM_ID =
                 (SELECT ID FROM PRODUCT WHERE SN = VAR_ORI.SN);
        ELSE
          insert into CUX_APP_SHOPPING_CART_NEW_T
            (ID,
             CREATEDDATE,
             LASTMODIFIEDDATE,
             CREATEDBY,
             LASTMODIFIEDBY,
             STORE_ID,
             ITEM_ID,
             ITEM_QUANTITY)
          values
            (get_primary_id('CUX_APP_SHOPPING_CART_NEW_T'),
             sysdate,
             sysdate,
             P_USER_ID,
             P_USER_ID,
             VAR_STORE_ID,
             (SELECT ID FROM PRODUCT WHERE SN = VAR_ORI.SN),
             VAR_ORI.QUANTITY);
        END IF;
      
      END LOOP;
    END IF;
    P_CODE    := VAR_CODE;
    P_MESSAGE := VAR_MESSAGE;
  END;

  PROCEDURE GET_SHOPPING_CART_CONFIRM_NEW(P_BATCH_ID      IN NUMBER,
                                          P_USER_ID       IN NUMBER,
                                          P_SHOPPING_DATE IN VARCHAR2,
                                          P_ORDER_ID      OUT NUMBER,
                                          P_FLAG          OUT VARCHAR2,
                                          P_MSG           OUT VARCHAR2) IS
    CURSOR CUR_SHOP IS
      SELECT *
        FROM CUX_APP_SHOPPING_CART_NEW_T CAS
       WHERE CAS.ID IN (SELECT T.SHOPPING_CART_ID
                          FROM cux_app_shopping_cart_temp T
                         WHERE T.BATCH_ID = P_BATCH_ID);
    VAR_SHOP             CUR_SHOP%ROWTYPE;
    VAR_ADDRESS          VARCHAR2(120);
    VAR_CONSIGNEE        VARCHAR2(30);
    VAR_PHONE            VARCHAR2(20);
    VAR_AREA_ID          NUMBER;
    VAR_MILK_STATION_ID  NUMBER;
    VAR_POI_UID          VARCHAR2(120);
    VAR_POI_TITLE        VARCHAR2(120);
    VAR_RECEIVER_ID      NUMBER;
    VAR_AREA_NAME        VARCHAR2(100);
    VAR_USER_ID          NUMBER;
    VAR_ORDER_ID         NUMBER;
    VAR_ITEM_SN          VARCHAR2(120);
    VAR_ITEM_NAME        VARCHAR2(120);
    VAR_ITEM_PRICE       NUMBER;
    VAR_FLAG             VARCHAR2(20);
    VAR_MSG              VARCHAR2(255);
    var_store_id_temp number;
  BEGIN
    VAR_FLAG := 'Y';
    IF VAR_FLAG = 'Y' THEN
      BEGIN
        SELECT cas.store_id
          into var_store_id_temp
          FROM CUX_APP_SHOPPING_CART_NEW_T CAS
         WHERE CAS.ID IN (SELECT T.SHOPPING_CART_ID
                            FROM cux_app_shopping_cart_temp T
                           WHERE T.BATCH_ID = P_BATCH_ID)
           and rownum = 1;
      
        SELECT CAS.STORE_MANAGER_ID
          INTO VAR_USER_ID
          FROM CUX_APP_STORE_T CAS
         WHERE CAS.ID = var_store_id_temp;
      EXCEPTION
        WHEN OTHERS THEN
          VAR_FLAG := 'N';
          VAR_MSG  := 'SELECT USER ID ERROR!!';
      END;
    END IF;
  
    IF VAR_FLAG = 'Y' THEN
      BEGIN
        SELECT RE.ADDRESS,
               RE.CONSIGNEE,
               RE.PHONE,
               RE.AREA_ID,
               RE.MILK_STATION_ID,
               RE.POI_UID,
               RE.POITITLE,
               A.FULLNAME_VAR,
               RE.ID
          INTO VAR_ADDRESS,
               VAR_CONSIGNEE,
               VAR_PHONE,
               VAR_AREA_ID,
               VAR_MILK_STATION_ID,
               VAR_POI_UID,
               VAR_POI_TITLE,
               VAR_AREA_NAME,
               VAR_RECEIVER_ID
          FROM RECEIVER RE, AREA A
         WHERE RE.AREA_ID = A.ID
           AND RE.MEMBER_ID = VAR_USER_ID;
      EXCEPTION
        WHEN OTHERS THEN
          VAR_FLAG := 'N';
          VAR_MSG  := '该门店未维护收货信息！';
      END;
    END IF;
  
    IF VAR_FLAG = 'Y' THEN
      SELECT get_primary_id('ORDERS') INTO VAR_ORDER_ID FROM DUAL;
      insert into ORDERS
        (id,
         CREATEDDATE,
         LASTMODIFIEDDATE,
         VERSION,
         ADDRESS,
         AMOUNT,
         AMOUNTPAID,
         AREANAME,
         CONSIGNEE,
         COUPONDISCOUNT,
         EXCHANGEPOINT,
         EXPIRE,
         FEE,
         FREIGHT,
         INVOICETITLE,
         ISALLOCATEDSTOCK,
         ISEXCHANGEPOINT,
         ISUSECOUPONCODE,
         MEMO,
         OFFSETAMOUNT,
         PAYMENTMETHODNAME,
         PAYMENTMETHODTYPE,
         PHONE,
         PRICE, --全部写为0
         PROMOTIONDISCOUNT,
         PROMOTIONNAMES,
         QUANTITY, --0
         REFUNDAMOUNT, --0
         RETURNEDQUANTITY, --0
         REWARDPOINT,
         SHIPPEDQUANTITY, --0
         SHIPPINGMETHODNAME,
         SN,
         STATUS,
         TAX,
         TYPE,
         WEIGHT,
         ZIPCODE,
         AREA_ID,
         COUPONCODE_ID,
         MEMBER_ID,
         PAYMENTMETHOD_ID,
         SHIPPINGMETHOD_ID, --配送到户 51
         STORE_ID,
         CREATED_BY, -- 默认为-1
         LAST_UPDATED_BY, --默认为-1
         ORDER_FROM,
         MILK_STATION_ID,
         MS_COURIER_ID,
         DEALER_ID,
         POI_UID,
         POI_TITLE,
         RECEIVER_ID,
         valid_milkstation_flag,
         OLDCUSTOMER_FLAG,
         MODE_OF_DISTRIBUTION,
         COUPONAMOUNT,
         REDPACKETAMOUNT,
         ACTUALAMOUNT,
         ACTIVITYAMOUNT,
         BUYER_REMARK,
         OLD_FLAG,
         DEL_FLAG,
         ORDERREFUNDS_STATUS)
      values
        (VAR_ORDER_ID,
         sysdate,
         sysdate,
         1,
         VAR_ADDRESS,
         0,
         0,
         VAR_AREA_NAME,
         VAR_CONSIGNEE,
         0,
         0,
         '',
         0,
         0,
         0,
         0,
         0,
         0,
         '',
         0,
         '',
         '',
         VAR_PHONE,
         0,
         0,
         '',
         0,
         0,
         0,
         0,
         0,
         0,
         'SN' || VAR_ORDER_ID,
         2,
         0,
         0, --type
         0,
         '',
         VAR_AREA_ID,
         '',
         VAR_USER_ID,
         '',
         51,
         51,
         P_USER_ID,
         P_USER_ID,
         'PCMALL',
         VAR_MILK_STATION_ID,
         '',
         '',
         VAR_POI_UID,
         VAR_POI_TITLE,
         VAR_RECEIVER_ID,
         'Y',
         '',
         '', --MODE_OF_DISTRIBUTION
         0,
         0,
         0,
         0,
         '',
         0,
         0,
         '');
    END IF;
  
    IF VAR_FLAG = 'Y' THEN
      FOR VAR_SHOP IN CUR_SHOP LOOP
        SELECT CAI.ITEM_SN, CAI.ITEM_NAME, CAI.PRICE_NOW
          INTO VAR_ITEM_SN, VAR_ITEM_NAME, VAR_ITEM_PRICE
          FROM CUX_APP_ITEM_ATTRIBUTE_T CAI
         WHERE CAI.ITEM_ID = VAR_SHOP.ITEM_ID;
        insert into ORDERITEM
          (id,
           createddate,
           lastmodifieddate,
           version,
           commissiontotals,
           isdelivery,
           name,
           price,
           quantity,
           returnedquantity,
           shippedquantity,
           sn,
           specifications,
           thumbnail,
           type,
           weight,
           orders,
           sku_id,
           created_by,
           last_updated_by,
           order_date_from,
           order_date_to,
           order_days,
           daily_delivery_quantity,
           delivery_days,
           remain_days,
           REFUND_STATUS,
           day_shipping_time,
           shipping_type,
           original_order_date_to,
           product_sn,
           PAY_PRICE,
           present_flag,
           TOTALPRICE,
           LINE_COUNT)
        values
          (get_primary_id('ORDERITEM'),
           sysdate,
           sysdate,
           1,
           0,
           1,
           VAR_ITEM_NAME,
           nvl(VAR_ITEM_PRICE, 0),
           VAR_SHOP.ITEM_QUANTITY, --每日配送数量* 订购天数
           0,
           0,
           VAR_ITEM_SN,
           '',
           '',
           0,
           --var_ord_line.type,
           '',
           VAR_ORDER_ID,
           '',
           -1,
           -1,
           TO_DATE(P_SHOPPING_DATE, 'yyyy-MM-dd'),
           TO_DATE(P_SHOPPING_DATE, 'yyyy-MM-dd'),
           1,
           VAR_SHOP.ITEM_QUANTITY,
           '',
           '',
           0,
           0,
           0,
           TO_DATE(P_SHOPPING_DATE, 'yyyy-MM-dd'),
           VAR_ITEM_SN,
           VAR_ITEM_PRICE,
           0,
           VAR_SHOP.ITEM_QUANTITY * VAR_ITEM_PRICE,
           0);
      END LOOP;
      COMMIT;
    END IF;
    P_ORDER_ID := VAR_ORDER_ID;
    P_FLAG     := VAR_FLAG;
    P_MSG      := VAR_MSG;
  END;
end CUX_PCMALL_PKG;
/

