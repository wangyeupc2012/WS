create PACKAGE BODY syjd_import_milkstation_pjg IS
  PROCEDURE syjd_import_milkstation is
    cursor c_temp_milk_station is
      select * from temp_milk_station;
  
    cursor cur_jz_station is
      select ms.id milk_station_id, ms1.id jz_milk_station_id
        from temp_milk_station tms, milk_station ms, milk_station ms1
       where tms.milk_station_name = ms.milk_station_name
         and tms.jz_belong_to_name = ms1.milk_station_name;
    var_jz_station cur_jz_station%rowtype;
  begin
    --先删除原奶站的数据
    delete from milk_station;
    COMMIT;
    FOR v_temp_milk_station in c_temp_milk_station loop
      begin
        insert into milk_station
          (ID,
           DEALERS_ID,
           MILK_STATION_CODE,
           MILK_STATION_NAME,
           MANAGER,
           TEL_NUMBER,
           AREA_ID,
           DETAILED_ADDRESS,
           LONGITUDE,
           LATITUDE,
           STATUS,
           JZ_FLAG,
           CREDIT_SCORE,
           LAST_UPDATE_DATE,
           LAST_UPDATED_BY,
           CREATION_DATE,
           CREATED_BY,
           PROVINCE_ID,
           CITY_ID,
           JZ_BELONG_TO,
           PRICE_ID,
           PRINT_ZONE,
           DELIVERY_LINE,
           POI_UID,
           POI_TITLE,
           SALESMAN_ID,
           ONE_OFF_DISTRIBUTION)
        values
          (get_primary_id('MILK_STATION'),
           v_temp_milk_station.DEALERS_ID,
           'NZ' || MILK_STATION_S.NEXTVAL,
           v_temp_milk_station.MILK_STATION_NAME,
           v_temp_milk_station.MANAGER,
           v_temp_milk_station.TEL_NUMBER,
           v_temp_milk_station.AREA_ID,
           v_temp_milk_station.DETAILED_ADDRESS,
           v_temp_milk_station.LONGITUDE,
           v_temp_milk_station.LATITUDE,
           'NEW',
           v_temp_milk_station.JZ_FLAG,
           '100',
           SYSDATE,
           -1,
           SYSDATE,
           -1,
           v_temp_milk_station.PROVINCE_ID,
           v_temp_milk_station.CITY_ID,
           v_temp_milk_station.JZ_BELONG_TO,
           v_temp_milk_station.PRICE_ID,
           v_temp_milk_station.PRINT_ZONE,
           v_temp_milk_station.DELIVERY_LINE,
           v_temp_milk_station.POI_UID,
           v_temp_milk_station.POI_TITLE,
           v_temp_milk_station.SALESMAN_ID,
           '');
        update temp_milk_station tms
           set tms.flag = 'Y'
         where tms.milk_station_name = tms.milk_station_name;
      exception
        when others then
          update temp_milk_station tms
             set tms.flag = 'E'
           where tms.milk_station_name = tms.milk_station_name;
      end;
      commit;
    end loop;
    --将基站信息更新
    for var_jz_station in cur_jz_station loop
      update milk_station ms
         set ms.jz_belong_to = var_jz_station.jz_milk_station_id
       where ms.id = var_jz_station.milk_station_id;
      commit;
    end loop;
  end;

  --插入用户 分配权限
  procedure insert_fnd_users(p_mobilephone in varchar2, p_name in varchar2) is
  
  begin
    insert into fnd_users
      (user_id,
       user_type,
       login_username,
       login_password,
       start_date,
       mobilephone,
       last_update_date,
       last_updated_by,
       created_by,
       status,
       name)
    values
      (fnd_user_s.nextval,
       'MILK_STATION',
       p_mobilephone,
       '123',
       sysdate,
       p_mobilephone,
       sysdate,
       -1,
       -1,
       'VALID',
       p_name);
  end;
end;
/

