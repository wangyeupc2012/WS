create package FND_UTIL is

  -- Author  : AI
  -- Created : 2015-05-11 07:59:29
  -- Purpose : FND_UTIL

  --验证用户数据相关
  function validate_auth(p_user_id number,
                         -- p_dealers_id      varchar2,
                         p_milk_station_id varchar2,
                         p_ms_courier_id   varchar2) return varchar2;
  --验证用户经销商和奶站的关系
  function crm_validate_auth(p_user_id number, p_milk_station_id varchar2)
    return varchar2;
  --根据lookup_type和lookup_code 获取 meaning
  function get_lookup_meaning(p_lookup_type in varchar2,
                              p_lookup_code varchar) return varchar2;

  procedure get_primary_id(p_seq_name in varchar2, x_id out number);

  function get_id(p_seq_name varchar2) return number;
  --输入两个日期判断两个日期之间有多少个节假日,及有多少天
  procedure f_playday_judge(p_start_date   in varchar2,
                            p_end_date     in varchar2,
                            p_extend_day   in varchar2,
                            holiday_amount out number,
                            all_amount     out number,
                            extend_date    out varchar);
  --验证订单来源是线上还是线下
  function validate_order_status(p_order_source  varchar2,
                                 p_order_status  varchar2,
                                 p_show_platform varchar2) return varchar2;
  --获取当前配送员的服务态度星级                                 
  function get_mscourier_service_attitude(p_mscourier_id number)
    return number;

  --根据订单编号获取退款金额
  procedure get_orderrefund_amount(p_order_id           in number,
                                   p_orderrefund_amount out number);
  --获得订单中间表错误信息
  function getErrorMessageFromTempOrder(p_orderid varchar2) return varchar;

  function getPauseMinusDays(p_id           varchar2,
                             p_pause_from   varchar2,
                             p_revoery_date varchar2) return number;
  --获得满足抛ERP条件的奶站
  function getErpMilkStationCondition(p_flag varchar2) return varchar;

  --显示小数点前的0                                                     
  function showZeroBeforePoint(p_num number) return varchar2;

end FND_UTIL;
/

