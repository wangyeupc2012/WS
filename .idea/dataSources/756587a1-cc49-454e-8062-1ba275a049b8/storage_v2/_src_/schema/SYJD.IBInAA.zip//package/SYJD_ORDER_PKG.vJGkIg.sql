create PACKAGE syjd_order_pkg IS
  --根据订单地址匹配地址库信息，对订单分配奶站及送奶工
  PROCEDURE allot_orders(p_order_id IN NUMBER,
                         x_code     OUT VARCHAR2,
                         x_msg      OUT VARCHAR2);

  --根据订单生成配送单
  PROCEDURE gen_shippingorder(p_order_id       IN NUMBER,
                              p_date           IN VARCHAR2,
                              p_user_id        IN INT,
                              p_type           IN VARCHAR2,
                              p_area_city_name IN VARCHAR2,
                              p_dealers_id     IN VARCHAR2,
                              p_shipping_group IN VARCHAR2,
                              p_status         out varchar2);

  --生成生产计划
  PROCEDURE gen_production_plan(p_date    IN VARCHAR2,
                                p_user_id IN NUMBER,
                                x_code    OUT VARCHAR2,
                                x_msg     OUT VARCHAR2);

  --生成ebs销售订单
  procedure gen_erp_order(p_date    IN VARCHAR2,
                          p_user_id IN NUMBER,
                          x_code    OUT VARCHAR2,
                          x_msg     OUT VARCHAR2);

  --判断配送员批量暂停区间标识
  function judge_pause_flag(p_ms_courier_id number, p_order_id number)
    return varchar2;
  --判断订单行是不是最后一天
  function judge_final_date(p_date             varchar2,
                            cp_milk_station_id number,
                            cp_order_from      varchar2,
                            product_id         number,
                            orderitem          number) return varchar2;
  --获得最后一天价格                        
  function get_final_price(p_date             varchar2,
                           cp_milk_station_id number,
                           cp_order_from      varchar2,
                           product_id         number,
                           orderitem          number) return number;
  --获得不是最后一天的数量                          
  function get_befroe_quantity(p_date             varchar2,
                               cp_milk_station_id number,
                               cp_order_from      varchar2,
                               product_id         number,
                               orderitem          number) return number;
  --新增批量暂停
  procedure import_batch_pause(p_mscourier_id    in varchar2,
                               p_milk_station_id IN VARCHAR2,
                               p_pause_reason    in varchar2,
                               p_pause_from      in varchar2,
                               p_recovery_date   in varchar2,
                               p_created_by      in varchar2,
                               P_BATCHPAUSE_ID   OUT NUMBER,
                               p_flag            out varchar2,
                               p_msg             out varchar2);
  --删除批量暂停
  procedure delete_batch_pause(p_batch_pause_id in varchar2,
                               p_flag           out varchar2,
                               p_msg            out varchar2);
  --更新批量暂停
  procedure update_batch_pause(p_batch_pause_id  in varchar2,
                               p_mscourier_id    in varchar2,
                               p_milk_station_id IN VARCHAR2,
                               p_pause_reason    in varchar2,
                               p_pause_from      in varchar2,
                               p_recovery_date   in varchar2,
                               p_created_by      in varchar2,
                               p_flag            out varchar2,
                               p_msg             out varchar2);
  --更换配送类型
  procedure change_shipping_type(p_orderitem_id  in varchar2,
                                 p_change_date   in varchar2,
                                 p_shipping_type in number,
                                 p_ori_ship_type in number,
                                 p_created_by    in number,
                                 p_flag          out varchar2,
                                 p_msg           out varchar2);
  --计算退款数量金额
  PROCEDURE GET_REFUND_INFO(P_ORDER_ID      IN VARCHAR2,
                            P_ORDERITEM_ID  IN VARCHAR2,
                            P_REFUND_DATE   IN VARCHAR2,
                            P_REFUND_NUM    OUT NUMBER,
                            P_REFUND_AMOUNT OUT NUMBER,
                            P_ACT_PRICE     OUT NUMBER,
                            P_PRICE         OUT NUMBER,
                            P_FLAG          OUT VARCHAR2,
                            P_MSG           OUT VARCHAR2);
END syjd_order_pkg;
/

