create package cux_import_tw_pkg is

  -- Author  : WANGYE
  -- Created : 2017/9/19 14:10:20
  -- Purpose : cux_import_tw_pkg

  --导入会员
  procedure import_customer;
  --根据cux_syjd_order表member_id 反查 CRM member表member_id
  function get_member_id(p_member_id cux_syjd_order.member%type)
    return number;
  --导入订单
  procedure import_order;
  --导入客户（经销商）
  procedure import_dealers;
  --导入奶站
  procedure import_milkstation;
  --根据经销商名称 获取导入后的经销商id
  function get_dealers_id(p_dealers_name cux_syjd_store.distributor_name%type)
    return number;
  --根据奶站名 获取导入后的经销商id
  function get_dealers_id_by_id(p_milk_station_id number) return number;
  --根据奶站id获取导入后的奶站id
  function get_milk_station_id(p_milk_station_id xx_dilivery_man.store%type)
    return number;
  --导入配送员
  procedure import_ms_courier;
  --订单area_name 格式化
  function format_area_name(p_area_name in cux_syjd_order.area_name%type)
    return varchar2;
  --根据同旺订单area_name，获取area_name格式化后的area_id
  function get_area_id(p_area_name cux_syjd_order.area_name%type)
    return number;
  --从订单表orders导入地址到地址库
  procedure import_addressbase(p_order_id in orders.id%type);

  --分批调用import_addressbase 每次5000条
  procedure import_addressbase_batch;

  --根据配送员姓名，奶站名，获取导入后的配送员id
  function get_ms_courier_id(p_ms_courier_name cux_syjd_order.send_people%type,
                             p_milk_station_id cux_syjd_order.stores%type)
    return number;
  --先在cux_syjd_order表中将需要更新的数据更新到新字段中，然后再导入，目的提升速度
  procedure update_cux_order;

  --导入收货地址
  procedure import_receiver;

  procedure main;

end cux_import_tw_pkg;
/

