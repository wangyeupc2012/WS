create package body CRM_PRODUCT_CHECK_PKG is

  procedure check_product is
    cursor cur_item is
      select name, product_sn from orderitem group by name, product_sn;
    var_item cur_item%rowtype;
    v_cnt    number;
		v_orderitem cux_orderitem_v%rowtype;
  begin
    --判断在PRODUCT_SN_NEW_AND_OLD表中是否已存在
    --判断在product表中是否存在相同的或者相似的名称
    for var_item in cur_item loop
      begin
        select id,name,sn
          into v_orderitem
          from product
         where name like '%' || var_item.name || '%';
        --如果存在相似的名称，继续判断SN是否相同，并将相同的写入PRODUCT_SN_NEW_AND_OLD表
        if v_cnt > 0 then
          null;
        end if;
      end;
    end loop;
  exception
    when others then
      null;
  end;
end CRM_PRODUCT_CHECK_PKG;
/

