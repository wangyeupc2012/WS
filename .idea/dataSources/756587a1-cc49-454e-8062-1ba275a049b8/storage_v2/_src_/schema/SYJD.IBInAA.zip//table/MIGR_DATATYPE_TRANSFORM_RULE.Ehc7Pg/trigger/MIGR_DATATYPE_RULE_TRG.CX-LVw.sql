create trigger MIGR_DATATYPE_RULE_TRG
  before insert or update
  on MIGR_DATATYPE_TRANSFORM_RULE
  for each row
  BEGIN
  if inserting and :new.id is null then
        :new.id := MD_META.get_next_id;
    end if;
END;
/

